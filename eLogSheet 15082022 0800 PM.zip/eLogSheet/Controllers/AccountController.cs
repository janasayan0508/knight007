﻿using System;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using eLogSheet.Models;
using System.Web.UI;
using eLogSheet.Utilities;
using System.Collections.Generic;

namespace eLogSheet.Controllers
{
    public class AccountController : Controller
    {
        private ApplicationSignInManager _signInManager;
        private ApplicationUserManager _userManager;
        private IdentityManager _indentityManager = new IdentityManager();
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        public AccountController()
        {
        }

        public AccountController(ApplicationUserManager userManager, ApplicationSignInManager signInManager )
        {
            UserManager = userManager;
            SignInManager = signInManager;
        }

        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set 
            { 
                _signInManager = value; 
            }
        }

        //
        // GET: /Account/ResetPassword
        [Authorize(Roles = "HOD,Admin")]
        public ActionResult ResetPassword(string id)
        {
            ResetPasswordViewModel model = new ResetPasswordViewModel();
            using (eLogSheetEntities db = new eLogSheetEntities())
            {
                sp_GetUserDetails_Result user =
                    db.sp_GetUserDetails(id)
                    .FirstOrDefault();
                if (user != null)
                {
                    model = new ResetPasswordViewModel
                    {
                        UserId = user.Id,
                        DId = user.DId,
                        Mobile = user.PhoneNumber,
                        Name = user.FullName,
                    };
                }

            }
            return View(model);
        }

        //
        // POST: /Account/ResetPassword
        [HttpPost]
        [Authorize(Roles = "HOD,Admin")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ResetPassword(ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var user = await UserManager.FindByIdAsync(model.UserId);
            if (user == null)
            {
                // Don't reveal that the user does not exist
                return RedirectToAction("ResetPasswordConfirmation", "Account");
            }
            await UserManager.RemovePasswordAsync(user.Id);
            var result = await UserManager.AddPasswordAsync(user.Id, model.ConfirmPassword);
            if (result.Succeeded)
            {
                if (string.IsNullOrEmpty(model.DId))
                {
                    return Redirect("/Admin/Index");
                }
                else
                {
                    return Redirect("/Utilities/Settings/" + model.DId);
                }
            }
            AddErrors(result);
            return View(model);
        }

        //
        // GET: /Account/ResetPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ResetPasswordConfirmation()
        {
            return View();
        }

        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        //
        // GET: /Account/ResetPasswordConfirmation
        [AllowAnonymous]
        public ActionResult Expired()
        {
            return View();
        }

        //
        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            LoginViewModel lvm = new LoginViewModel();
            try
            {
                Captcha c = Utility.GenerateCaptchaImage();
                Session["cot_captcha_verify"] = c.txt;
                lvm.ImgCaptcha = c.image;
                if (Request.IsAuthenticated)
                {
                    if (string.IsNullOrEmpty(returnUrl))
                    {
                        return RedirectToLocal("/Home/Index");
                    }
                    else
                    {
                        return RedirectToLocal(returnUrl);
                    }
                }
                else
                {
                    if (Request.Cookies["email"] != null)
                    {
                        lvm.Email = Request.Cookies["email"].Value;
                    }
                    if (Request.Cookies["passwd"] != null)
                    {
                        lvm.Password = Request.Cookies["passwd"].Value;
                    }
                    if (Request.Cookies["rememberme"] != null)
                    {
                        int rememberme = 0;
                        int.TryParse(Request.Cookies["rememberme"].Value, out rememberme);
                        lvm.RememberMe = rememberme > 0;
                        
                    }
                }

            }
            catch (Exception e)
            {

            }
            
            ViewBag.ReturnUrl = returnUrl;
            
            return View(lvm);
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl)
        {
            ViewBag.Attempt = 0;
            if (!ModelState.IsValid)
            {
                ViewBag.Attempt = 1;
                return View(model);
            }

            try
            {
                if (Session["cot_captcha_verify"] != null && !Session["cot_captcha_verify"].Equals(model.Captcha + ""))
                {
                    ModelState.AddModelError("Captcha", "Invalid Captcha.");
                    ViewBag.Attempt = 1;
                    return View(model);
                }
            }
            catch (Exception ce)
            {
                try
                {
                    Captcha c = Utility.GenerateCaptchaImage();
                    Session["cot_captcha_verify"] = c.txt;
                    model.ImgCaptcha = c.image;
                }
                catch (Exception cge)
                {

                }
                ModelState.AddModelError("Captcha", "Invalid Captcha.");
                ViewBag.Attempt = 1;
                return View(model);
            }
            // This doesn't count login failures towards account lockout
            // To enable password failures to trigger account lockout, change to shouldLockout: true

            // To enable password failures to trigger account lockout, change to shouldLockout: true
            using (eLogSheetEntities db = new eLogSheetEntities())
            {
                AspNetUser user = db.AspNetUsers
                    .Where(u => u.UserName.Equals(model.Email))
                    .FirstOrDefault();

                if(user!=null && !string.IsNullOrEmpty(user.DId))
                {
                    //
                    //Checking for the account activation
                    //
                    try
                    {
                        string status = EncryptionHelper.Decrypt(user.M3, user.DId);
                        if (string.IsNullOrEmpty(status) || status.Equals("Deactivated"))
                        {
                            return Redirect("/Account/Expired");
                        }
                        DateTime sd = DateTime.ParseExact(EncryptionHelper.Decrypt(user.M1, user.DId), "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        DateTime ed = DateTime.ParseExact(EncryptionHelper.Decrypt(user.M2, user.DId), "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        if (DateTime.Now >= sd && DateTime.Now <= ed)
                        {
                            //Activated Account
                        }
                        else
                        {
                            user.M3 = EncryptionHelper.Encrypt("Deactivated", user.DId);
                            db.Entry(user).State = EntityState.Modified;
                            db.SaveChanges();
                            return Redirect("/Account/Expired");
                        }
                    }
                    catch (Exception exx)
                    {

                    }

                    //
                    //Checking for the account activation
                    //
                }
            }


            var result = await SignInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, shouldLockout: false);
            switch (result)
            {
                case SignInStatus.Success:
                    if (model.RememberMe)
                    {
                        HttpCookie email = new HttpCookie("email", model.Email);
                        email.Expires = DateTime.Now.AddDays(30);
                        HttpCookie passwd = new HttpCookie("passwd", model.Password);
                        passwd.Expires = DateTime.Now.AddDays(30);
                        HttpCookie rememberme = new HttpCookie("rememberme", "1");
                        rememberme.Expires = DateTime.Now.AddDays(30);
                        Response.Cookies.Add(email);
                        Response.Cookies.Add(passwd);
                        Response.Cookies.Add(rememberme);
                    }
                    else
                    {
                        HttpCookie email = new HttpCookie("email", string.Empty);
                        email.Expires = DateTime.Now.AddDays(-1);
                        HttpCookie passwd = new HttpCookie("passwd", string.Empty);
                        passwd.Expires = DateTime.Now.AddDays(-1);
                        HttpCookie rememberme = new HttpCookie("rememberme", string.Empty);
                        rememberme.Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies.Add(email);
                        Response.Cookies.Add(passwd);
                        Response.Cookies.Add(rememberme);
                    }
                    //
                    //Login Success
                    using (eLogSheetEntities db = new eLogSheetEntities())
                    {
                        AspNetUser user = db.AspNetUsers
                            .Where(u => u.UserName.Equals(model.Email))
                            .FirstOrDefault();
                        user.LastLogin = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        user.LastLoginIP = Utility.GetIpAddress();
                        user.UserAgent = Request.UserAgent;
                        db.Entry(user).State = EntityState.Modified;
                        db.SaveChanges();
                    }

                    //
                    //

                    return RedirectToLocal(returnUrl);
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.RequiresVerification:
                    return RedirectToAction("SendCode", new { ReturnUrl = returnUrl, RememberMe = model.RememberMe });
                case SignInStatus.Failure:
                default:
                    ViewBag.Attempt = 1;
                    ModelState.AddModelError("Invalid", "Invalid login attempt.");
                    return View(model);
            }
        }

        //
        // GET: /Account/VerifyCode
        [AllowAnonymous]
        public async Task<ActionResult> VerifyCode(string provider, string returnUrl, bool rememberMe)
        {
            // Require that the user has already logged in via username/password or external login
            if (!await SignInManager.HasBeenVerifiedAsync())
            {
                return View("Error");
            }
            return View(new VerifyCodeViewModel { Provider = provider, ReturnUrl = returnUrl, RememberMe = rememberMe });
        }

        //
        // POST: /Account/VerifyCode
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> VerifyCode(VerifyCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // The following code protects for brute force attacks against the two factor codes. 
            // If a user enters incorrect codes for a specified amount of time then the user account 
            // will be locked out for a specified amount of time. 
            // You can configure the account lockout settings in IdentityConfig
            var result = await SignInManager.TwoFactorSignInAsync(model.Provider, model.Code, isPersistent:  model.RememberMe, rememberBrowser: model.RememberBrowser);
            switch (result)
            {
                case SignInStatus.Success:
                    return RedirectToLocal(model.ReturnUrl);
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.Failure:
                default:
                    ModelState.AddModelError("", "Invalid code.");
                    return View(model);
            }
        }

        //[Authorize(Roles = "HOD,Admin")]
        // GET: /Account/Register
        [AllowAnonymous]
        public ActionResult CreateUser(string id)
        {
            return View(new RegisterViewModel { 
            DId = id
        });
        }
        //
        // POST: /Account/Register
        [HttpPost]
        //[Authorize(Roles = "HOD, Admin")]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> CreateUser(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser { UserName = model.UserName, Email = model.Email };
                var result = await UserManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    //
                    //Create Profile For Entity
                    //
                    using (eLogSheetEntities db = new eLogSheetEntities())
                    {
                        AspNetUser user2update = (from u in db.AspNetUsers
                                                  where u.UserName.Equals(model.UserName)
                                                  select u)
                                                  .FirstOrDefault();
                        if (user2update != null)
                        {
                            user2update.EmailConfirmed = false;
                            user2update.LockoutEnabled = false;
                            user2update.PhoneNumber = model.Mobile;
                            user2update.Designation = model.Designation;
                            user2update.FullName = model.Name;
                            user2update.DId = model.DId;
                            db.Entry(user2update).State = EntityState.Modified;
                            db.SaveChanges();
                            _indentityManager.AddUserToRole(user2update.Id, model.RoleName);
                        }
                    }
                    //
                    //Sending Confirmation Email/SMS
                    //
                    //await SignInManager.SignInAsync(user, isPersistent:false, rememberBrowser:false);
                    // For more information on how to enable account confirmation and password reset please visit https://go.microsoft.com/fwlink/?LinkID=320771
                    // Send an email with this link
                    model = new RegisterViewModel();
                    model.errorMsg = "";
                    model.successMsg = "User successfully created. User need to verify email before he/she login for the first time. Thanks.";
                    if(string.IsNullOrEmpty(model.DId))
                    {
                        return Redirect("/Admin/Index");
                    }
                    else
                    {
                        return Redirect("/Utilities/Settings/" + model.DId);
                    }
                    
                }
                AddErrors(result);
            }
            // If we got this far, something failed, redisplay form
            return View(model);
        }

        [Authorize(Roles = "HOD,Admin")]
        //
        // GET: /Account/Register
        public ActionResult EditUser(string id)
        {
            RegisterViewModel model = new RegisterViewModel();
            using (eLogSheetEntities db = new eLogSheetEntities())
            {
                sp_GetUserDetails_Result user = 
                    db.sp_GetUserDetails(id)
                    .FirstOrDefault();
                if(user!=null)
                {
                    model = new RegisterViewModel
                    {
                        Id = user.Id,
                        DId = user.DId,
                        RoleName = user.RLE,
                        Email = user.Email,
                        Mobile = user.PhoneNumber,
                        Name = user.FullName,
                        Designation = user.Designation
                    };
                }
                
            }
            return View(model);
        }

        //
        // POST: /Account/Register
        [HttpPost]
        [Authorize(Roles = "HOD,Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult EditUser(RegisterViewModel model)
        {
            //
            //Create Profile For Entity
            //
            using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    AspNetUser user2update = (from u in db.AspNetUsers
                                              where u.Email.Equals(model.Email)
                                              select u)
                                              .FirstOrDefault();
                    if (user2update != null)
                    {
                        user2update.PhoneNumber = model.Mobile;
                        user2update.Designation = model.Designation;
                        user2update.Email = model.Email;
                        user2update.FullName = model.Name;
                        db.Entry(user2update).State = EntityState.Modified;
                        db.SaveChanges();
                        _indentityManager.AddUserToRole(user2update.Id, model.RoleName);
                }
                if (string.IsNullOrEmpty(model.DId))
                {
                    return Redirect("/Admin/Index");
                }
                else
                {
                    return Redirect("/Utilities/Settings/" + model.DId);
                }
            }
            // If we got this far, something failed, redisplay form
        }

        [Authorize(Roles = "HOD,Admin")]
        //
        // GET: /Account/Register
        public ActionResult DeleteUser(string id)
        {
            RegisterViewModel model = new RegisterViewModel();
            using (eLogSheetEntities db = new eLogSheetEntities())
            {
                model = db.AspNetUsers
                        .Where(p => p.Id.Equals(id))
                        .Select(p => new RegisterViewModel
                        {
                            Id = p.Id,
                            DId = p.DId,
                            Email = p.Email,
                            Mobile = p.PhoneNumber,
                            Name = p.FullName,
                            Designation = p.Designation
                        }).FirstOrDefault();
            }
            return View(model);
        }

        //
        // POST: /Account/Register
        [HttpPost]
        [Authorize(Roles = "HOD,Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteUser(RegisterViewModel model)
        {
            //
            //Create Profile For Entity
            //
            using (eLogSheetEntities db = new eLogSheetEntities())
            {
                AspNetUser user2update = (from u in db.AspNetUsers
                                          where u.Id.Equals(model.Id)
                                          select u)
                                          .FirstOrDefault();
                if (user2update != null)
                {
                    db.AspNetUsers.Remove(user2update);
                    db.SaveChanges();
                }
                if (string.IsNullOrEmpty(model.DId))
                {
                    return Redirect("/Admin/Index");
                }
                else
                {
                    return Redirect("/Utilities/Settings/" + model.DId);
                }
            }
        }

        //
        // GET: /Account/ConfirmEmail
        [AllowAnonymous]
        public ActionResult ConfirmEmail(string userId, string code)
        {
            if (userId == null || code == null)
            {
                return View("Error");
            }
            using (eLogSheetEntities cevEntities = new eLogSheetEntities())
            {
                Verification verification =
                        (from u in cevEntities.Verifications
                         where u.CallBackUrl.IndexOf(code) > 0 && u.CallBackUrl.IndexOf(userId) > 0
                         select u)
                        .FirstOrDefault();

                if (verification != null && verification.Used <= 0)
                {

                    AspNetUser user2update = (from u in cevEntities.AspNetUsers
                                              where u.Id.Equals(userId)
                                              select u)
                                              .FirstOrDefault();
                    if (user2update != null)
                    {

                        verification.Used = 1;
                        cevEntities.Entry(verification).State = EntityState.Modified;

                        user2update.EmailConfirmed = true;
                        cevEntities.Entry(user2update).State = EntityState.Modified;

                        cevEntities.SaveChanges();
                        _indentityManager.AddUserToRole(user2update.Id, "Owner");

                        ConfirmationModelView cmv = new ConfirmationModelView();
                        cmv.ContactName = user2update.FullName;
                        cmv.UserName = user2update.UserName;

                        COTEmail mail = new COTEmail();
                        mail.Body = "";
                        mail.Subject = "Account Created";
                        mail.Receiver = user2update.Email;
                        if (!string.IsNullOrEmpty(mail.Receiver))
                        {
                            COTMailer.SendAccountConfirmation(mail, user2update.FullName, EncryptionHelper.Decrypt(user2update.SCode, "ePractice"));
                        }
                    }
                    return View("ConfirmEmail");
                }
                else
                {
                    return View("Error");
                }
            }
        }

        //
        // GET: /Account/ForgotPassword
        [AllowAnonymous]
        public ActionResult ForgotPassword()
        {
            return View();
        }

        //
        // POST: /Account/ForgotPassword
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ForgotPassword(ForgotPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                //Send Password Reset Link
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    AspNetUser user2update = (from u in db.AspNetUsers
                                              where u.Email.Equals(model.Email)
                                              select u)
                    .FirstOrDefault();
                    if (user2update != null)
                    {
                        //Send Email Confirmation Link
                        //
                        var callbackUrl = Url.Action("ResetPassword", "Account", new { userId = user2update.Id, code = Guid.NewGuid().ToString("n") }, protocol: Request.Url.Scheme);

                        Verification verification = new Verification();
                        verification.CallBackUrl = callbackUrl;
                        verification.Used = 0;
                        verification.IpAddress = Utility.GetIpAddress();
                        verification.UserAgent = Request.UserAgent;
                        
                        verification.UserName = user2update.UserName;
                        verification.CreatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        verification.ExpiringOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE).AddDays(1);
                        db.Verifications.Add(verification);
                        db.SaveChanges();

                        COTEmail mail = new COTEmail();
                        mail.Subject = "Password Reset";
                        mail.Receiver = model.Email;
                        if (!string.IsNullOrEmpty(mail.Receiver))
                        {
                            COTMailer.SendPasswordResetLink(mail, user2update.UserName, callbackUrl);
                        }
                    }
                }
                return View("ForgotPasswordConfirmation");
            }
            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/ForgotPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ForgotPasswordConfirmation()
        {
            return View();
        }

        
        //
        // POST: /Account/ExternalLogin
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ExternalLogin(string provider, string returnUrl)
        {
            // Request a redirect to the external login provider
            return new ChallengeResult(provider, Url.Action("ExternalLoginCallback", "Account", new { ReturnUrl = returnUrl }));
        }

        //
        // GET: /Account/SendCode
        [AllowAnonymous]
        public async Task<ActionResult> SendCode(string returnUrl, bool rememberMe)
        {
            var userId = await SignInManager.GetVerifiedUserIdAsync();
            if (userId == null)
            {
                return View("Error");
            }
            var userFactors = await UserManager.GetValidTwoFactorProvidersAsync(userId);
            var factorOptions = userFactors.Select(purpose => new SelectListItem { Text = purpose, Value = purpose }).ToList();
            return View(new SendCodeViewModel { Providers = factorOptions, ReturnUrl = returnUrl, RememberMe = rememberMe });
        }

        //
        // POST: /Account/SendCode
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> SendCode(SendCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            // Generate the token and send it
            if (!await SignInManager.SendTwoFactorCodeAsync(model.SelectedProvider))
            {
                return View("Error");
            }
            return RedirectToAction("VerifyCode", new { Provider = model.SelectedProvider, ReturnUrl = model.ReturnUrl, RememberMe = model.RememberMe });
        }

        //
        // GET: /Account/ExternalLoginCallback
        [AllowAnonymous]
        public async Task<ActionResult> ExternalLoginCallback(string returnUrl)
        {
            var loginInfo = await AuthenticationManager.GetExternalLoginInfoAsync();
            if (loginInfo == null)
            {
                return RedirectToAction("Login");
            }

            // Sign in the user with this external login provider if the user already has a login
            var result = await SignInManager.ExternalSignInAsync(loginInfo, isPersistent: false);
            switch (result)
            {
                case SignInStatus.Success:
                    return RedirectToLocal(returnUrl);
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.RequiresVerification:
                    return RedirectToAction("SendCode", new { ReturnUrl = returnUrl, RememberMe = false });
                case SignInStatus.Failure:
                default:
                    // If the user does not have an account, then prompt the user to create an account
                    ViewBag.ReturnUrl = returnUrl;
                    ViewBag.LoginProvider = loginInfo.Login.LoginProvider;
                    return View("ExternalLoginConfirmation", new ExternalLoginConfirmationViewModel { Email = loginInfo.Email });
            }
        }

        //
        // POST: /Account/ExternalLoginConfirmation
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ExternalLoginConfirmation(ExternalLoginConfirmationViewModel model, string returnUrl)
        {
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Manage");
            }

            if (ModelState.IsValid)
            {
                // Get the information about the user from the external login provider
                var info = await AuthenticationManager.GetExternalLoginInfoAsync();
                if (info == null)
                {
                    return View("ExternalLoginFailure");
                }
                var user = new ApplicationUser { UserName = model.Email, Email = model.Email };
                var result = await UserManager.CreateAsync(user);
                if (result.Succeeded)
                {
                    result = await UserManager.AddLoginAsync(user.Id, info.Login);
                    if (result.Succeeded)
                    {
                        await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
                        return RedirectToLocal(returnUrl);
                    }
                }
                AddErrors(result);
            }

            ViewBag.ReturnUrl = returnUrl;
            return View(model);
        }

        //
        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            Session.Clear();
            Session.Abandon();

            Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));
            HttpCookie email = new HttpCookie("email", string.Empty);
            email.Expires = DateTime.Now.AddDays(-1);
            HttpCookie passwd = new HttpCookie("passwd", string.Empty);
            passwd.Expires = DateTime.Now.AddDays(-1);
            HttpCookie rememberme = new HttpCookie("rememberme", string.Empty);
            rememberme.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(email);
            Response.Cookies.Add(passwd);
            Response.Cookies.Add(rememberme);
            AuthenticationManager.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
            return RedirectToAction("Index", "Home");
        }

        //
        // GET: /Account/ExternalLoginFailure
        [AllowAnonymous]
        public ActionResult ExternalLoginFailure()
        {
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_userManager != null)
                {
                    _userManager.Dispose();
                    _userManager = null;
                }

                if (_signInManager != null)
                {
                    _signInManager.Dispose();
                    _signInManager = null;
                }
            }

            base.Dispose(disposing);
        }

        #region Helpers
        // Used for XSRF protection when adding external logins
        private const string XsrfKey = "XsrfId";

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (User.IsInRole("Admin"))
            {
                return RedirectToAction("Index", "Administrator");
            }
            else if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        internal class ChallengeResult : HttpUnauthorizedResult
        {
            public ChallengeResult(string provider, string redirectUri)
                : this(provider, redirectUri, null)
            {
            }

            public ChallengeResult(string provider, string redirectUri, string userId)
            {
                LoginProvider = provider;
                RedirectUri = redirectUri;
                UserId = userId;
            }

            public string LoginProvider { get; set; }
            public string RedirectUri { get; set; }
            public string UserId { get; set; }

            public override void ExecuteResult(ControllerContext context)
            {
                var properties = new AuthenticationProperties { RedirectUri = RedirectUri };
                if (UserId != null)
                {
                    properties.Dictionary[XsrfKey] = UserId;
                }
                context.HttpContext.GetOwinContext().Authentication.Challenge(properties, LoginProvider);
            }
        }
        #endregion
    }
}
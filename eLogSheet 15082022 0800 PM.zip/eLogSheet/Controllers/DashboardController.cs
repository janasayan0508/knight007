﻿using eLogSheet.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace eLogSheet.Controllers
{
    [Authorize()]
    public class DashboardController : Controller
    {
        // GET: Dashboard
        public ActionResult Index(string dt)
        {
            return View(new DashboardView(User.Identity.Name, dt));
        }
    }
}
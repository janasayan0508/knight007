﻿using eLogSheet.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace eLogSheet.Controllers
{
    public class DataEntryController : Controller
    {
        // GET: DataEntry
        public ActionResult Index(int did, string dt)
        {
            return View(new SheetView(User.Identity.Name, dt, did));
        }

        public ActionResult Settings(int did)
        {
            return View(did);
        }
    }
}
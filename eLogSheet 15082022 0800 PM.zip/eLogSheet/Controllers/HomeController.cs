﻿using eLogSheet.Models;
using eLogSheet.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace eLogSheet.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {

        public ActionResult Index()
        {
            if (User.IsInRole("HOD") || User.IsInRole("CGM") || User.IsInRole("ED") ||  User.IsInRole("DIC"))
            {
                return Redirect("/Dashboard/Index");
            }
            else if (User.IsInRole("Admin"))
            {
                return Redirect("/Admin/Index");
            }
            return View();
        }

        public ActionResult Users()
        {
            return View();
        }

    }
}
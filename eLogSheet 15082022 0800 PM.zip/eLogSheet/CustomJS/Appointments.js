﻿(function () {
    var app = angular.module('HMSApp', []);
    app.controller('HMSController', ['$scope', '$http', '$filter', function ($scope, $http, $filter) {

        $scope.ConnectionStarted = false;

        $scope.disabledDates = {};

        //toaster options
        toastr.options = { 'closeButton': 'true', 'debug': false, 'newestOnTop': true, 'progressBar': true, 'positionClass': 'toast-bottom-left', 'preventDuplicates': true, 'onclick': null, 'showDuration': '5000', 'hideDuration': '1200', 'timeOut': '2000', 'extendedTimeOut': '1500', 'showEasing': 'swing', 'hideEasing': 'linear', 'showMethod': 'fadeIn', 'hideMethod': 'fadeOut' };
        $scope.toastr_title = 'ePractice Powered by GPRN!';

        $scope.appEvents = [];
        
        $scope.clinicHub = $.connection.clinicHub; // initializes hub
        $scope.ConnectionStarted = false;

        $scope.FC_CV_MIN_DT = '';
        $scope.FC_CV_MAX_DT = '';
        $scope.cdtaList = [];

        $scope.mdl_title = '';
        $scope.dateInfo = {};
        $scope.sList = {};

        $('form.bv-form').each(function () {
            var frmId = $(this).attr('id');
            $('#' + frmId + ' .form-control').on("blur, change", function () {
                var nm = $(this).attr('name');
                $('#' + frmId + '').bootstrapValidator('revalidateField', nm);
            });
        });


        $scope.ValidateFormById = function (frmId) {
            $('#' + frmId + ' .form-control').each(function () {
                var nm = $(this).attr('name');
                $('#' + frmId + '').bootstrapValidator('revalidateField', nm);
            });
        };

        $scope.settings = {};

        $scope.patient = null;
        
        $scope.appCalendar = {};
        $scope.sDate = '';
        $scope.sDateTime = '';
        $scope.event = {};
        $scope.Department = '';
        $scope.Doctor = '';

        var today = new Date();
        today.setDate(today.getDate() - 1);
        $scope.NewApptAllowed = true;
        $scope.model = {};
        $scope.NewApptAllowed = true;
        $scope.appEvents = [];
        $scope.cdhList = [];

        $scope.NoAppointmentReason = '';

        angular.element(document).ready(function () {

            $scope.appCalendar = new FullCalendar.Calendar($('div#calendar')[0], {
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                initialView: 'timeGridWeek',
                initialDate: new Date(),
                slotMinTime: "09:00:00",
                slotMaxTime: "19:00:00",
                slotLabelFormat: {
                    hour: '2-digit',
                    minute: '2-digit',
                    omitZeroMinute: false,
                    meridiem: 'short'
                },
                slotDuration: '00:15:00',
                slotLabelInterval: 15,
                snapDuration: '00:05:00',
                defaultTimedEventDuration: '00:40',
                editable: true,
                eventAllow: function (dropInfo, draggedEvent) {
                    return true;
                },
                eventDrop: function (info) {
                    $scope.$evalAsync(function () {
                        
                        if (info.view.type !== 'dayGridMonth') {
                            //alert(JSON.stringify(info));
                            var index = _.findIndex($scope.dtaList, {
                                Id: parseInt(info.event.id, 10)
                            });
                            if (index >= 0 && $scope.dtaList[index].AttendedOn !== null) {
                                toastr['error']('Patient already attended, can not be moved!', $scope.toastr_title);
                                info.revert();
                            }
                            else if (info.event.start < moment())
                            {
                                toastr['error']('Can not moved to past date!', $scope.toastr_title);
                                info.revert();
                            }
                            else {
                                $scope.NoAppointmentReason = '';
                                $scope.NewApptAllowed = info.event.start >= moment();
                                if (!$scope.NewApptAllowed) {
                                    $scope.NoAppointmentReason = 'Past Date\n';
                                }

                                var dayofweek = $filter('date')(info.event.start, 'EEE').toLowerCase();

                                $scope.NewApptAllowed = $scope.NewApptAllowed && !(($scope.settings.WeeklyOff + '').toLowerCase().indexOf(dayofweek) >= 0);

                                if (($scope.settings.WeeklyOff + '').toLowerCase().indexOf(dayofweek) >= 0) {
                                    $scope.NoAppointmentReason += 'Clinic Weekly Off (' + dayofweek + ')\n';
                                }

                                $scope.cdhList = _.filter($scope.dthList, function (a) {
                                    var endDate = new Date(a.ChEndDt);
                                    var startDate = new Date(a.ChStartDt);
                                    return info.event.start >= startDate && info.event.start <= endDate;
                                });

                                for (var j in $scope.cdhList) {
                                    $scope.NoAppointmentReason += '\n' + $scope.cdhList[j].ChReason + ' (' + $filter('date')($scope.cdhList[j].ChStartDt, 'dd/MM/yyyy') + '-' + $filter('date')($scope.cdhList[j].ChEndDt, 'dd/MM/yyyy') + ')\n';
                                }

                                $scope.NewApptAllowed = $scope.NewApptAllowed && !($scope.cdhList.length > 0);
                                if ($scope.NewApptAllowed || $scope.cdtaList.length > 0) {
                                    var r = confirm('Are you sure to change appointment of ' + info.oldEvent.title + ' from ' + info.oldEvent.start + ' to ' + info.event.start);
                                    if (r) {
                                        $scope.event = $scope.dtaList[index];
                                        $scope.event.ApptDate = $filter('date')(info.event.start, 'yyyy-MM-dd H:mm:ss');
                                        $scope.event.ADATE = $filter('date')(info.event.start, 'yyyy-MM-dd H:mm:ss');
                                        $scope.UpdateEventInfo($scope.model.U.U);
                                    }
                                    else {
                                        toastr['info']('Modification Cancelled by User!', $scope.toastr_title);
                                        info.revert();
                                    }
                                }
                                else {
                                    toastr['error']('No Appointment Allowed: ' + $filter('date')(info.event.start, 'dd/MM/yyyy') + $scope.NoAppointmentReason, $scope.toastr_title);
                                    info.revert();
                                }
                            }
                            
                        }
                        else {
                            toastr['info']('Modification not allowd in this view!', $scope.toastr_title);
                            info.revert();
                        }
                    });
                },
                eventResize: function (info) {
                    $scope.$evalAsync(function () {

                        if (info.view.type !== 'dayGridMonth') {
                            //alert(JSON.stringify(info));
                            if (info.event.end >= moment()) {
                                var r = confirm('Are you sure to modify appointment of ' + info.oldEvent.title + ' from ' + info.oldEvent.start + ' to ' + info.event.end);
                                if (r) {
                                    $scope.event = {};
                                    $scope.event.Id = info.event.id;
                                    $scope.event.DId = info.event.DId;
                                    $scope.event.ApptDate = $filter('date')(info.event.start, 'yyyy-MM-dd H:mm:ss');
                                    $scope.event.ApptEndDate = $filter('date')(info.event.end, 'yyyy-MM-dd H:mm:ss');
                                    $scope.event.ADATE = $filter('date')(info.event.start, 'yyyy-MM-dd H:mm:ss');
                                    $scope.UpdateEventInfo($scope.model.U.U);
                                }
                                else {
                                    toastr['info']('Resize Cancelled by User!', $scope.toastr_title);
                                    info.revert();
                                }
                            }
                            else {
                                info.revert();
                            }
                            
                        }
                        else {
                            toastr['info']('Modification not allowd in this view!', $scope.toastr_title);
                            info.revert();
                        }
                    });
                },
                navLinks: false, // can click day/week names to navigate views
                dayMaxEvents: true, // allow "more" link when too many events
                eventOverlap: false,
                events: [],
                loading: function (bool) {
                    $scope.$evalAsync(function () {
                        if (bool) {

                        }
                        else {
                            $scope.FC_CV_MIN_DT = $('div#calendar .fc-daygrid-day:first').attr('data-date');
                            $scope.FC_CV_MAX_DT = $('div#calendar .fc-daygrid-day:last').attr('data-date');

                            $('#calendar td.fc-day-' + $scope.settings.WeeklyOff).css('background-color', '#F1F29A');
                            //
                            //toastr['success']('Calendar Loaded ' + $('div#calendar .fc-daygrid-day:first').attr('data-date') + '', $scope.toastr_title);
                        }
                    });
                },
                eventClick: function (info) {
                    $scope.$evalAsync(function () {

                        $scope.NoAppointmentReason = '';
                        $scope.NewApptAllowed = info.event.start >= moment();
                        if (!$scope.NewApptAllowed) {
                            $scope.NoAppointmentReason = 'Past Date\n';
                        }

                        var dayofweek = $filter('date')(info.event.start, 'EEE').toLowerCase();

                        $scope.NewApptAllowed = $scope.NewApptAllowed && !(($scope.settings.WeeklyOff + '').toLowerCase().indexOf(dayofweek) >= 0);

                        if (($scope.settings.WeeklyOff + '').toLowerCase().indexOf(dayofweek) >= 0) {
                            $scope.NoAppointmentReason += 'Clinic Weekly Off (' + dayofweek + ')\n';
                        }

                        $scope.cdhList = _.filter($scope.dthList, function (a) {
                            var endDate = new Date(a.ChEndDt);
                            var startDate = new Date(a.ChStartDt);
                            return info.event.start >= startDate && info.event.start <= endDate;
                        });

                        for (var j in $scope.cdhList) {
                            $scope.NoAppointmentReason += '\n' + $scope.cdhList[j].ChReason + ' (' + $filter('date')($scope.cdhList[j].ChStartDt, 'dd/MM/yyyy') + '-' + $filter('date')($scope.cdhList[j].ChEndDt, 'dd/MM/yyyy') + ')\n';
                        }

                        $scope.NewApptAllowed = $scope.NewApptAllowed && !($scope.cdhList.length > 0);

                        var index = _.findIndex($scope.dtaList, {
                            Id: parseInt(info.event.id, 10)
                        });
                        if (index >= 0) {
                            $scope.event = Object.assign({}, $scope.dtaList[index]);
                            $scope.sDate = $filter('date')(info.event.start, 'yyyy-MM-dd');
                            $scope.sDateTime = $filter('date')(info.event.start, 'yyyy-MM-dd H:mm:ss');

                            $scope.cdtaList = _.filter($scope.dtaList, function (a) {
                                return $filter('date')(a.ADATE, 'yyyy-MM-dd') === $scope.sDate;
                            });
                            //$('div#mdlAppointment').modal('show');
                            $('.appts_tabs a[href="#modify_visit"]').tab('show');
                        }

                    });
                },
                selectAllow: function (info) {
                    if (info.start.isBefore(moment()))
                        return false;
                    return true;
                },
                dateClick: function (info) {
                    $scope.$evalAsync(function () {

                        $scope.NoAppointmentReason = '';

                        $scope.sDate = $filter('date')(info.date, 'yyyy-MM-dd');
                        $scope.sDateTime = $filter('date')(info.date, 'yyyy-MM-dd H:mm:ss');

                        $scope.NewApptAllowed = info.date >= moment();
                        if (!$scope.NewApptAllowed) {
                            $scope.NoAppointmentReason = 'Past Date\n';
                        }

                        var dayofweek = $filter('date')(info.date, 'EEE').toLowerCase();

                        $scope.NewApptAllowed = $scope.NewApptAllowed && !(($scope.settings.WeeklyOff + '').toLowerCase().indexOf(dayofweek) >= 0);

                        if (($scope.settings.WeeklyOff + '').toLowerCase().indexOf(dayofweek) >= 0) {
                            $scope.NoAppointmentReason += 'Clinic Weekly Off (' + dayofweek + ')\n';
                        }

                        $scope.cdhList = _.filter($scope.dthList, function (a) {
                            var endDate = new Date(a.ChEndDt);
                            var startDate = new Date(a.ChStartDt);
                            return info.date >= startDate && info.date <= endDate;
                        });

                        for (var j in $scope.cdhList) {
                            $scope.NoAppointmentReason += '\n' + $scope.cdhList[j].ChReason + ' (' + $filter('date')($scope.cdhList[j].ChStartDt, 'dd/MM/yyyy') + '-' + $filter('date')($scope.cdhList[j].ChEndDt, 'dd/MM/yyyy') +')\n';
                        }

                        $scope.NewApptAllowed = $scope.NewApptAllowed && !($scope.cdhList.length > 0);
                        
                        if ($scope.NewApptAllowed) {
                            
                            
                            if ($scope.patient.hasOwnProperty('PtName') || $scope.event.hasOwnProperty('PtName')) {
                                $scope.appt.ADATE = $scope.sDate;
                                $scope.appt.ApptDate = $scope.sDateTime;

                                $scope.patient.ADATE = $scope.sDate;
                                $scope.patient.ApptDate = $scope.sDateTime;

                                $scope.event.ADATE = $scope.sDate;
                                $scope.event.ApptDate = $scope.sDateTime;
                            }
                            else {
                                toastr['info']('Booking for Date: ' + $filter('date')(info.date, 'dd/MM/yyyy'), $scope.toastr_title);

                                //$('div#mdlAppointment').modal('show');
                                $('.appts_tabs a[href="#search_patient"]').tab('show');
                                $scope.appt = {};
                                $scope.patient = {};

                                $scope.appt.ADATE = $scope.sDate;
                                $scope.appt.ApptDate = $scope.sDateTime;

                                $scope.patient.ADATE = $scope.sDate;
                                $scope.patient.ApptDate = $scope.sDateTime;

                                $scope.cdtaList = _.filter($scope.dtaList, function (a) {
                                    return $filter('date')(a.ADATE, 'yyyy-MM-dd') === $scope.sDate;
                                });
                            }
                        }
                        else {
                            toastr['error']('No Appointment Allowed: ' + $filter('date')(info.date, 'dd/MM/yyyy') + $scope.NoAppointmentReason, $scope.toastr_title);
                        }
                    });
                }
            });

            $scope.appCalendar.render();

            $scope.model = $.parseJSON($('p#modelData').text());
            $('p#modelData').text('')

            $scope.settings = $.parseJSON($scope.model.C.ClSettings);

            $scope.sList = $.parseJSON($('p#sList').text());
            for (var ic in $scope.sList) {
                $scope.sList[ic].iList = $.parseJSON($scope.sList[ic].JsonStr);
            }
            $('p#sList').text('');

            $scope.Department = $scope.model.D.Department;
            $scope.Doctor = $scope.model.D.FullName;


            $('.datepicker').daterangepicker({
                singleDatePicker: true,
                showDropdowns: true,
                drops: "auto",
                autoUpdateInput: false,
                autoApply: false,
                locale: {
                    format: 'YYYY-MM-DD',
                    cancelLabel: 'Clear'
                }
            });

            $('.datepicker').on('show.daterangepicker', () => {
                $('.daterangepicker').removeClass('auto-apply');
            });
            $('.datepicker').on('cancel.daterangepicker', function (ev, picker) {
                var nm = $(this).attr('name');
                $scope.$evalAsync(function () {
                    $scope.appt[nm] = null;
                });
            });

            $('.datepicker').on('apply.daterangepicker', function (ev, picker) {
                var nm = $(this).attr('name');
                $scope.$evalAsync(function () {
                    $scope.appt[nm] = picker.startDate.format('YYYY-MM-DD');
                });
            });


            $('.datetimepicker1').daterangepicker({
                singleDatePicker: true,
                showDropdowns: true,
                autoUpdateInput: false,
                autoApply: false,
                timePicker: true,
                timePickerIncrement: 5,
                minDate: new Date(),
                timePicker24Hour: true,
                showDropdowns: true,
                locale: {
                    format: 'DD/MM/YYYY',
                    cancelLabel: 'Clear'
                }
            });
            

            $('.datetimepicker1').on('show.daterangepicker', () => {
                $('.daterangepicker').removeClass('auto-apply');
            });


            $('.datetimepicker1').on('cancel.daterangepicker', function (ev, picker) {
                var nm = $(this).attr('name');
                $scope.$evalAsync(function () {
                    $scope.appt[nm] = null;
                    $scope.patient[nm] = null;
                    $scope.appt['ADATE'] = null;
                    $scope.patient['ADATE'] = null;
                    $scope.event[nm] = null;
                });
            });


            $('.datetimepicker1').on('apply.daterangepicker', function (ev, picker) {
                var nm = $(this).attr('name');
                $scope.$evalAsync(function () {

                    $scope.sDate = picker.startDate.format('YYYY-MM-DD');
                    $scope.sDateTime = picker.startDate.format('YYYY-MM-DD H:mm:ss');

                    $scope.appt.ADATE = $scope.sDate;
                    $scope.appt[nm] = $scope.sDateTime;

                    $scope.patient.ADATE = $scope.sDate;
                    $scope.patient[nm] = $scope.sDateTime;

                    $scope.event.ADATE = $scope.sDate;
                    $scope.event[nm] = $scope.sDateTime;

                    $scope.cdtaList = _.filter($scope.dtaList, function (a) {
                        return $filter('date')(a.ADATE, 'yyyy-MM-dd') === $scope.sDate;
                    });

                    //$scope.appCalendar.currentData.calendarOptions.initialDate = new moment(picker.startDate.format('YYYY-MM-DD'));
                    //$scope.appCalendar.render();
                    //$scope.GetAppointmentsListForCalendar();
                });
            });


            $scope.$evalAsync(function () {
                $.connection.hub.start().done(function () {
                    $scope.ConnectionStarted = true;
                    toastr['info']('Hub Started!', $scope.toastr_title);
                    $scope.FC_CV_MIN_DT = $('div#calendar .fc-daygrid-day:first').attr('data-date');
                    $scope.FC_CV_MAX_DT = $('div#calendar .fc-daygrid-day:last').attr('data-date');

                    $('.datetimepicker1').daterangepicker({
                        singleDatePicker: true,
                        showDropdowns: true,
                        autoUpdateInput: false,
                        autoApply: false,
                        timePicker: true,
                        timePickerIncrement: 5,
                        minDateTime: $scope.FC_CV_MIN_DT + " 00:01:00",
                        maxDateTime: $scope.FC_CV_MAX_DT + " 23:59:59",
                        timePicker24Hour: true,
                        showDropdowns: true,
                        locale: {
                            format: 'YYYY-MM-DD',
                            cancelLabel: 'Clear'
                        }
                    });

                    $scope.GetAppointmentsListForDateRange();
                    
                }); // starts hub

            });
        });


        $('div#calendar').on('click', 'button.fc-button', function () {
            $scope.$evalAsync(function () {
                $scope.FC_CV_MIN_DT = $('div#calendar .fc-daygrid-day:first').attr('data-date');
                $scope.FC_CV_MAX_DT = $('div#calendar .fc-daygrid-day:last').attr('data-date');
                toastr['info']('Prev/Next Button Clicked!' + $scope.FC_CV_MIN_DT + '-' + $scope.FC_CV_MAX_DT, $scope.toastr_title);

                $('.datetimepicker1').daterangepicker({
                    singleDatePicker: true,
                    showDropdowns: true,
                    autoUpdateInput: false,
                    autoApply: false,
                    timePicker: true,
                    timePickerIncrement: 5,
                    minDateTime: $scope.FC_CV_MIN_DT + " 00:01:00",
                    maxDateTime: $scope.FC_CV_MAX_DT + " 23:59:59",
                    timePicker24Hour: true,
                    showDropdowns: true,
                    locale: {
                        format: 'YYYY-MM-DD',
                        cancelLabel: 'Clear'
                    }
                });

                $scope.GetAppointmentsListForDateRange();
                //
                
            });
        });

        //
        //Manage Events CRUD
        //


        $scope.ModifyEventInfo = function (ev2update) {
            $scope.$evalAsync(function () {
                var r = confirm('Are you sure to modify appointment for: ' + ev2update.PtName + '?');
                if (r) {
                    $scope.event = Object.assign({}, ev2update);
                }
            });
        };

        $scope.UpdateEventInfo = function (user) {
            $scope.appt.DId = $scope.model.C.Id;
            $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
            if (!$scope.ConnectionStarted) {
                $.connection.hub.start().done(function () {
                    $scope.ConnectionStarted = true;
                    $scope.UpdateEventInformation(user);
                });
            }
            else {
                $scope.UpdateEventInformation(user);
            }
        };
        $scope.UpdateEventInformation = function (user) {
            $scope.clinicHub.server.updateEventInformation(user, JSON.stringify($scope.event)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $scope.event = {};
                        toastr['success']('Appointment Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Appointment information!', $scope.toastr_title);
                    }
                });
            });
        };

        $scope.DeleteEventInfo = function (user, event) {
            var r = confirm('Are you sure to modify appointment for: ' + event.PtName + '?');
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteEventInformation(user, event);
                    });
                }
                else {
                    $scope.DeleteEventInformation(user, event);
                }
            }
            
        };
        $scope.DeleteEventInformation = function (user, event) {
            $scope.clinicHub.server.deleteEventInformation(user, JSON.stringify(event)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $scope.event = {};
                        toastr['success']('Appt deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Appt information!', $scope.toastr_title);
                    }
                });
            });
        };

        //
        //Manage Events CRUD
        //



        //
        //Clinic Holidays
        //

        $scope.GetClinicHolidaysListForDateRange = function () {
            $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
            if (!$scope.ConnectionStarted) {
                $.connection.hub.start().done(function () {
                    $scope.ConnectionStarted = true;
                    $scope.GetClinicHolidaysList();
                });
            }
            else {
                $scope.GetClinicHolidaysList();
            }
        };

        $scope.clHoliday = {};
        $scope.GetClinicHolidaysList = function () {
            $scope.clinicHub.server.getClinicHolidaysForDateRange($scope.model.C.Id, $scope.FC_CV_MIN_DT, $scope.FC_CV_MAX_DT).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data !== "") {
                        $scope.dthList = $.parseJSON(data);
                        //toastr['success']($scope.dthList.length + ' Clinic Holidays found!', $scope.toastr_title);
                        $scope.RefreshCalendarEvents();
                    }
                    else {
                        toastr['error']('Error in getting Clinic Holiday information!', $scope.toastr_title);
                    }
                });

            });
        };
        $scope.appEvents = [];

        $scope.RefreshClinicHolidaysSource = function () {
            $scope.$evalAsync(function () {
                
                $scope.appCalendar.removeAllEvents();
                $scope.appCalendar.addEventSource($scope.appEvents);
                $scope.RefreshClinicHolidaysTable();
            });
        };

        $scope.clinicHub.client.refreshClinicHolidays = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data !== null && data != undefined && data.DId === $scope.model.C.Id) {
                    var index = _.findIndex($scope.dthList, {
                        Id: data.Id
                    });
                    if (index >= 0) {
                        $scope.dthList[index] = data;
                        toastr['success']('Holidays Refreshed Successfully!', $scope.toastr_title);
                    }
                    else {
                        $scope.dthList.push(data);
                    }
                    $scope.RefreshCalendarEvents();
                }

            });
        };

        $scope.clinicHub.client.refreshClinicHolidaysAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data !== null && data != undefined && data.DId === $scope.model.C.Id) {
                    var index = _.findIndex($scope.dthList, {
                        Id: data.Id
                    });
                    if (index >= 0) {
                        $scope.dthList.splice(index, 1);
                        toastr['success']('Holidays Refreshed Successfully!', $scope.toastr_title);
                    }
                    $scope.RefreshCalendarEvents();
                }
            });
        };

        //
        //Clinic Holidays
        //

        //
        //Appointments & Patients
        //

        $scope.AddNewPatient = function () {
            $scope.$evalAsync(function () {
                $scope.ShowRegistrationForm = true;
                $scope.patient = {};
                $scope.patient.PtDepartment = $scope.Department;
                $scope.patient.PtDoctor = $scope.Doctor;
                $scope.patient.PtDoctor = $scope.Doctor;
                $scope.patient.PtGender = "Female";
                $scope.patient.DId = $scope.model.C.Id;
                $scope.patient.ADATE = $scope.sDate;
                $scope.patient.ApptDate = $scope.sDateTime;
                $('.appts_tabs a[href="#schedule_visit"]').tab('show');
            });
        };

        $scope.spList = [];
        $scope.GetPatientListForSearchText = function () {
            if ($scope.frmSearch.$valid) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.GetPatientList();
                    });
                }
                else {
                    $scope.GetPatientList();
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };

        $scope.GetPatientList = function () {
            $scope.clinicHub.server.getPatientListForSearchText($scope.SearchTxt, $scope.model.C.Id).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data !== "") {
                        $scope.spList = $.parseJSON(data);
                        toastr['success']($scope.spList.length + ' patients found!', $scope.toastr_title);
                        $scope.RefreshPatientList();
                    }
                    else {
                        toastr['error']('Error in getting patient information!', $scope.toastr_title);
                    }
                });

            });
        };

        $scope.dtaList = [];
        $scope.GetAppointmentsListForDateRange = function () {
            $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
            if (!$scope.ConnectionStarted) {
                $.connection.hub.start().done(function () {
                    $scope.ConnectionStarted = true;
                    $scope.GetAppointmentsList();
                });
            }
            else {
                $scope.GetAppointmentsList();
            }
        };

        $scope.appt = {};
        $scope.GetAppointmentsList = function () {
            
            $scope.clinicHub.server.getAppointmentsForDateRange($scope.model.C.Id, $scope.FC_CV_MIN_DT, $scope.FC_CV_MAX_DT, '').done(function (data) {
                $scope.$evalAsync(function () {
                    if (data !== "") {
                        $scope.dtaList = $.parseJSON(data);
                        toastr['success']($scope.dtaList.length + ' appointments found!', $scope.toastr_title);
                        $scope.GetClinicHolidaysListForDateRange();
                    }
                    else {
                        toastr['error']('Error in getting appointment information!', $scope.toastr_title);
                    }
                });
                
            });
        };
        $scope.appEvents = [];

        
        $scope.RefreshCalendarEvents = function () {
            $scope.$evalAsync(function () {
                $scope.appEvents = [];
                for (var j in $scope.dtaList) {
                    $scope.appEvents.push({
                        id: $scope.dtaList[j].Id,
                        cid: $scope.dtaList[j].DId,
                        title: $scope.dtaList[j].ApptPurpose + ' | ' + $scope.dtaList[j].PtName + ', ' + $scope.dtaList[j].PtGender + ' (' + $scope.dtaList[j].PtAge.toFixed(0) + ')',
                        start: $scope.dtaList[j].ADATE,
                        end: $scope.dtaList[j].EDATE,
                        allDay: false,
                        editable: $scope.dtaList[j].AttendedOn === null,
                        backgroundColor: ($scope.dtaList[j].AttendedOn === null) ? '#0088c2' : (($scope.dtaList[j].Due <= 0) ? '#0AA9AA' : '#fca011')
                    });
                }

                $scope.disabledDates = {};
                for (var j in $scope.dthList) {
                    var endDate = new Date($scope.dthList[j].ChEndDt);
                    var startDate = new Date($scope.dthList[j].ChStartDt);
                    var strDt = '';
                    for (var day = startDate; day <= endDate; day.setDate(day.getDate() + 1)) {
                        strDt = $filter('date')(day, 'yyyy-MM-dd');
                        $scope.disabledDates[strDt] = $filter('date')(day, 'yyyy-MM-dd');
                        $('#calendar td.fc-daygrid-day[data-date="' + strDt + '"]')
                            .css({
                                'background-color': '#cecece'
                            });

                    }

                    $scope.appEvents.push({
                        title: $scope.dthList[j].ChReason,
                        description: $scope.dthList[j].ChReason,
                        start: $scope.dthList[j].ChStartDt,
                        end: endDate.setDate(endDate.getDate() + 1),
                        allDay: true,
                        backgroundColor: '#C66511'
                    });

                    
                }

                $scope.appCalendar.removeAllEvents();
                $scope.appCalendar.addEventSource($scope.appEvents);
            });
        };


        $scope.visit = {};
        $scope.patient = {};
        $scope.appt = {};
        $scope.appt.PId = '';

        

        $('table#patient_list').on('click', 'button.btn_appt', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            if (id_parts.length > 1) {
                $scope.$evalAsync(function () {
                    var index = _.findIndex($scope.spList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.patient = angular.copy($scope.spList[index]);
                        $scope.appt.Department = $scope.Department;
                        $scope.appt.Doctor = $scope.Doctor;
                        $scope.appt.PId = $scope.patient.Id;
                        $scope.appt.ADATE = $scope.sDate;
                        $scope.appt.ApptDate = $scope.sDateTime;
                        $('.appts_tabs a[href="#schedule_visit"]').tab('show');
                        $scope.ShowRegistrationForm = false;
                    }
                });
            }
        });

        $('table#appt_list').on('click', 'button.action', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            if (id_parts.length > 1) {
                $scope.$evalAsync(function () {
                    var index = _.findIndex($scope.cdtaList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        switch (id_parts[0]) {
                            case "edit":
                                $scope.patient = angular.copy($scope.cdtaList[index]);
                                $scope.appt = angular.copy($scope.cdtaList[index]);
                                break;
                            case "delete":
                                var r = confirm("Are you sure to delete this appointment for " + $scope.cdtaList[index].PtName + '?');
                                if (r) {
                                    $scope.DeleteApptInfo($scope.model.U.N, $scope.cdtaList[index]);
                                }
                                break;
                            default:
                                break;
                        }
                    }
                });
            }
        });

        $scope.dtempTable = null;
        $scope.RefreshPatientList = function () {
            $scope.$evalAsync(function () {
                if ($scope.dtempTable === null) {
                    $scope.dtempTable = $("table#patient_list").dataTable({
                        language: { search: '', searchPlaceholder: "Search" },
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: [
                            [10, 25, 50, -1],
                            ['10 rows', '25 rows', '50 rows', 'Show all']
                        ],
                        "bDestroy": true,
                        data: $scope.spList,
                        buttons: [
                            {
                                extend: 'excelHtml5',
                                text: '<i class="bx bx-spreadsheet text-success"></i>',
                                titleAttr: 'Export to Excel'
                            },
                            {
                                extend: 'pdfHtml5',
                                text: '<i class="bx bxs-file-pdf text-danger"></i>',
                                titleAttr: 'Export to PDF'
                            }
                        ],
                        columns: [
                            {
                                "mData": "Id",
                                "bSortable": true,
                                "mRender": function (data, type, row) {
                                    return '<button class="btn_appt btn btn-dark" id="btn_' + data + '"><b class="fa fa-calendar"></b> Book Appointment</button>';
                                }
                            },
                            { "mData": "PtName" },
                            { "mData": "PtGender" },
                            { "mData": "PtAge" },
                            { "mData": "PtAddress" },
                            { "mData": "PtSpouseName" }
                        ]
                    });
                }
                else {
                    $scope.dtempTable.fnClearTable();
                    if ($scope.spList.length > 0) {
                        $scope.dtempTable.fnAddData($scope.spList); // Add new data
                        $scope.dtempTable.fnDraw(); // Redraw the DataTable
                    }
                }
            });
        };

        $scope.dtapptTable = null;
        $scope.RefreshAppointmentsTable = function () {
            $scope.$evalAsync(function () {
                if ($scope.dtapptTable === null) {

                    $scope.dtapptTable = $("table#appt_list").dataTable({
                        language: { search: '', searchPlaceholder: "Search" },
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: [
                            [10, 25, 50, -1],
                            ['10 rows', '25 rows', '50 rows', 'Show all']
                        ],
                        "bDestroy": true,
                        data: $scope.cdtaList,
                        buttons: [
                            {
                                extend: 'excelHtml5',
                                text: '<i class="bx bx-spreadsheet text-success"></i>',
                                titleAttr: 'Export to Excel'
                            },
                            {
                                extend: 'pdfHtml5',
                                text: '<i class="bx bxs-file-pdf text-danger"></i>',
                                titleAttr: 'Export to PDF'
                            }
                        ],
                        columns: [
                            {
                                "mData": "Id",
                                "bSortable": true,
                                "mRender": function (data, type, row) {
                                    var bt1 = '<button class="action btn btn-warning" id="edit_' + data + '"><b class="bx bx-edit"></b></button>';
                                    bt1 += '<button class="action btn btn-danger" id="delete_' + data + '"><b class="bx bx-trash"></b></button>';
                                    return (row.BillId > 0) ? '' : bt1;
                                }
                            },
                            { "mData": "PtName" },
                            { "mData": "PtGender" },
                            { "mData": "PtAge" },
                            { "mData": "PtAddress" },
                            { "mData": "ApptPurpose" },
                            { "mData": "ApptRemarks" }
                        ]
                    });
                }
                else {
                    $scope.dtapptTable.fnClearTable();
                    if ($scope.cdtaList.length > 0) {
                        $scope.dtapptTable.fnAddData($scope.cdtaList); // Add new data
                        $scope.dtapptTable.fnDraw(); // Redraw the DataTable
                    }
                }
            });
        };

        $scope.AddAppt = function () {
            $scope.$evalAsync(function () {
                $scope.patient = {};
                $scope.appt = {};
                $scope.appt.Department = $scope.Department;
                $scope.appt.Doctor = $scope.Doctor;
                
            });
        };

        $scope.UpdateAppt = function (appt) {
            $scope.$evalAsync(function () {
                if ($scope.ddl.hasOwnProperty(appt.Department)) {
                    $scope.doctorList = $scope.ddl[appt.Department];
                }
                else {
                    $scope.doctorList = [];
                }
                $scope.ShowAppointmentForm = false;
                $scope.patient = appt;
                $scope.appt = appt;
            });
        };

        $scope.AddPatientAndBookAppt = function (user) {
            if ($scope.frmPatient.$valid) {
                $('form[name="frmPatient"] button[type="submit"]').prop('disabled', true);
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.RegPatientAndScheduleAppt(user);
                    });
                }
                else {
                    $scope.RegPatientAndScheduleAppt(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.RegPatientAndScheduleAppt = function (user) {

            $scope.patient.DId = $scope.model.C.Id;
            

            $scope.clinicHub.server.registerPatientAndBookAppt(user, JSON.stringify($scope.patient)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        //$('#mdlAppointment').modal('hide');
                        $scope.patient = {};
                        toastr['success']('Appt Scheduled for patient successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating patient information!', $scope.toastr_title);
                    }
                    $('form[name="frmPatient"] button[type="submit"]').prop('disabled', false);
                });
            });
        };


        $scope.AddUpdateApptInfo = function (user) {
            if ($scope.frmAppointment.$valid) {
                $('form[name="frmAppointment"] button[type="submit"]').prop('disabled', true);
                $scope.appt.DId = $scope.model.C.Id;
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateApptInformation(user);
                    });
                }
                else {
                    $scope.UpdateApptInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateApptInformation = function (user) {
            $scope.appt.ApptType = 'OPD';
            $scope.clinicHub.server.updateAppointmentInformation(user, JSON.stringify($scope.appt)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $scope.appt = {};
                        $scope.patient = {};
                        toastr['success']('Appt Booked for patient successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Appt information!', $scope.toastr_title);
                    }
                    $('form[name="frmAppointment"] button[type="submit"]').prop('disabled', false);
                });
            });
        };

        $scope.DeleteApptInfo = function (user, app2delete) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteApptInformation(user, app2delete);
                    });
                }
                else {
                    $scope.DeleteApptInformation(user, app2delete);
                }
        };
        $scope.DeleteApptInformation = function (user, app2delete) {
            $scope.clinicHub.server.deleteAppointmentInformation(user, JSON.stringify(app2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Appt deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Appt information!', $scope.toastr_title);
                    }
                });
            });
        };

        $scope.clinicHub.client.refreshAppointments = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data !== null && data != undefined && data.DId === $scope.model.C.Id && data.ApptType === 'OPD') {
                    var index = -1;
                    index = _.findIndex($scope.dtaList, {
                        Id: data.Id
                    });
                    if (index >= 0) {
                        $scope.dtaList[index] = data;
                        toastr['success']('Appointments Refreshed Successfully!', $scope.toastr_title);
                    }
                    else {
                        $scope.dtaList.push(data);
                    }
                    $scope.cdtaList = _.filter($scope.dtaList, function (a) {
                        return $filter('date')(a.ADATE, 'yyyy-MM-dd') === $scope.sDate;
                    });
                    $scope.RefreshCalendarEvents();
                }
            });
        };

        $scope.clinicHub.client.refreshAppointmentsAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data !== null && data != undefined && data.DId === $scope.model.C.Id) {
                    var index = _.findIndex($scope.dtaList, {
                        Id: data.Id
                    });
                    if (index >= 0) {
                        $scope.dtaList.splice(index, 1);
                        $scope.cdtaList = _.filter($scope.dtaList, function (a) {
                            return $filter('date')(a.ADATE, 'yyyy-MM-dd') === $scope.sDate;
                        });
                        
                        $scope.RefreshCalendarEvents();
                        toastr['success']('Appointments Refreshed Successfully!', $scope.toastr_title);
                    }
                }
            });
        };

        //
        //Appointments & Patients
        //

    }]);

    app.directive('enterAsTab', function () {
        return function (scope, element, attrs) {
            element.bind("keydown keypress", function (event) {
                if (event.which === 13) {
                    event.preventDefault();
                    var elementToFocus = element.parent().next().find('input, select, textarea, button')[0];
                    if (angular.isDefined(elementToFocus)) {
                        elementToFocus.focus();
                    }
                    else {
                        elementToFocus = element.parent().parent().next().find('input, select, textarea, button')[0];
                        if (angular.isDefined(elementToFocus)) {
                            elementToFocus.focus();
                        }
                    }
                }
            });
        };
    });

}());
﻿﻿(function () {
    var app = angular.module('HMSApp', []);
     app.controller('HMSController', function ($scope, $http) {
        toastr.options = { 'closeButton': 'true', 'debug': false, 'newestOnTop': true, 'progressBar': true, 'positionClass': 'toast-bottom-left', 'preventDuplicates': true, 'onclick': null, 'showDuration': '5000', 'hideDuration': '1200', 'timeOut': '2000', 'extendedTimeOut': '1500', 'showEasing': 'swing', 'hideEasing': 'linear', 'showMethod': 'fadeIn', 'hideMethod': 'fadeOut' };
        $scope.toastr_title = 'ePractice Powered by GPRN!';
        $scope.base_url = '';
        $scope.website_url = '';



         angular.element(document).ready(function () {

             $('form.bv-form').each(function () {
                 var frmId = $(this).attr('id');
                 $('#' + frmId + ' .form-control').on("blur, change", function () {
                     var nm = $(this).attr('name');
                     $('#' + frmId + '').bootstrapValidator('revalidateField', nm);
                 });
             });

             $scope.ValidateFormById = function (frmId) {
                 $scope.$evalAsync(function () {
                     $('#' + frmId + ' .form-control').each(function () {
                         var nm = $(this).attr('name');
                         $('#' + frmId + '').bootstrapValidator('revalidateField', nm);
                     });
                 });
             };

        });
    });
}());
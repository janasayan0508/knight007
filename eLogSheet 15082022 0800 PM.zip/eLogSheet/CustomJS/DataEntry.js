﻿(function () {
    var app = angular.module('eLogSheetApp', []);
    app.controller('eLogSheetCtrl', ['$scope', '$http', '$filter', function ($scope, $http, $filter) {

        $scope.ConnectionStarted = false;

        //toaster options
        toastr.options = { 'closeButton': 'true', 'debug': false, 'newestOnTop': true, 'progressBar': true, 'positionClass': 'toast-bottom-left', 'preventDuplicates': true, 'onclick': null, 'showDuration': '5000', 'hideDuration': '1200', 'timeOut': '2000', 'extendedTimeOut': '1500', 'showEasing': 'swing', 'hideEasing': 'linear', 'showMethod': 'fadeIn', 'hideMethod': 'fadeOut' };
        $scope.toastr_title = 'ePractice Powered by CoDT, BSL!';

        $scope.dataEntryHub = $.connection.dataEntryHub; // initializes hub
        $scope.ConnectionStarted = false;

        $scope.data = {};
        $scope.model = {};
        $scope.dshift = '';
        $scope.pTotal = {};
        $scope.SelectedDate = '';
        $scope.delay = {};
        $scope.incident = {};

        $scope.SH = {};


        for (var hrs = 6; hrs <= 29; hrs++) {

            var shift = '';

            if (hrs >= 6 && hrs <= 13) {
                shift = 'A';
            }
            else if (hrs >= 14 && hrs <= 21) {
                shift = 'B';
            }
            else {
                shift = 'C';
            }
            var hr = hrs > 23 ? hrs % 24 : hrs;
            if ($scope.SH.hasOwnProperty(shift)) {
                $scope.SH[shift][hrs] = hr;
            }
            else {
                $scope.SH[shift] = {};
                $scope.SH[shift][hrs] = hr;
            }
        }



        angular.element(document).ready(function () {

            $scope.$evalAsync(function () {

                $scope.base_url = $(location).attr('host');
                $('.datepicker').daterangepicker({
                    singleDatePicker: true,
                    showDropdowns: true,
                    drops: "auto",
                    maxDate: new Date(),
                    autoUpdateInput: false,
                    autoApply: false,
                    locale: {
                        format: 'DD/MM/YYYY',
                        cancelLabel: 'Clear'
                    }
                });
                $('.datepicker').on('show.daterangepicker', () => {
                    $('.daterangepicker').removeClass('auto-apply');
                });
                
                $('.datepicker').on('apply.daterangepicker', function (ev, picker) {
                    $scope.$evalAsync(function () {
                        $scope.model.DT = moment(picker.startDate.format('DD/MM/YYYY'), 'DD/MM/YYYY');
                        $scope.SelectedDate = picker.startDate.format('DD/MM/YYYY');
                        var dt = picker.startDate.format('YYYYMMDD');
                        toastr['info'](dt, $scope.toastr_title);
                        $scope.GetDataForDay($scope.model.U.UserName, dt);
                    });
                });

                $scope.model = $.parseJSON($('p#modelData').text());
                $('p#modelData').text('');

                //
                //Datetime Picker
                //

                $('.datetimepicker').daterangepicker({
                    singleDatePicker: true,
                    showDropdowns: true,
                    autoUpdateInput: false,
                    autoApply: false,
                    parentEl: $(this).attr('frm-entity'),
                    timePicker: true,
                    timePickerIncrement: 5,
                    minDate: new Date(),
                    timePicker24Hour: true,
                    showDropdowns: true,
                    locale: {
                        format: 'YYYY-MM-DDThh:mm:ss',
                        cancelLabel: 'Clear'
                    }
                });


                $('.datetimepicker').on('show.daterangepicker', () => {
                    $('.daterangepicker').removeClass('auto-apply');
                });


                $('.datetimepicker').on('cancel.daterangepicker', function (ev, picker) {
                    var nm = $(this).attr('name');
                    var frmObject = $(this).attr('frm-entity');
                    $scope.$evalAsync(function () {
                        $scope[frmObject][nm] = null;
                    });
                });

                $('.datetimepicker').on('apply.daterangepicker', function (ev, picker) {
                    var nm = $(this).attr('name');
                    var frmObject = $(this).attr('frm-entity');
                    $scope.$evalAsync(function () {
                        $scope[frmObject][nm] = picker.startDate.format('YYYY-MM-DDThh:mm:ss');
                    });
                });


                //
                //Datetime Picker
                //
                
                
                $.connection.hub.start().done(function () {
                    $scope.$evalAsync(function () {
                        $scope.ConnectionStarted = true;
                        toastr['info']('Hub Started!', $scope.toastr_title);
                        $scope.GenerateDataForm();

                        var hrs = new Date().getHours();

                        if (hrs >= 6 && hrs <= 13) {
                            shift = 'A';
                        }
                        else if (hrs >= 14 && hrs <= 21) {
                            shift = 'B';
                        }
                        else {
                            shift = 'C';
                        }

                        $scope.dshift = shift;
                        $scope.SelectedDate = $filter('date')($scope.model.DT, 'dd/MM/yyyy');

                    });
                }); // starts hub

            });
        });


        $scope.ValidateFormById = function (frmId) {
            $scope.$evalAsync(function () {
                $('#' + frmId + ' .input-field:visible').each(function () {
                    var nm = $(this).attr('name');
                    $('#' + frmId + '').bootstrapValidator('revalidateField', nm);
                });
            });
        };


        $('form.bv-form').on('blur', 'input.input-field', function () {
            var frm = $(this).attr('frm-name');
            var nm = $(this).attr('name');
            $scope.$evalAsync(function () {
                //var bv = $('#' + frm + '').bootstrapValidator();
                $('#' + frm + '').bootstrapValidator('revalidateField', nm);
                //toastr['info'](frm + ' Input ' + nm +' Changed!', $scope.toastr_title);
            });
        });

        $scope.dfwpList = {};
        $scope.data = {};


        $scope.GenerateDataForm = function () {
            $scope.$evalAsync(function () {

                $scope.dfwpList = {};
                toastr['info']('Processing Data for Date!', $scope.toastr_title);
                $scope.model.dataList = $scope.model.dataList.sort(function (a, b) {
                    return a.FPV - b.FPV;
                });

                for (var j in $scope.model.dataList) {

                    var st = $scope.model.dataList[j].PF;
                    var did = $scope.model.dataList[j].DId;
                    var sft = $scope.model.dataList[j].PFT;
                    var pid = $scope.model.dataList[j].PId;
                    var pname = $scope.model.pList[pid].Name;


                    var isInpuparam4Form = false;
                    var sv = null;
                    switch (sft) {
                        case "int":
                            sv = parseInt($scope.model.dataList[j].PFV, 10);
                            break;
                        case "string":
                            sv = $scope.model.dataList[j].PFV
                            break;
                        default:
                            break;
                    }

                    var uid = st + '_' + sv + '_' + $scope.model.dataList[j].PId;
                    var stpid = st + '_' + $scope.model.dataList[j].PId;
                    var val = 0;

                    var dfname = $scope.model.dataList[j].PDT + 'Value';

                    $scope.model.dataList[j].uid = uid;
                    $scope.model.dataList[j].stpid = stpid;
                    $scope.model.dataList[j].dfname = dfname;
                    
                    var val = $scope.model.dataList[j][dfname];

                    switch (st) {
                        case "Shift":
                            isInpuparam4Form = ($scope.dshift === sv);

                            break;
                        case "Hour":
                            isInpuparam4Form = $scope.SH.hasOwnProperty($scope.dshift) && $scope.SH[$scope.dshift].hasOwnProperty(sv);
                            break;
                        case "Day":
                            break;
                        default:
                            break;
                    }

                    if ($scope.dfwpList.hasOwnProperty(did)) {
                        if ($scope.dfwpList[did].hasOwnProperty(st)) {
                            if ($scope.dfwpList[did][st].pList.hasOwnProperty(pid)) {
                                if (isInpuparam4Form) {
                                    $scope.dfwpList[did][st].pList[pid].ifList[sv] = $scope.model.dataList[j];
                                    $scope.data[uid] = val;
                                }
                                else {
                                    $scope.dfwpList[did][st].pList[pid].ofList[sv] = $scope.model.dataList[j];
                                }
                            }
                            else {
                                $scope.dfwpList[did][st].pList[pid] = {};
                                $scope.dfwpList[did][st].pList[pid].ifList = {};
                                $scope.dfwpList[did][st].pList[pid].ofList = {};
                                if (isInpuparam4Form) {
                                    $scope.dfwpList[did][st].pList[pid].ifList[sv] = $scope.model.dataList[j];
                                    $scope.data[uid] = val;
                                }
                                else {
                                    $scope.dfwpList[did][st].pList[pid].ofList[sv] = $scope.model.dataList[j];
                                }
                            }
                        }
                        else {
                            $scope.dfwpList[did][st] = {};
                            $scope.dfwpList[did][st].pList = {};
                            $scope.dfwpList[did][st].pList[pid] = {};
                            $scope.dfwpList[did][st].pList[pid].ifList = {};
                            $scope.dfwpList[did][st].pList[pid].ofList = {};
                            if (isInpuparam4Form) {
                                $scope.dfwpList[did][st].pList[pid].ifList[sv] = $scope.model.dataList[j];
                                $scope.data[uid] = val;
                            }
                            else {
                                $scope.dfwpList[did][st].pList[pid].ofList[sv] = $scope.model.dataList[j];
                            }
                        }
                    }
                    else {
                        $scope.dfwpList[did] = {};
                        $scope.dfwpList[did][st] = {};
                        $scope.dfwpList[did][st].pList = {};
                        $scope.dfwpList[did][st].pList[pid] = {};
                        $scope.dfwpList[did][st].pList[pid].ifList = {};
                        $scope.dfwpList[did][st].pList[pid].ofList = {};
                        if (isInpuparam4Form) {
                            $scope.dfwpList[did][st].pList[pid].ifList[sv] = $scope.model.dataList[j];
                            $scope.data[uid] = val;
                        }
                        else {
                            $scope.dfwpList[did][st].pList[pid].ofList[sv] = $scope.model.dataList[j];
                        }
                    }
                }

                $scope.RefreshDelaysTable();
                $scope.RefreshIncidentsTable();
            });
        };


        $scope.GenerateDataFormOld = function () {
            $scope.$evalAsync(function () {

                $scope.dfwpList = {};

                $scope.model.dataList = $scope.model.dataList.sort(function (a, b) {
                    return a.FPV - b.FPV;
                });

                for (var j in $scope.model.dataList) {

                    var st = $scope.model.dataList[j].PF;
                    
                    var sft = $scope.model.dataList[j].PFT;
                    var pid = $scope.model.dataList[j].PId;

                    

                    var isInpuparam4Form = false;
                    var sv = null;
                    switch (sft) {
                        case "int":
                            sv = parseInt($scope.model.dataList[j].PFV, 10);
                            break;
                        case "string":
                            sv = $scope.model.dataList[j].PFV
                            break;
                        default:
                            break;
                    }

                    var uid = st + '_' + sv + '_' + $scope.model.dataList[j].PId;
                    var stpid = st + '_' + $scope.model.dataList[j].PId;
                    var val = 0;

                    var dfname = $scope.model.dataList[j].PDT + 'Value';

                    $scope.model.dataList[j].uid = uid;
                    $scope.model.dataList[j].stpid = stpid;
                    $scope.model.dataList[j].dfname = dfname;
                    var val = $scope.model.dataList[j][dfname];

                    switch (st) {
                        case "Shift":
                            isInpuparam4Form = ($scope.dshift === sv);

                            break;
                        case "Hour":
                            isInpuparam4Form = $scope.SH.hasOwnProperty($scope.dshift) && $scope.SH[$scope.dshift].hasOwnProperty(sv);
                            break;
                        case "Day":
                            break;
                        default:
                            break;
                    }

                    if ($scope.dfwpList.hasOwnProperty(st)) {
                        if (isInpuparam4Form) {
                            $scope.dfwpList[st].ifList[uid] = {};
                            $scope.dfwpList[st].ifList[uid].df = $scope.model.dataList[j];
                            $scope.data[uid] = val;
                        }
                        else {
                            $scope.dfwpList[st].ofList[uid] = {};
                            $scope.dfwpList[st].ofList[uid].df = $scope.model.dataList[j];
                        }
                        if ($scope.dfwpList[st].frmData.hasOwnProperty(stpid)) {
                            $scope.dfwpList[st].frmData[stpid][sv] = val;
                        }
                        else {
                            $scope.dfwpList[st].frmData[stpid] = {};
                            $scope.dfwpList[st].frmData[stpid][sv] = val;
                        }
                    }
                    else {
                        $scope.dfwpList[st] = {};
                        $scope.dfwpList[st].ifList = {};
                        $scope.dfwpList[st].ofList = {};
                        if (isInpuparam4Form) {
                            $scope.dfwpList[st].ifList[uid] = {};
                            
                            $scope.dfwpList[st].ifList[uid].df = $scope.model.dataList[j];
                            $scope.data[uid] = val;
                        }
                        else {
                            $scope.dfwpList[st].ofList[uid] = {};
                            $scope.dfwpList[st].ofList[uid].df = $scope.model.dataList[j];
                        }
                        $scope.dfwpList[st].frmData = {};
                        $scope.dfwpList[st].frmData[stpid] = {};
                        $scope.dfwpList[st].frmData[stpid][sv] = val;
                    }
                }

                var total = 0;
                val = 0;
                for (var st in $scope.dfwpList) {
                    for (var stpid in $scope.dfwpList[st].frmData) {
                        total = 0;
                        val = 0;
                        for (var ps in $scope.dfwpList[st].frmData[stpid]) {
                            val = parseFloat($scope.dfwpList[st].frmData[stpid][ps]);
                            total += isNaN(val) ? 0 : val;
                        }
                        $scope.pTotal[stpid] = total;
                    }
                }


                
            });
        };

        

        $scope.RefreshScopeFromModel = function () {
            $scope.$evalAsync(function () {
                var total = 0;
                var isNumber = true;

                for (var s in $scope.model.swpList) {
                    for (var p in $scope.model.swpList[s]) {

                        total = 0;

                        for (var sn in $scope.model.swpList[s][p]) {
                            var data = $scope.model.swpList[s][p][sn];
                            var param = $scope.model.pList[data.PId];
                            isNumber = (param.InpType === 'number');
                            var uid = param.DId + '_' + param.MId + '_' + param.EId + '_' + s + '_' + sn + '_' + param.Id + '_' + param.InpType;
                            $scope.model.swpList[s][p][sn].UID = uid;
                            $scope.data[uid] = data[param.Datatype + 'Value'];
                            if (isNumber) {
                                total += data[param.Datatype + 'Value'];
                            }
                        }
                        if (isNumber) {
                            $scope.pTotal[p] = total;
                        }
                    }
                }

                $('div#frmData input:visible').remove();

                $scope.ValidateFormById('frmData');
                $scope.RefreshDelaysTable();
                $scope.RefreshIncidentsTable();
                
            });
        };

        //
        //Submit Data
        //

        $scope.UpdateDataValueInList = function (uid, f2update, s, p, psv) {
            $scope.$evalAsync(function () {

                var val = parseFloat($('input[name="' + uid + '"]').val());
                var stpid = s + '_' + p;
                val = isNaN(val) ? 0 : val;


                $scope.dfwpList[$scope.model.DId][s].pList[p].ifList[psv][f2update] = val;
                $scope.dfwpList[$scope.model.DId][s].pList[p].ifList[psv]['PDV'] = val;
               
                ////toastr['info']('UID' + uid + ', Value:' + $('input[name="' + uid + '"]').val(), $scope.toastr_title);
                //var total = 0;
                //val = 0;
                
                //total = 0;
                //val = 0;
                //for (var ps in $scope.dfwpList[s].frmData[stpid]) {
                //    val = parseFloat($scope.dfwpList[s].frmData[stpid][ps]);
                //    total += isNaN(val) ? 0 : val;
                //}
                //$scope.pTotal[stpid] = total;
            });
        };


        $scope.UpdateCheckBoxValueInList = function (uid, f2update, s, p, sn) {
            $scope.$evalAsync(function () {

                var currVal = $('input[name="' + uid + '"]:visible').is(':checked');
                $('input[name="' + uid + '"]:visible').attr('checked', currVal);
                $scope.model.swpList[s][p][sn][f2update] = currVal;
                $scope.model.swpList[s][p][sn]['PDV'] = currVal;
                //toastr['info']('UID' + uid + ', Value:' + $('input[name="' + uid + '"]').val(), $scope.toastr_title);
                toastr['info'](currVal, $scope.toastr_title);

                $scope.pTotal[p] = $('div#div_' + p + ' input[type="checkbox"]:visible:checked').length;

            });
        };


        $scope.GetDataForDay = function (user, dt) {

            $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
            if (!$scope.ConnectionStarted) {
                $.connection.hub.start().done(function () {
                    $scope.ConnectionStarted = true;
                    $scope.GetReportDataForDay(user, dt);
                });
            }
            else {
                $scope.GetReportDataForDay(user, dt);
            }
        };
        $scope.GetReportDataForDay = function (user, dt) {

            
            $scope.dataEntryHub.server.getDataForTheDay(user, dt, $scope.model.DId).done(function (response) {
                $scope.$evalAsync(function () {
                    if (response !== "") {
                        var data = $.parseJSON(response);
                        $scope.model = angular.copy(data);
                        $scope.GenerateDataForm();
                        toastr['success']('Data Refreshed for ' + data.DT + '!', $scope.toastr_title);
                        toastr['success']('Data Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating data!', $scope.toastr_title);
                    }
                });
            });
        };


        $scope.SaveDataForDay = function (user) {

            if ($scope.frmData.$valid) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.SaveReportDataForDay(user);
                    });
                }
                else {
                    $scope.SaveReportDataForDay(user);
                }
            }
            else {
                toastr['error']('Provide valid entries and try again!', $scope.toastr_title);

            }
        };
        $scope.SaveReportDataForDay = function (user) {

            var tmpData = [];
            for (var s in $scope.dfwpList[$scope.model.DId]) {
                for (var pid in $scope.dfwpList[$scope.model.DId][s].pList) {
                    for (var uid in $scope.dfwpList[$scope.model.DId][s].pList[pid].ifList) {
                        tmpData.push($scope.dfwpList[$scope.model.DId][s].pList[pid].ifList[uid]);
                    }
                    for (var uid in $scope.dfwpList[$scope.model.DId][s].pList[pid].ofList) {
                        tmpData.push($scope.dfwpList[$scope.model.DId][s].pList[pid].ofList[uid]);
                    }
                }
            }

            $scope.dataEntryHub.server.saveDataForTheDay(user, $filter('date')($scope.model.DT, 'yyyyMMdd'), $scope.model.DId, JSON.stringify(tmpData)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        
                        toastr['success']('Data Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating data!', $scope.toastr_title);
                    }
                });
            });
        };


        $scope.dataEntryHub.client.refreshSheetViewModel = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.DId && $filter('date')(data.DT, 'yyyyMMdd') == $filter('date')($scope.model.DT, 'yyyyMMdd')) {
                    $scope.model = angular.copy(data);
                    $scope.RefreshScopeFromModel();
                    toastr['success']('Data Refreshed for ' + data.DT + '!', $scope.toastr_title);
                }
            });
        };

        //
        //Submit Data
        //

        //
        //Delays
        //

        $('table#delays_list').on('click', 'span.dt_btns', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            switch (id_parts[0]) {
                case "edt":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.delaysList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {

                                $scope.delay = angular.copy($scope.model.delaysList[index]);
                                $scope.ValidateFormById('frmDelay');
                                toastr['warning']('You are editing ' + $scope.delay.Reason, $scope.toastr_title);
                                $('div#mdlDelays').modal('show');
                            }
                        }
                    });
                    break;
                case "del":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.delaysList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {
                                $scope.delay = angular.copy($scope.model.delaysList[index]);
                                $scope.DeleteDelayInfo($scope.model.U.UserName, $scope.delay);
                                toastr['danger']('You are deleting ' + $scope.delay.Reason, $scope.toastr_title);
                            }
                        }
                    });
                    break;
                case "cln":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.delaysList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {

                                $scope.delay = angular.copy($scope.model.delaysList[index]);
                                $scope.delay.Id = 0;
                                $scope.ValidateFormById('frmDelay');
                                toastr['warning']('You are editing ' + $scope.delay.Reason, $scope.toastr_title);
                                $('div#mdlDelays').modal('show');
                            }
                        }
                    });
                    break;
                default:
                    break;
            }

        });


        $scope.dtDelay = null;
        $scope.RefreshDelaysTable = function () {
            $scope.$evalAsync(function () {

                var lengthMenu = [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ];
                var btns = [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="text-success bx bxs-spreadsheet"></i>',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="text-danger bx bxs-file-pdf"></i>',
                        titleAttr: 'Export to PDF'
                    }
                ];
                var clms = [

                    {
                        "mData": "Id",
                        "bSortable": false,
                        "mRender": function (data, type, gcb) {
                            var edBtns = '<span title="Edit Delay" id="edt_' + data + '" class="text-primary dt_btns bx bx-edit"></span>';
                            edBtns += '<span title="Delete Delay" id="del_' + data + '" class="text-danger dt_btns bx bx-trash"></span>';
                            edBtns += '<span title="Clone Delay" id="cln_' + data + '" class="text-success dt_btns bx bx-copy"></span>';
                            return edBtns;
                        }
                    },
                    { "mData": "Reason" },
                    {
                        "mData": "DtStart",
                        "bSortable": true,
                        "mRender": function (data, type, row) {

                            return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                        }
                    },
                    {
                        "mData": "DtEnd",
                        "bSortable": true,
                        "mRender": function (data, type, row) {

                            return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                        }
                    },
                    {
                        "mData": "Id",
                        "bSortable": true,
                        "mRender": function (data, type, row) {
                            var d = '';
                            d += (row.HH === null) ? '00' : row.HH;
                            d += (row.MM === null) ? ':00' : ":" + row.MM;
                            return d;
                        }
                    },
                    { "mData": "UpdatedBy" },
                    {
                        "mData": "UpdatedOn",
                        "bSortable": true,
                        "mRender": function (data, type, row) {

                            return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                        }
                    }
                ];

                if ($scope.dtDelay === null) {
                    $scope.dtDelay = $("table#delays_list").dataTable({
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: lengthMenu,
                        data: $scope.model.delaysList,
                        buttons: btns,
                        columns: clms
                    });
                }
                else {
                    $scope.dtDelay.fnClearTable();
                    $scope.dtDelay.fnAddData($scope.model.delaysList); // Add new data
                    $scope.dtDelay.fnDraw(); // Redraw the DataTable
                }
            });
        };


        $scope.AddNewDelay = function () {
            $scope.$evalAsync(function () {
                $scope.delay = {};
                $scope.delay.Id = 0;
                $scope.delay.PF = 2;
                $scope.delay.PFT = 'string';
                $scope.delay.PFV = $scope.dshift;
                $scope.delay.DId = $scope.model.DId;
                $scope.delay.FY = $scope.model.FY;
                $scope.delay.DT = $filter('date')($scope.model.DT, 'yyyy-MM-dd');
                $scope.delay.Q = $scope.model.Q;
            });
        };
        $scope.AddUpdateDelayInfo = function (user) {
            if ($scope.frmDelay.$valid) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateDelayInformation(user);
                    });
                }
                else {
                    $scope.UpdateDelayInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateDelayInformation = function (user) {
            $scope.dataEntryHub.server.updateDelayInformation(user, JSON.stringify($scope.delay)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $('#mdlDelays').modal('hide');
                        $scope.delay = {};
                        toastr['success']('Delay Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Delay information!' + data, $scope.toastr_title);
                    }
                });
            });
        };
        $scope.DeleteDelayInfo = function (user, item2delete) {
            var r = confirm("Are you sure to delete this Delay " + item2delete.Reason);
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteDelayInformation(user, item2delete);
                    });
                }
                else {
                    $scope.DeleteDelayInformation(user, item2delete);
                }
            }
        };
        $scope.DeleteDelayInformation = function (user, item2delete) {
            $scope.dataEntryHub.server.deleteDelayInformation(user, JSON.stringify(item2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Delay deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Delay information!', $scope.toastr_title);
                    }
                });
            });
        };
        $scope.dataEntryHub.client.refreshDelays = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.DId) {
                    index = _.findIndex($scope.model.delaysList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.delaysList[index] = data;
                    }
                    else {
                        $scope.model.delaysList.push(data);
                    }
                    $scope.delay = {};
                    $scope.RefreshDelaysTable();
                    toastr['success']('Delay Refreshed Successfully!', $scope.toastr_title);
                }
                
            });
        };
        $scope.dataEntryHub.client.refreshDelaysAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.DId) {
                    index = _.findIndex($scope.model.delaysList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.delaysList.splice(index, 1);
                        toastr['success']('Delay Refreshed Successfully!', $scope.toastr_title);
                        $scope.delay = {};
                        $scope.RefreshDelaysTable();
                    }
                }

            });
        };

        //
        //Delays
        //

        //
        //Incidents
        //

        $('table#incidents_list').on('click', 'span.dt_btns', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            switch (id_parts[0]) {
                case "edt":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.incidentsList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {

                                $scope.incident = angular.copy($scope.model.incidentsList[index]);
                                $scope.ValidateFormById('frmIncident');
                                toastr['warning']('You are editing ' + $scope.incident.BriefDesc, $scope.toastr_title);
                                $('div#mdlIncidents').modal('show');
                            }
                        }
                    });
                    break;
                case "del":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.incidentsList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {
                                $scope.incident = angular.copy($scope.model.incidentsList[index]);
                                $scope.DeleteIncidentInfo($scope.model.U.UserName, $scope.incident);
                                toastr['danger']('You are deleting ' + $scope.incident.BriefDesc, $scope.toastr_title);
                            }
                        }
                    });
                    break;
                case "cln":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.incidentsList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {

                                $scope.incident = angular.copy($scope.model.incidentsList[index]);
                                $scope.incident.Id = 0;
                                $scope.ValidateFormById('frmIncident');
                                toastr['warning']('You are creating a copy of ' + $scope.incident.BriefDesc, $scope.toastr_title);
                                $('div#mdlIncidents').modal('show');
                            }
                        }
                    });
                    break;
                default:
                    break;
            }

        });


        $scope.dtIncident = null;
        $scope.RefreshIncidentsTable = function () {
            $scope.$evalAsync(function () {

                var lengthMenu = [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ];
                var btns = [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="text-success bx bxs-spreadsheet"></i>',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="text-danger bx bxs-file-pdf"></i>',
                        titleAttr: 'Export to PDF'
                    }
                ];
                var clms = [

                    {
                        "mData": "Id",
                        "bSortable": false,
                        "mRender": function (data, type, gcb) {
                            var edBtns = '<span title="Edit Incident" id="edt_' + data + '" class="text-primary dt_btns item_edit bx bx-edit"></span>';
                            edBtns += '<span title="Delete Incident" id="del_' + data + '" class="text-danger dt_btns item_delete bx bx-trash"></span>';
                            edBtns += '<span title="Clone Incident" id="cln_' + data + '" class="text-success dt_btns item_clone bx bx-copy"></span>';
                            return edBtns;
                        }
                    },
                    { "mData": "Reason" },
                    {
                        "mData": "IncDate",
                        "bSortable": true,
                        "mRender": function (data, type, row) {

                            return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                        }
                    },
                    { "mData": "BriefDesc" },
                    { "mData": "ShiftInc" },
                    { "mData": "IncLocation" },
                    { "mData": "IncType" },
                    { "mData": "MsrsTaken" },
                    { "mData": "UpdatedBy" },
                    {
                        "mData": "UpdatedOn",
                        "bSortable": true,
                        "mRender": function (data, type, row) {

                            return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                        }
                    }
                ];

                if ($scope.dtIncident === null) {
                    $scope.dtIncident = $("table#incidents_list").dataTable({
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: lengthMenu,
                        data: $scope.model.incidentsList,
                        buttons: btns,
                        columns: clms
                    });
                }
                else {
                    $scope.dtIncident.fnClearTable();
                    $scope.dtIncident.fnAddData($scope.model.incidentsList); // Add new data
                    $scope.dtIncident.fnDraw(); // Redraw the DataTable
                }
            });
        };


        $scope.AddNewIncident = function () {
            $scope.$evalAsync(function () {
                $scope.incident = {};
                $scope.incident.Id = 0;
                $scope.incident.PFT = 'string';
                $scope.incident.PFV = $scope.dshift;
                $scope.incident.DId = $scope.model.DId;
                $scope.incident.FY = $scope.model.FY;
                $scope.incident.DT = $filter('date')($scope.model.DT, 'yyyy-MM-dd');;
                $scope.incident.Q = $scope.model.Q;
            });
        };
        $scope.AddUpdateIncidentInfo = function (user) {
            if ($scope.frmIncident.$valid) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateIncidentInformation(user);
                    });
                }
                else {
                    $scope.UpdateIncidentInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateIncidentInformation = function (user) {
            $scope.dataEntryHub.server.updateIncidentInformation(user, JSON.stringify($scope.incident)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $('#mdlIncidents').modal('hide');
                        $scope.incident = {};
                        toastr['success']('Incident Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Incident information!' + data, $scope.toastr_title);
                    }
                });
            });
        };
        $scope.DeleteIncidentInfo = function (user, item2delete) {
            var r = confirm("Are you sure to delete this Incident " + item2delete.BriefDesc);
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteIncidentInformation(user, item2delete);
                    });
                }
                else {
                    $scope.DeleteIncidentInformation(user, item2delete);
                }
            }
        };
        $scope.DeleteIncidentInformation = function (user, item2delete) {
            $scope.dataEntryHub.server.deleteIncidentInformation(user, JSON.stringify(item2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Incident deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Incident information!', $scope.toastr_title);
                    }
                });
            });
        };
        $scope.dataEntryHub.client.refreshIncidents = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.DId) {
                    index = _.findIndex($scope.model.incidentsList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.incidentsList[index] = data;
                    }
                    else {
                        $scope.model.incidentsList.push(data);
                    }
                    $scope.incident = {};
                    $scope.RefreshIncidentsTable();
                    toastr['success']('Incident Refreshed Successfully!', $scope.toastr_title);
                }

            });
        };
        $scope.dataEntryHub.client.refreshIncidentsAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.DId) {
                    index = _.findIndex($scope.model.incidentsList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.incidentsList.splice(index, 1);
                        toastr['success']('Incident Refreshed Successfully!', $scope.toastr_title);
                        $scope.incident = {};
                        $scope.RefreshIncidentsTable();
                    }
                }

            });
        };

        //
        //Incidents
        //
    }]);


    app.filter('ceil', function () {
        return function (input) {
            return Math.ceil(input);
        };
    });


    app.directive('enterAsTab', function () {
        return function (scope, element, attrs) {
            element.bind("keydown keypress", function (event) {
                if (event.which === 13) {
                    event.preventDefault();
                    var elementToFocus = element.parent().next().find('input, select, textarea, button')[0];
                    if (angular.isDefined(elementToFocus)) {
                        elementToFocus.focus();
                    }
                    else {
                        elementToFocus = element.parent().parent().next().find('input, select, textarea, button')[0];
                        if (angular.isDefined(elementToFocus)) {
                            elementToFocus.focus();
                        }
                    }
                }
            });
        };
    });

}());
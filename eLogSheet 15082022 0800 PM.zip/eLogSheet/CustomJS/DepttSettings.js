﻿(function () {
    var app = angular.module('HMSApp', []);
    app.controller('HMSController', ['$scope', '$http', '$filter', function ($scope, $http, $filter) {

        $scope.ConnectionStarted = false;

        //toaster options
        toastr.options = { 'closeButton': 'true', 'debug': false, 'newestOnTop': true, 'progressBar': true, 'positionClass': 'toast-bottom-left', 'preventDuplicates': true, 'onclick': null, 'showDuration': '5000', 'hideDuration': '1200', 'timeOut': '2000', 'extendedTimeOut': '1500', 'showEasing': 'swing', 'hideEasing': 'linear', 'showMethod': 'fadeIn', 'hideMethod': 'fadeOut' };
        $scope.toastr_title = 'eLogSheet Powered by CoDT, BSL!';


        $scope.dataEntryHub = $.connection.dataEntryHub; // initializes hub
        $scope.ConnectionStarted = false;

        $('form.bv-form').each(function () {
            var frmId = $(this).attr('id');
            $('#' + frmId + ' .form-control').on("blur, change", function () {
                var nm = $(this).attr('name');
                $('#' + frmId + '').bootstrapValidator('revalidateField', nm);
            });
        });

        $scope.ValidateFormById = function (frmId) {
            $scope.$evalAsync(function () {
                $('#' + frmId + ' .form-control').each(function () {
                    var nm = $(this).attr('name');
                    $('#' + frmId + '').bootstrapValidator('revalidateField', nm);
                });
            });
        };

        var today = new Date();
        today.setDate(today.getDate() - 1);

        angular.element(document).ready(function () {

            $scope.$evalAsync(function () {

                $scope.base_url = $(location).attr('host');

                $scope.model = $.parseJSON($('p#modelData').text());
                $('p#modelData').text('');

                $scope.RefreshParametersTable();
                $scope.RefreshEquipmentsTable();
                $scope.RefreshMachinesTable();
                $scope.RefreshTitlesTable();
            });
        });

        $scope.CheckUncheck = function (nm) {
            $scope.$evalAsync(function () {
                $('input.' + nm).attr('checked', $('input.' + nm).is(':checked'));
                $('input.' + nm).val($('input.' + nm).is(':checked'));
            });
        };


        //
        //Parameters
        //

        $('table#parameters_list').on('click', 'span.dt_btns', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            switch (id_parts[0]) {
                case "edt":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.paramList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {
                                $scope.parameter = angular.copy($scope.model.paramList[index]);
                                $scope.ValidateFormById('frmParameter');
                                toastr['warning']('You are editing ' + $scope.parameter.Reason, $scope.toastr_title);
                                $('div#mdlParameters').modal('show');
                            }
                        }
                    });
                    break;
                case "del":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.paramList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {
                                $scope.parameter = angular.copy($scope.model.paramList[index]);
                                $scope.DeleteParameterInfo($scope.model.U.UserName, $scope.parameter);
                                toastr['danger']('You are deleting ' + $scope.parameter.Reason, $scope.toastr_title);
                            }
                        }
                    });
                    break;
                case "cln":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.paramList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {

                                $scope.parameter = angular.copy($scope.model.paramList[index]);
                                $scope.parameter.Id = 0;
                                $scope.ValidateFormById('frmParameter');
                                toastr['warning']('You are editing ' + $scope.parameter.Reason, $scope.toastr_title);
                                $('div#mdlParameters').modal('show');
                            }
                        }
                    });
                    break;
                default:
                    break;
            }

        });




        $scope.dtParameter = null;
        $scope.RefreshParametersTable = function () {
            $scope.$evalAsync(function () {

                var lengthMenu = [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ];
                var btns = [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="text-success bx bxs-spreadsheet"></i>',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="text-danger bx bxs-file-pdf"></i>',
                        titleAttr: 'Export to PDF'
                    }
                ];
                var clms = [

                    {
                        "mData": "Id",
                        "bSortable": false,
                        "mRender": function (data, type, gcb) {
                            var edBtns = '<span title="Edit Parameter" id="edt_' + data + '" class="text-primary dt_btns bx bx-edit"></span>';
                            edBtns += '<span title="Delete Parameter" id="del_' + data + '" class="text-danger dt_btns bx bx-trash"></span>';
                            edBtns += '<span title="Clone Parameter" id="cln_' + data + '" class="text-success dt_btns bx bx-copy"></span>';
                            return edBtns;
                        }
                    },
                    { "mData": "Name" },
                    { "mData": "Desc" },
                    { "mData": "Datatype" },
                    { "mData": "IsNumber" },
                    { "mData": "Min" },
                    { "mData": "Max" },
                    { "mData": "Regex" },
                    { "mData": "IsEnabled" },
                    { "mData": "IsRequired" },
                    { "mData": "Unit" },
                    { "mData": "InpType" },
                    { "mData": "InpValues" },
                    { "mData": "InpField" },
                ];

                //<th>Name</th>
                //<th>Desc</th>
                //<th>Datatype</th>
                //<th>IsNumber</th>
                //<th>Min</th>
                //<th>Max</th>
                //<th>Regex</th>
                //<th>IsEnabled</th>
                //<th>IsRequired</th>
                //<th>Unit</th>
                //<th>InpType</th>
                //<th>InpValues</th>
                //<th>InpField</th>

                if ($scope.dtParameter === null) {
                    $scope.dtParameter = $("table#parameters_list").dataTable({
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: lengthMenu,
                        data: $scope.model.paramList,
                        buttons: btns,
                        columns: clms
                    });
                }
                else {
                    $scope.dtParameter.fnClearTable();
                    $scope.dtParameter.fnAddData($scope.model.paramList); // Add new data
                    $scope.dtParameter.fnDraw(); // Redraw the DataTable
                }
            });
        };


        $scope.AddNewParameter = function () {
            $scope.$evalAsync(function () {
                $scope.parameter = {};
                $scope.parameter.Id = 0;
                $scope.parameter.DId = $scope.model.D.Id;
            });
        };
        $scope.AddUpdateParameterInfo = function (user) {
            if ($scope.frmParameter.$valid) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateParameterInformation(user);
                    });
                }
                else {
                    $scope.UpdateParameterInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateParameterInformation = function (user) {
            $scope.dataEntryHub.server.updateParameterInformation(user, JSON.stringify($scope.parameter)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $('#mdlParameters').modal('hide');
                        $scope.parameter = {};
                        toastr['success']('Parameter Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Parameter information!' + data, $scope.toastr_title);
                    }
                });
            });
        };
        $scope.DeleteParameterInfo = function (user, item2delete) {
            var r = confirm("Are you sure to delete this Parameter " + item2delete.Reason);
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteParameterInformation(user, item2delete);
                    });
                }
                else {
                    $scope.DeleteParameterInformation(user, item2delete);
                }
            }
        };
        $scope.DeleteParameterInformation = function (user, item2delete) {
            $scope.dataEntryHub.server.deleteParameterInformation(user, JSON.stringify(item2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Parameter deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Parameter information!', $scope.toastr_title);
                    }
                });
            });
        };
        $scope.dataEntryHub.client.refreshParameters = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.D.Id) {
                    index = _.findIndex($scope.model.paramList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.paramList[index] = data;
                    }
                    else {
                        $scope.model.paramList.push(data);
                    }
                    $scope.parameter = {};
                    $scope.RefreshParametersTable();
                    toastr['success']('Parameter Refreshed Successfully!', $scope.toastr_title);
                }

            });
        };
        $scope.dataEntryHub.client.refreshParametersAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.D.Id) {
                    index = _.findIndex($scope.model.paramList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.paramList.splice(index, 1);
                        toastr['success']('Parameter Refreshed Successfully!', $scope.toastr_title);
                        $scope.parameter = {};
                        $scope.RefreshParametersTable();
                    }
                }

            });
        };

        //
        //Parameters
        //


        //
        //Machines
        //

        $('table#machines_list').on('click', 'span.dt_btns', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            switch (id_parts[0]) {
                case "edt":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.mcnList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {
                                $scope.machine = angular.copy($scope.model.mcnList[index]);
                                $scope.ValidateFormById('frmMachine');
                                toastr['warning']('You are editing ' + $scope.machine.Reason, $scope.toastr_title);
                                $('div#mdlMachines').modal('show');
                            }
                        }
                    });
                    break;
                case "del":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.mcnList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {
                                $scope.machine = angular.copy($scope.model.mcnList[index]);
                                $scope.DeleteMachineInfo($scope.model.U.UserName, $scope.machine);
                                toastr['danger']('You are deleting ' + $scope.machine.Reason, $scope.toastr_title);
                            }
                        }
                    });
                    break;
                case "cln":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.mcnList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {

                                $scope.machine = angular.copy($scope.model.mcnList[index]);
                                $scope.machine.Id = 0;
                                $scope.ValidateFormById('frmMachine');
                                toastr['warning']('You are editing ' + $scope.machine.Reason, $scope.toastr_title);
                                $('div#mdlMachines').modal('show');
                            }
                        }
                    });
                    break;
                default:
                    break;
            }

        });




        $scope.dtMachine = null;
        $scope.RefreshMachinesTable = function () {
            $scope.$evalAsync(function () {

                var lengthMenu = [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ];
                var btns = [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="text-success bx bxs-spreadsheet"></i>',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="text-danger bx bxs-file-pdf"></i>',
                        titleAttr: 'Export to PDF'
                    }
                ];
                var clms = [

                    {
                        "mData": "Id",
                        "bSortable": false,
                        "mRender": function (data, type, gcb) {
                            var edBtns = '<span title="Edit Machine" id="edt_' + data + '" class="text-primary dt_btns bx bx-edit"></span>';
                            edBtns += '<span title="Delete Machine" id="del_' + data + '" class="text-danger dt_btns bx bx-trash"></span>';
                            edBtns += '<span title="Clone Machine" id="cln_' + data + '" class="text-success dt_btns bx bx-copy"></span>';
                            return edBtns;
                        }
                    },
                    { "mData": "Name" },
                    { "mData": "Desc" },
                    { "mData": "IsEnabled" },
                ];


                if ($scope.dtMachine === null) {
                    $scope.dtMachine = $("table#machines_list").dataTable({
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: lengthMenu,
                        data: $scope.model.mcnList,
                        buttons: btns,
                        columns: clms
                    });
                }
                else {
                    $scope.dtMachine.fnClearTable();
                    $scope.dtMachine.fnAddData($scope.model.mcnList); // Add new data
                    $scope.dtMachine.fnDraw(); // Redraw the DataTable
                }
            });
        };


        $scope.AddNewMachine = function () {
            $scope.$evalAsync(function () {
                $scope.machine = {};
                $scope.machine.Id = 0;
                $scope.machine.DId = $scope.model.D.Id;
            });
        };
        $scope.AddUpdateMachineInfo = function (user) {
            if ($scope.frmMachine.$valid) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateMachineInformation(user);
                    });
                }
                else {
                    $scope.UpdateMachineInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateMachineInformation = function (user) {
            $scope.dataEntryHub.server.updateMachineInformation(user, JSON.stringify($scope.machine)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $('#mdlMachines').modal('hide');
                        $scope.machine = {};
                        toastr['success']('Machine Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Machine information!' + data, $scope.toastr_title);
                    }
                });
            });
        };
        $scope.DeleteMachineInfo = function (user, item2delete) {
            var r = confirm("Are you sure to delete this Machine " + item2delete.Name);
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteMachineInformation(user, item2delete);
                    });
                }
                else {
                    $scope.DeleteMachineInformation(user, item2delete);
                }
            }
        };
        $scope.DeleteMachineInformation = function (user, item2delete) {
            $scope.dataEntryHub.server.deleteMachineInformation(user, JSON.stringify(item2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Machine deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Machine information!', $scope.toastr_title);
                    }
                });
            });
        };
        $scope.dataEntryHub.client.refreshMachines = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.D.Id) {
                    index = _.findIndex($scope.model.mcnList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.mcnList[index] = data;
                    }
                    else {
                        $scope.model.mcnList.push(data);
                    }
                    $scope.machine = {};
                    $scope.RefreshMachinesTable();
                    toastr['success']('Machine Refreshed Successfully!', $scope.toastr_title);
                }

            });
        };
        $scope.dataEntryHub.client.refreshMachinesAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.D.Id) {
                    index = _.findIndex($scope.model.mcnList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.mcnList.splice(index, 1);
                        toastr['success']('Machine Refreshed Successfully!', $scope.toastr_title);
                        $scope.machine = {};
                        $scope.RefreshMachinesTable();
                    }
                }

            });
        };

        //
        //Machines
        //

        //Equipments
        //

        $('table#equipments_list').on('click', 'span.dt_btns', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            switch (id_parts[0]) {
                case "edt":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.eqpList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {
                                $scope.equipment = angular.copy($scope.model.eqpList[index]);
                                $scope.ValidateFormById('frmEquipment');
                                toastr['warning']('You are editing ' + $scope.equipment.Name, $scope.toastr_title);
                                $('div#mdlEquipments').modal('show');
                            }
                        }
                    });
                    break;
                case "del":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.eqpList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {
                                $scope.equipment = angular.copy($scope.model.eqpList[index]);
                                $scope.DeleteEquipmentInfo($scope.model.U.UserName, $scope.equipment);
                                toastr['danger']('You are deleting ' + $scope.equipment.Name, $scope.toastr_title);
                            }
                        }
                    });
                    break;
                case "cln":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.eqpList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {

                                $scope.equipment = angular.copy($scope.model.eqpList[index]);
                                $scope.equipment.Id = 0;
                                $scope.ValidateFormById('frmEquipment');
                                toastr['warning']('You are editing ' + $scope.equipment.Name, $scope.toastr_title);
                                $('div#mdlEquipments').modal('show');
                            }
                        }
                    });
                    break;
                default:
                    break;
            }

        });




        $scope.dtEquipment = null;
        $scope.RefreshEquipmentsTable = function () {
            $scope.$evalAsync(function () {

                var lengthMenu = [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ];
                var btns = [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="text-success bx bxs-spreadsheet"></i>',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="text-danger bx bxs-file-pdf"></i>',
                        titleAttr: 'Export to PDF'
                    }
                ];
                var clms = [

                    {
                        "mData": "Id",
                        "bSortable": false,
                        "mRender": function (data, type, gcb) {
                            var edBtns = '<span title="Edit Equipment" id="edt_' + data + '" class="text-primary dt_btns bx bx-edit"></span>';
                            edBtns += '<span title="Delete Equipment" id="del_' + data + '" class="text-danger dt_btns bx bx-trash"></span>';
                            edBtns += '<span title="Clone Equipment" id="cln_' + data + '" class="text-success dt_btns bx bx-copy"></span>';
                            return edBtns;
                        }
                    },
                    { "mData": "Name" },
                    { "mData": "Desc" },
                    { "mData": "IsEnabled" },
                ];


                if ($scope.dtEquipment === null) {
                    $scope.dtEquipment = $("table#equipments_list").dataTable({
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: lengthMenu,
                        data: $scope.model.eqpList,
                        buttons: btns,
                        columns: clms
                    });
                }
                else {
                    $scope.dtEquipment.fnClearTable();
                    $scope.dtEquipment.fnAddData($scope.model.eqpList); // Add new data
                    $scope.dtEquipment.fnDraw(); // Redraw the DataTable
                }
            });
        };


        $scope.AddNewEquipment = function () {
            $scope.$evalAsync(function () {
                $scope.equipment = {};
                $scope.equipment.Id = 0;
                $scope.equipment.DId = $scope.model.D.Id;
            });
        };
        $scope.AddUpdateEquipmentInfo = function (user) {
            if ($scope.frmEquipment.$valid) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateEquipmentInformation(user);
                    });
                }
                else {
                    $scope.UpdateEquipmentInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateEquipmentInformation = function (user) {
            $scope.dataEntryHub.server.updateEquipmentInformation(user, JSON.stringify($scope.equipment)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $('#mdlEquipments').modal('hide');
                        $scope.equipment = {};
                        toastr['success']('Equipment Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Equipment information!' + data, $scope.toastr_title);
                    }
                });
            });
        };
        $scope.DeleteEquipmentInfo = function (user, item2delete) {
            var r = confirm("Are you sure to delete this Equipment " + item2delete.Name);
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteEquipmentInformation(user, item2delete);
                    });
                }
                else {
                    $scope.DeleteEquipmentInformation(user, item2delete);
                }
            }
        };
        $scope.DeleteEquipmentInformation = function (user, item2delete) {
            $scope.dataEntryHub.server.deleteEquipmentInformation(user, JSON.stringify(item2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Equipment deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Equipment information!', $scope.toastr_title);
                    }
                });
            });
        };
        $scope.dataEntryHub.client.refreshEquipments = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.D.Id) {
                    index = _.findIndex($scope.model.eqpList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.eqpList[index] = data;
                    }
                    else {
                        $scope.model.eqpList.push(data);
                    }
                    $scope.equipment = {};
                    $scope.RefreshEquipmentsTable();
                    toastr['success']('Equipment Refreshed Successfully!', $scope.toastr_title);
                }

            });
        };
        $scope.dataEntryHub.client.refreshEquipmentsAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.D.Id) {
                    index = _.findIndex($scope.model.eqpList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.eqpList.splice(index, 1);
                        toastr['success']('Equipment Refreshed Successfully!', $scope.toastr_title);
                        $scope.equipment = {};
                        $scope.RefreshEquipmentsTable();
                    }
                }

            });
        };

        //
        //Equipments
        //


        //Titles
        //

        $('table#titles_list').on('click', 'span.dt_btns', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            switch (id_parts[0]) {
                case "edt":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.tList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {
                                $scope.title = angular.copy($scope.model.tList[index]);
                                $scope.ValidateFormById('frmTitle');
                                toastr['warning']('You are editing ' + $scope.title.Name, $scope.toastr_title);
                                $('div#mdlTitles').modal('show');
                            }
                        }
                    });
                    break;
                case "del":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.tList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {
                                $scope.title = angular.copy($scope.model.tList[index]);
                                $scope.DeleteTitleInfo($scope.model.U.UserName, $scope.title);
                                toastr['danger']('You are deleting ' + $scope.title.Name, $scope.toastr_title);
                            }
                        }
                    });
                    break;
                case "cln":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.tList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {

                                $scope.title = angular.copy($scope.model.tList[index]);
                                $scope.title.Id = 0;
                                $scope.ValidateFormById('frmTitle');
                                toastr['warning']('You are editing ' + $scope.title.Name, $scope.toastr_title);
                                $('div#mdlTitles').modal('show');
                            }
                        }
                    });
                    break;
                default:
                    break;
            }

        });




        $scope.dtTitle = null;
        $scope.RefreshTitlesTable = function () {
            $scope.$evalAsync(function () {

                var lengthMenu = [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ];
                var btns = [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="text-success bx bxs-spreadsheet"></i>',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="text-danger bx bxs-file-pdf"></i>',
                        titleAttr: 'Export to PDF'
                    }
                ];
                var clms = [

                    {
                        "mData": "Id",
                        "bSortable": false,
                        "mRender": function (data, type, gcb) {
                            var edBtns = '<span title="Edit Title" id="edt_' + data + '" class="text-primary dt_btns bx bx-edit"></span>';
                            edBtns += '<span title="Delete Title" id="del_' + data + '" class="text-danger dt_btns bx bx-trash"></span>';
                            edBtns += '<span title="Clone Title" id="cln_' + data + '" class="text-success dt_btns bx bx-copy"></span>';
                            return edBtns;
                        }
                    },
                    { "mData": "Name" },
                    { "mData": "Desc" },
                    { "mData": "IsEnabled" },
                    { "mData": "Remarks" },
                ];


                if ($scope.dtTitle === null) {
                    $scope.dtTitle = $("table#titles_list").dataTable({
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: lengthMenu,
                        data: $scope.model.tList,
                        buttons: btns,
                        columns: clms
                    });
                }
                else {
                    $scope.dtTitle.fnClearTable();
                    $scope.dtTitle.fnAddData($scope.model.tList); // Add new data
                    $scope.dtTitle.fnDraw(); // Redraw the DataTable
                }
            });
        };


        $scope.AddNewTitle = function () {
            $scope.$evalAsync(function () {
                $scope.title = {};
                $scope.title.Id = 0;
                $scope.title.DId = $scope.model.D.Id;
            });
        };
        $scope.AddUpdateTitleInfo = function (user) {
            if ($scope.frmTitle.$valid) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateTitleInformation(user);
                    });
                }
                else {
                    $scope.UpdateTitleInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateTitleInformation = function (user) {
            $scope.title.DId = $scope.model.D.Id;
            $scope.dataEntryHub.server.updateTitleInformation(user, JSON.stringify($scope.title)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $('#mdlTitles').modal('hide');
                        $scope.title = {};
                        toastr['success']('Title Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Title information!' + data, $scope.toastr_title);
                    }
                });
            });
        };
        $scope.DeleteTitleInfo = function (user, item2delete) {
            var r = confirm("Are you sure to delete this Title " + item2delete.Name);
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteTitleInformation(user, item2delete);
                    });
                }
                else {
                    $scope.DeleteTitleInformation(user, item2delete);
                }
            }
        };
        $scope.DeleteTitleInformation = function (user, item2delete) {
            $scope.dataEntryHub.server.deleteTitleInformation(user, JSON.stringify(item2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Title deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Title information!', $scope.toastr_title);
                    }
                });
            });
        };
        $scope.dataEntryHub.client.refreshTitles = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.D.Id) {
                    index = _.findIndex($scope.model.tList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.tList[index] = data;
                    }
                    else {
                        $scope.model.tList.push(data);
                    }
                    $scope.title = {};
                    $scope.RefreshTitlesTable();
                    toastr['success']('Title Refreshed Successfully!', $scope.toastr_title);
                }

            });
        };
        $scope.dataEntryHub.client.refreshTitlesAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.D.Id) {
                    index = _.findIndex($scope.model.tList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.tList.splice(index, 1);
                        toastr['success']('Title Refreshed Successfully!', $scope.toastr_title);
                        $scope.title = {};
                        $scope.RefreshTitlesTable();
                    }
                }

            });
        };

        //
        //Titles
        //
    }]);


    app.filter('ceil', function () {
        return function (input) {
            return Math.ceil(input);
        };
    });

    app.directive('enterAsTab', function () {
        return function (scope, element, attrs) {
            element.bind("keydown keypress", function (event) {
                if (event.which === 13) {
                    event.preventDefault();
                    var elementToFocus = element.parent().next().find('input, select, textarea, button')[0];
                    if (angular.isDefined(elementToFocus)) {
                        elementToFocus.focus();
                    }
                    else {
                        elementToFocus = element.parent().parent().next().find('input, select, textarea, button')[0];
                        if (angular.isDefined(elementToFocus)) {
                            elementToFocus.focus();
                        }
                    }
                }
            });
        };
    });

}());
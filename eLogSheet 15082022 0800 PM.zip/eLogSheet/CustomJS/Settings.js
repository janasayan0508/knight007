﻿(function () {
    var app = angular.module('HMSApp', []);
    app.controller('HMSController', ['$scope', '$http', '$filter', function ($scope, $http, $filter) {

        $scope.ConnectionStarted = false;

        //toaster options
        toastr.options = { 'closeButton': 'true', 'debug': false, 'newestOnTop': true, 'progressBar': true, 'positionClass': 'toast-bottom-left', 'preventDuplicates': true, 'onclick': null, 'showDuration': '5000', 'hideDuration': '1200', 'timeOut': '2000', 'extendedTimeOut': '1500', 'showEasing': 'swing', 'hideEasing': 'linear', 'showMethod': 'fadeIn', 'hideMethod': 'fadeOut' };
        $scope.toastr_title = 'ePractice Powered by GPRN!';

        $scope.FC_CV_MIN_DT = '';
        $scope.FC_CV_MAX_DT = '';
        $scope.cdthList = [];

        $scope.dtList = {};

        $scope.dtList['TAB'] = 'TAB';
        $scope.dtList['CAP'] = 'CAP';
        $scope.dtList['PWD'] = 'PWD';
        $scope.dtList['OIN'] = 'OIN';
        $scope.dtList['INJ'] = 'INJ';
        $scope.dtList['OIL'] = 'OIL';
        $scope.dtList['SYP'] = 'SYP';


        $scope.dcList = {};

        $scope.dcList[1] = 1;
        $scope.dcList[2] = 2;
        $scope.dcList[3] = 3;
        $scope.dcList[4] = 4;

        $scope.dsList = {};

        $scope.dsList["AD"] = 0.5;
        $scope.dsList["AFTER LUNCH"] = 1;
        $scope.dsList["BD"] = 2;
        $scope.dsList["HS"] = 1;
        $scope.dsList["OD"] = 1;
        $scope.dsList["OD/BD"] = 1;
        $scope.dsList["ONCE A WK"] = 0.13;
        $scope.dsList["QID"] = 4;
        $scope.dsList["SOS"] = 0;
        $scope.dsList["STAT"] = 1;
        $scope.dsList["TDS"] = 1;
        $scope.dsList["TID"] = 3;
        $scope.dsList["TWICE A WK"] = 0.25;

        $scope.clinicHub = $.connection.clinicHub; // initializes hub
        $scope.ConnectionStarted = false;

        $('form.bv-form').each(function () {
            var frmId = $(this).attr('id');
            $('#' + frmId + ' .form-control').on("blur, change", function () {
                var nm = $(this).attr('name');
                $('#' + frmId + '').bootstrapValidator('revalidateField', nm);
            });
        });

        $scope.ValidateFormById = function (frmId) {
            $scope.$evalAsync(function () {
                $('#' + frmId + ' .form-control').each(function () {
                    var nm = $(this).attr('name');
                    $('#' + frmId + '').bootstrapValidator('revalidateField', nm);
                });
            });
        };
        $scope.NewApptAllowed = true;
        $scope.model = {};
        $scope.appCalendar = {};

        var today = new Date();
        today.setDate(today.getDate() - 1);

        angular.element(document).ready(function () {

            $scope.$evalAsync(function () {

                $scope.base_url = $(location).attr('host');

                $scope.model = $.parseJSON($('p#modelData').text());
                $('p#modelData').text('');

                for (var ic in $scope.model.list) {
                    $scope.model.list[ic].iList = $.parseJSON($scope.model.list[ic].JsonStr);
                }

                $(".filter_list").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $(this).parent().parent().find('ul li').filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                    });
                    $(this).parent().find('.btn-success').toggle($(this).parent().parent().find('ul li:visible').length <= 0);

                });


                $scope.appCalendar = new FullCalendar.Calendar($('div#calendar')[0], {
                    headerToolbar: {
                        left: 'prev,next today',
                        center: 'title',
                        right: ''
                    },
                    nextDayThreshold: "00:00:00",
                    initialDate: new Date(),
                    editable: true,
                    eventAllow: function (dropInfo, draggedEvent) {
                        return false;
                    },
                    navLinks: false, // can click day/week names to navigate views
                    dayMaxEvents: true, // allow "more" link when too many events
                    events: [],
                    loading: function (bool) {
                        $scope.$evalAsync(function () {
                            if (bool) {

                            }
                            else {

                                $scope.$evalAsync(function () {
                                    $scope.FC_CV_MIN_DT = $('div#calendar .fc-daygrid-day:first').attr('data-date');
                                    $scope.FC_CV_MAX_DT = $('div#calendar .fc-daygrid-day:last').attr('data-date');
                                    //
                                    //toastr['success']('Calendar Loaded ' + $('div#calendar .fc-daygrid-day:first').attr('data-date') + '', $scope.toastr_title);
                                });

                                
                            }
                        });
                    },
                    dateClick: function (info) {
                        $scope.$evalAsync(function () {
                            $scope.NewApptAllowed = info.date >= today;
                        });
                    }
                });
                $scope.appCalendar.render();

                $.connection.hub.start().done(function () {
                    $scope.ConnectionStarted = true;

                    toastr['info']('Hub Started!', $scope.toastr_title);

                    $scope.GetClinicHolidaysListForDateRange();
                    $scope.RefreshCategoryDataTable();
                    $scope.RefreshDrugDataTable();
                    $scope.RefreshItemDataTable();
                    $scope.RefreshSymptomDataTable();
                }); // starts hub

                $('.datepicker').daterangepicker({
                    singleDatePicker: false,
                    showDropdowns: true,
                    drops: "auto",
                    minDate: new Date(),
                    autoUpdateInput: false,
                    autoApply: false,
                    locale: {
                        format: 'YYYY-MM-DD',
                        cancelLabel: 'Clear'
                    }
                });
                $('.datepicker').on('show.daterangepicker', () => {
                    $('.daterangepicker').removeClass('auto-apply');
                });
                $('.datepicker').on('cancel.daterangepicker', function (ev, picker) {
                    var nm = $(this).attr('name');
                    $scope.$evalAsync(function () {
                        $scope.cHoliday[nm] = null;
                        $scope.cHoliday['ChStartDt'] = null;
                        $scope.cHoliday['ChEndDt'] = null;
                    });
                });
                $('.datepicker').on('apply.daterangepicker', function (ev, picker) {
                    var nm = $(this).attr('name');
                    $scope.$evalAsync(function () {
                        $scope.cHoliday[nm] = picker.startDate.format('DD/MM/YYYY') + '-' + picker.endDate.format('DD/MM/YYYY');
                        $scope.cHoliday['ChStartDt'] = picker.startDate.format('YYYY-MM-DDT00:00:00');
                        $scope.cHoliday['ChEndDt'] = picker.endDate.format('YYYY-MM-DDT23:59:55');
                    });
                });


            });
        });

        $scope.CheckUncheck = function (nm) {
            $scope.$evalAsync(function () {
                $('input.' + nm).attr('checked', $('input.' + nm).is(':checked'));
                $('input.' + nm).val($('input.' + nm).is(':checked'));
            });
        };


        //
        //Update Setting Item Collection
        //

        $scope.AddNewCollection = function (tb_id) {
            $scope.$evalAsync(function () {
                var nm = $('input#' + tb_id).val();
                if(!$scope.model.list.hasOwnProperty(nm))
                {
                    $scope.model.list[nm] = {};
                    $scope.model.list[nm].Id = 0;
                    $scope.model.list[nm].NM = nm;
                    $scope.model.list[nm].DId = $scope.model.C.Id;
                    $scope.model.list[nm].UId = $scope.model.U.U;
                    $scope.model.list[nm].NM = nm;
                    $scope.model.list[nm].JsonStr = "[]";
                    $scope.model.list[nm].iList = [];
                    $scope.UpdateSettingCollection(nm);
                    $('input#' + tb_id).focus().select();
                }
            });
        };

        $scope.ManageListForGroup = function (nm) {
            $scope.$evalAsync(function () {
                $scope.cname = nm;
                $scope.model.list[nm].iList = $.parseJSON($scope.model.list[nm].JsonStr);
                toastr['info']('Currently Managing Items For: ' + nm + '!', $scope.toastr_title);
            });
        };

        $scope.AddItem2Collection = function (tb_id) {
            $scope.$evalAsync(function () {
                var item = $('input#' + tb_id).val();
                if ($scope.model.list.hasOwnProperty($scope.cname)) {
                    var index = $scope.model.list[$scope.cname].iList.indexOf(item);
                    if (index < 0) {
                        $scope.model.list[$scope.cname].iList.push(item);
                        $scope.UpdateSettingCollection($scope.cname);
                        $('input#' + tb_id).focus().select();
                    }
                    
                }
            });
        };

        $scope.RemoveItemFromCollection = function (item) {
            $scope.$evalAsync(function () {

                if ($scope.model.list.hasOwnProperty($scope.cname)) {
                    var index = $scope.model.list[$scope.cname].iList.indexOf(item);
                    if (index >= 0) {
                        var r = confirm('Are you sure to remove ' + item + ' from ' + $scope.cname + ' collection?');
                        if (r) {
                            $scope.model.list[$scope.cname].iList.splice(index, 1);
                            $scope.UpdateSettingCollection($scope.cname);
                        }
                    }
                    
                }
            });
        };

        $scope.UpdateSettingCollection = function (name) {
            $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
            if (!$scope.ConnectionStarted) {
                $.connection.hub.start().done(function () {
                    $scope.ConnectionStarted = true;
                    $scope.UpdateSettingCollectionInfo(name);
                });
            }
            else {
                $scope.UpdateSettingCollectionInfo(name);
            }
        };
        $scope.UpdateSettingCollectionInfo = function (name) {
            $scope.clinicHub.server.updateSetting4Param($scope.model.U.U, $scope.model.C.Id, name, JSON.stringify($scope.model.list[name].iList)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data !== "") {
                        var obj = $.parseJSON(data);
                        $scope.model.list[obj.name] = Object.assign({}, obj);
                        $scope.model.list[obj.name].iList = $.parseJSON(obj.JsonStr);
                        toastr['success']( name + ' Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating ' + name + ' information!', $scope.toastr_title);
                    }
                });
            });
        };


        //
        //Update Setting Item Collection
        //


        //Clinic Leave Updates

        $('table#cHoliday_list').on('click', 'button.action', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            if (id_parts.length > 1) {
                $scope.$evalAsync(function () {
                    var index = _.findIndex($scope.dthList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        switch (id_parts[0]) {
                            case "edit":
                                $scope.cHoliday = angular.copy($scope.dthList[index]);
                                $scope.cHoliday.DtRange = $filter('date')($scope.cHoliday.ChStartDt, 'dd/MM/yyyy') + '-' + $filter('date')($scope.cHoliday.ChEndDt, 'dd/MM/yyyy');
                                break;
                            case "delete":
                                var r = confirm("Are you sure to delete this holiday for " + $scope.dthList[index].PtName + '?');
                                if (r) {
                                    $scope.DeleteClinicHolidayInfo($scope.model.U.N, $scope.dthList[index]);
                                }
                                break;
                            default:
                                break;
                        }
                    }
                });
            }
        });

        $scope.dtcHolidayTable = null;
        $scope.RefreshClinicHolidaysTable = function () {
            $scope.$evalAsync(function () {
                if ($scope.dtcHolidayTable === null) {

                    $scope.dtcHolidayTable = $("table#cHoliday_list").dataTable({
                        language: { search: '', searchPlaceholder: "Search" },
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: [
                            [10, 25, 50, -1],
                            ['10 rows', '25 rows', '50 rows', 'Show all']
                        ],
                        "bDestroy": true,
                        data: $scope.dthList,
                        buttons: [
                            {
                                extend: 'excelHtml5',
                                text: '<i class="bx bx-spreadsheet text-success"></i>',
                                titleAttr: 'Export to Excel'
                            },
                            {
                                extend: 'pdfHtml5',
                                text: '<i class="bx bxs-file-pdf text-danger"></i>',
                                titleAttr: 'Export to PDF'
                            }
                        ],
                        columns: [
                            {
                                "mData": "Id",
                                "bSortable": true,
                                "mRender": function (data, type, row) {
                                    var bt1 = '<button class="action btn btn-warning" id="edit_' + data + '"><b class="bx bx-edit"></b></button>';
                                    bt1 += '<button class="action btn btn-danger" id="delete_' + data + '"><b class="bx bx-trash"></b></button>';
                                    return (row.BillId > 0) ? '' : bt1;
                                }
                            },
                            { "mData": "ChReason" },
                            {
                                "mData": "ChStartDt",
                                "bSortable": true,
                                "mRender": function (data, type, puc) {

                                    return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                                }
                            },
                            {
                                "mData": "ChEndDt",
                                "bSortable": true,
                                "mRender": function (data, type, puc) {

                                    return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                                }
                            },
                            { "mData": "UpdatedBy" },
                            {
                                "mData": "UpdatedOn",
                                "bSortable": true,
                                "mRender": function (data, type, puc) {

                                    return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                                }
                            }
                        ]
                    });
                }
                else {
                    $scope.dtcHolidayTable.fnClearTable();
                    if ($scope.dthList.length > 0) {
                        $scope.dtcHolidayTable.fnAddData($scope.dthList); // Add new data
                        $scope.dtcHolidayTable.fnDraw(); // Redraw the DataTable
                    }
                }
            });
        };

        $scope.ManageClinicHolidays = function () {
            $scope.$evalAsync(function () {
                RefreshClinicHolidaysTable();
            });
        };

        $scope.AddClinicHoliday = function () {
            $scope.$evalAsync(function () {
                $scope.cHoliday = {};
                $scope.cHoliday.DId = $scope.model.C.DId;
                $scope.cHoliday.Id = 0;
            });
        };

        $scope.UpdateClinicHoliday = function (cHoliday) {
            $scope.$evalAsync(function () {
                $scope.cHoliday = cHoliday;
                $scope.cHoliday.DtRange = $filter('date')(cHoliday.ChStartDt, 'dd/MM/yyyy') + '-' + $filter('date')(cHoliday.ChEndDt, 'dd/MM/yyyy');
            });
        };

        $scope.dthList = [];

        $scope.AddUpdateClinicHolidayInfo = function (user) {
            if ($scope.frmHoliday.$valid) {
                $('form[name="frmHoliday"] button[type="submit"]').prop('disabled', true);
                $scope.cHoliday.DId = $scope.model.C.Id;
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateClinicHolidayInformation(user);
                    });
                }
                else {
                    $scope.UpdateClinicHolidayInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateClinicHolidayInformation = function (user) {
            $scope.clinicHub.server.updateClinicHolidayInformation(user, JSON.stringify($scope.cHoliday)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $scope.cHoliday = {};
                        toastr['success']('ClinicHoliday Booked for patient successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating ClinicHoliday information!', $scope.toastr_title);
                    }
                    $('form[name="frmHoliday"] button[type="submit"]').prop('disabled', false);
                });
            });
        };

        $scope.DeleteClinicHolidayInfo = function (user, ch2delete) {
            $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
            if (!$scope.ConnectionStarted) {
                $.connection.hub.start().done(function () {
                    $scope.ConnectionStarted = true;
                    $scope.DeleteClinicHolidayInformation(user, ch2delete);
                });
            }
            else {
                $scope.DeleteClinicHolidayInformation(user, ch2delete);
            }
        };
        $scope.DeleteClinicHolidayInformation = function (user, ch2delete) {
            $scope.clinicHub.server.deleteClinicHolidayInformation(user, JSON.stringify(ch2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Clinic Holiday deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Clinic Holiday information!', $scope.toastr_title);
                    }
                });
            });
        };


        $scope.GetClinicHolidaysListForDateRange = function () {
            $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
            if (!$scope.ConnectionStarted) {
                $.connection.hub.start().done(function () {
                    $scope.ConnectionStarted = true;
                    $scope.GetClinicHolidaysList();
                });
            }
            else {
                $scope.GetClinicHolidaysList();
            }
        };

        $scope.clHoliday = {};
        $scope.GetClinicHolidaysList = function () {
            $scope.clinicHub.server.getClinicHolidaysForDateRange($scope.model.C.Id, $scope.FC_CV_MIN_DT, $scope.FC_CV_MAX_DT).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data !== "") {
                        $scope.dthList = $.parseJSON(data);
                        //toastr['success']($scope.dthList.length + ' Clinic Holidays found!', $scope.toastr_title);
                        $scope.RefreshClinicHolidaysSource();
                    }
                    else {
                        toastr['error']('Error in getting Clinic Holiday information!', $scope.toastr_title);
                    }
                });

            });
        };
        $scope.appEvents = [];

        $scope.RefreshClinicHolidaysSource = function () {
            $scope.$evalAsync(function () {
                $scope.appEvents = [];
                for (var j in $scope.dthList) {
                    var endDate = new Date($scope.dthList[j].ChEndDt);
                    var startDate = new Date($scope.dthList[j].ChStartDt);
                    var strDt = '';
                    for (var day = startDate; day <= endDate; day.setDate(day.getDate() + 1)) {
                        strDt = $filter('date')(day, 'yyyy-MM-dd');
                        $('#calendar td.fc-daygrid-day[data-date="' + strDt + '"]')
                            .css({
                                'background-color': '#cecece'
                            });

                    }

                    $scope.appEvents.push({
                        title: $scope.dthList[j].ChReason,
                        description: $scope.dthList[j].ChReason,
                        start: $scope.dthList[j].ChStartDt,
                        end: endDate.setDate(endDate.getDate() + 1),
                        allDay: true,
                        backgroundColor: '#C66511'
                    });
                }
                $scope.appCalendar.removeAllEvents();
                $scope.appCalendar.addEventSource($scope.appEvents);
                $scope.RefreshClinicHolidaysTable();
            });
        };

        $scope.clinicHub.client.refreshClinicHolidays = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data !== null && data != undefined && data.DId === $scope.model.C.Id) {
                    var index = _.findIndex($scope.dthList, {
                        Id: data.Id
                    });
                    if (index >= 0) {
                        $scope.dthList[index] = data;
                        toastr['success']('Holidays Refreshed Successfully!', $scope.toastr_title);
                    }
                    else {
                        $scope.dthList.push(data);
                    }
                    $scope.RefreshClinicHolidaysSource();
                }

            });
        };

        $scope.clinicHub.client.refreshClinicHolidaysAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data !== null && data != undefined && data.DId === $scope.model.C.Id) {
                    var index = _.findIndex($scope.dthList, {
                        Id: data.Id
                    });
                    if (index >= 0) {
                        $scope.dthList.splice(index, 1);
                        toastr['success']('Holidays Refreshed Successfully!', $scope.toastr_title);
                    }
                    $scope.RefreshClinicHolidaysSource();
                }
            });
        };

        //Clinic Leave Updates

        //Render Category Groups

        $('table.dt-categories').on('click', 'span.item_edit', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.igList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.category = angular.copy($scope.model.igList[index]);
                        $scope.ValidateFormById('frmCategory');
                    }
                }
            });
        });
        $('table.dt-categories').on('click', 'span.item_clone', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.igList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.category = angular.copy($scope.model.igList[index]);
                        $scope.category.Id = 0;
                        $scope.ValidateFormById('frmCategory');
                    }
                }
            });
        });

        $('table.dt-categories').on('click', 'span.item_delete', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.igList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.category = angular.copy($scope.model.igList[index]);
                        $scope.DeleteCategoryInfo($scope.model.U.U, $scope.category);
                    }
                }
            });
        });

        $scope.dtCategory = null;
        $scope.RefreshCategoryDataTable = function () {
            $scope.$evalAsync(function () {

                var lengthMenu = [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ];
                var btns = [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="text-success bx bxs-spreadsheet"></i>',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="text-danger bx bxs-file-pdf"></i>',
                        titleAttr: 'Export to PDF'
                    }
                ];
                var clms = [
                    
                    {
                        "mData": "Id",
                        "bSortable": false,
                        "mRender": function (data, type, gcb) {
                            var edBtns = '<span title="Edit Category" id="item_' + data + '" class="text-primary dt_btns item_edit bx bx-edit"></span>';
                            edBtns += '<span title="Delete Category" id="item_' + data + '" class="text-danger dt_btns item_delete bx bx-trash"></span>';
                            edBtns += '<span title="Clone Category" id="item_' + data + '" class="text-success dt_btns item_clone bx bx-copy"></span>';
                            return edBtns;
                        }
                    },
                    { "mData": "ItGRP" },
                    { "mData": "UpdatedBy" },
                    {
                        "mData": "UpdatedOn",
                        "bSortable": true,
                        "mRender": function (data, type, puc) {

                            return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                        }
                    }
                ];

                if ($scope.dtCategory === null) {
                    $scope.dtCategory = $("table.dt-categories").dataTable({
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: lengthMenu,
                        data: $scope.model.igList,
                        buttons: btns,
                        columns: clms
                    });
                }
                else {
                    $scope.dtCategory.fnClearTable();
                    $scope.dtCategory.fnAddData($scope.model.igList); // Add new data
                    $scope.dtCategory.fnDraw(); // Redraw the DataTable
                }
            });
        };

        $scope.AddNewCategory = function () {
            $scope.$evalAsync(function () {
                $scope.category = {};
                $scope.category.Id = 0;
            });
        };
        $scope.AddUpdateCategoryInfo = function (user) {
            if ($scope.frmCategory.$valid) {
                $scope.category.DId = $scope.model.C.Id;
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateCategoryInformation(user);
                    });
                }
                else {
                    $scope.UpdateCategoryInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateCategoryInformation = function (user) {
            $scope.clinicHub.server.updateCategoryInformation(user, JSON.stringify($scope.category)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $('#mdlCategory').modal('hide');
                        $scope.category = {};
                        toastr['success']('Category Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Category information!' + data, $scope.toastr_title);
                    }
                });
            });
        };
        $scope.DeleteCategoryInfo = function (user, item2delete) {
            var r = confirm("Are you sure to delete this Category " + item2delete.Description + " (" + item2delete.Code + ")?");
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteCategoryInformation(user, item2delete);
                    });
                }
                else {
                    $scope.DeleteCategoryInformation(user, item2delete);
                }
            }
        };
        $scope.DeleteCategoryInformation = function (user, item2delete) {
            $scope.clinicHub.server.deleteCategoryInformation(user, JSON.stringify(item2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Category deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Category information!', $scope.toastr_title);
                    }
                });
            });
        };
        $scope.clinicHub.client.refreshCategories = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.C.Id) {
                    index = _.findIndex($scope.model.igList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.igList[index] = data;
                    }
                    else {
                        $scope.model.igList.push(data);
                    }
                    $scope.category = {};
                    $scope.RefreshCategoryDataTable();
                }
                toastr['success']('Category Refreshed Successfully for: ' + $scope.model.C.ClName + '!', $scope.toastr_title);
            });
        };
        $scope.clinicHub.client.refreshCategoriesAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.C.Id) {
                    index = _.findIndex($scope.model.igList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.igList.splice(index, 1);
                        toastr['success']('Category Refreshed Successfully for: ' + $scope.model.C.ClName + '!', $scope.toastr_title);
                        $scope.category = {};
                        $scope.RefreshCategoryDataTable();
                    }
                }

            });
        };

        //Render Category Groups

        //Render Drug Groups
        $('table.dt-drugs').on('click', 'span.drug_edit', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.drugList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.drug = angular.copy($scope.model.drugList[index]);
                        $scope.ValidateFormById('frmDrug');
                    }
                }
            });
        });
        $('table.dt-drugs').on('click', 'span.drug_clone', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.drugList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.drug = angular.copy($scope.model.drugList[index]);
                        $scope.drug.Id = 0;
                        $scope.ValidateFormById('frmDrug');
                    }
                }
            });
        });
        $('table.dt-drugs').on('click', 'span.drug_delete', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.drugList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.drug = angular.copy($scope.model.drugList[index]);
                        $scope.DeleteDrugInfo($scope.model.U.U, $scope.drug);
                    }
                }
            });
        });
        $scope.dtDrug = null;
        $scope.RefreshDrugDataTable = function () {
            $scope.$evalAsync(function () {

                var lengthMenu = [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ];
                var btns = [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="text-success bx bxs-spreadsheet"></i>',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="text-danger bx bxs-file-pdf"></i>',
                        titleAttr: 'Export to PDF'
                    }
                ];
                var clms = [

                    {
                        "mData": "Id",
                        "bSortable": false,
                        "mRender": function (data, type, gcb) {
                            var edBtns = '<span title="Edit Drug" id="drug_' + data + '" class="text-primary dt_btns drug_edit bx bx-edit"></span>';
                            edBtns += '<span title="Delete Drug" id="drug_' + data + '" class="text-danger dt_btns drug_delete bx bx-trash"></span>';
                            edBtns += '<span title="Clone Drug" id="item_' + data + '" class="text-success dt_btns item_clone bx bx-copy"></span>';
                            return edBtns;
                        }
                    },
                    { "mData": "Type" },
                    { "mData": "Code" },
                    { "mData": "Name" },
                    { "mData": "Amnt" },
                    { "mData": "Dose" }
                ];

                if ($scope.dtDrug === null) {
                    $scope.dtDrug = $("table.dt-drugs").dataTable({
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: lengthMenu,
                        data: $scope.model.drugList,
                        buttons: btns,
                        columns: clms
                    });
                }
                else {
                    $scope.dtDrug.fnClearTable();
                    $scope.dtDrug.fnAddData($scope.model.drugList); // Add new data
                    $scope.dtDrug.fnDraw(); // Redraw the DataTable
                }
            });
        };
        $scope.AddNewDrug = function () {
            $scope.$evalAsync(function () {
                $scope.drug = {};
                $scope.drug.Id = 0;
            });
        };
        $scope.AddUpdateDrugInfo = function (user) {
            if ($scope.frmDrug.$valid) {
                $scope.drug.DId = $scope.model.C.Id;
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateDrugInformation(user);
                    });
                }
                else {
                    $scope.UpdateDrugInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateDrugInformation = function (user) {
            $scope.clinicHub.server.updateDrugInformation(user, JSON.stringify($scope.drug)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $('#mdlDrug').modal('hide');
                        $scope.drug = {};
                        toastr['success']('Drug Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Drug information!' + data, $scope.toastr_title);
                    }
                });
            });
        };
        $scope.DeleteDrugInfo = function (user, drug2delete) {
            var r = confirm("Are you sure to delete this drug " + drug2delete.Description + " (" + drug2delete.Code + ")?");
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteDrugInformation(user, drug2delete);
                    });
                }
                else {
                    $scope.DeleteDrugInformation(user, drug2delete);
                }
            }
        };
        $scope.DeleteDrugInformation = function (user, drug2delete) {
            $scope.clinicHub.server.deleteDrugInformation(user, JSON.stringify(drug2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Drug deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Drug information!', $scope.toastr_title);
                    }
                });
            });
        };
        $scope.clinicHub.client.refreshDrugs = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.C.Id) {
                    index = _.findIndex($scope.model.drugList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.drugList[index] = data;
                    }
                    else {
                        $scope.model.drugList.push(data);
                    }
                    $scope.drug = {};
                    $scope.RefreshDrugDataTable();
                }
                toastr['success']('Drug Refreshed Successfully for: ' + $scope.model.C.ClName + '!', $scope.toastr_title);
            });
        };
        $scope.clinicHub.client.refreshDrugsAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.C.Id) {
                    index = _.findIndex($scope.model.drugList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.drugList.splice(index, 1);
                        toastr['success']('Drug Refreshed Successfully for: ' + $scope.model.C.ClName + '!', $scope.toastr_title);
                        $scope.drug = {};
                        $scope.RefreshDrugDataTable();
                    }
                }

            });
        };
        //Render Drug Groups


        //Render Item Groups
        $('table.dt-items').on('click', 'span.item_edit', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.itemList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.item = angular.copy($scope.model.itemList[index]);
                        $scope.ValidateFormById('frmItem');
                    }
                }
            });
        });
        $('table.dt-items').on('click', 'span.item_clone', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.itemList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.item = angular.copy($scope.model.itemList[index]);
                        $scope.item.Id = 0;
                        $scope.ValidateFormById('frmItem');
                    }
                }
            });
        });
        $('table.dt-items').on('click', 'span.item_delete', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.itemList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.item = angular.copy($scope.model.itemList[index]);
                        $scope.DeleteItemInfo($scope.model.U.U, $scope.item);
                    }
                }
            });
        });
        $scope.dtItem = null;
        $scope.RefreshItemDataTable = function () {
            $scope.$evalAsync(function () {

                var lengthMenu = [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ];
                var btns = [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="text-success bx bxs-spreadsheet"></i>',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="text-danger bx bxs-file-pdf"></i>',
                        titleAttr: 'Export to PDF'
                    }
                ];
                var clms = [
                    {
                        "mData": "Id",
                        "bSortable": false,
                        "mRender": function (data, type, gcb) {
                            var edBtns = '<span title="Edit Item" id="item_' + data + '" class="text-primary dt_btns item_edit bx bx-edit"></span>';
                            edBtns += '<span title="Delete Item" id="item_' + data + '" class="text-danger dt_btns item_delete bx bx-trash"></span>';
                            edBtns += '<span title="Clone Item" id="item_' + data + '" class="text-success dt_btns item_clone bx bx-copy"></span>';
                            return edBtns;
                        }
                    },
                    { "mData": "ItGRP" },
                    { "mData": "ItCode" },
                    { "mData": "ItDescription" },
                    { "mData": "ItRate" }
                ];

                if ($scope.dtItem === null) {
                    $scope.dtItem = $("table.dt-items").dataTable({
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: lengthMenu,
                        data: $scope.model.itemList,
                        buttons: btns,
                        columns: clms
                    });
                }
                else {
                    $scope.dtItem.fnClearTable();
                    $scope.dtItem.fnAddData($scope.model.itemList); // Add new data
                    $scope.dtItem.fnDraw(); // Redraw the DataTable
                }
            });
        };
        $scope.AddNewItem = function () {
            $scope.$evalAsync(function () {
                $scope.item = {};
                $scope.item.Id = 0;
            });
        };
        $scope.AddUpdateItemInfo = function (user) {
            if ($scope.frmItem.$valid) {
                $scope.item.DId = $scope.model.C.Id;
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateItemInformation(user);
                    });
                }
                else {
                    $scope.UpdateItemInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateItemInformation = function (user) {
            $scope.clinicHub.server.updateItemInformation(user, JSON.stringify($scope.item)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $('#mdlItem').modal('hide');
                        $scope.item = {};
                        toastr['success']('Item Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Item information!' + data, $scope.toastr_title);
                    }
                });
            });
        };
        $scope.DeleteItemInfo = function (user, item2delete) {
            var r = confirm("Are you sure to delete this item " + item2delete.Description + " (" + item2delete.Code + ")?");
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteItemInformation(user, item2delete);
                    });
                }
                else {
                    $scope.DeleteItemInformation(user, item2delete);
                }
            }
        };
        $scope.DeleteItemInformation = function (user, item2delete) {
            $scope.clinicHub.server.deleteItemInformation(user, JSON.stringify(item2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Item deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Item information!', $scope.toastr_title);
                    }
                });
            });
        };
        $scope.clinicHub.client.refreshItems = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.C.Id) {
                    index = _.findIndex($scope.model.itemList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.itemList[index] = data;
                    }
                    else {
                        $scope.model.itemList.push(data);
                    }
                    $scope.item = {};
                    $scope.RefreshItemDataTable();
                }
                toastr['success']('Item Refreshed Successfully for: ' + $scope.model.C.ClName + '!', $scope.toastr_title);
            });
        };
        $scope.clinicHub.client.refreshItemsAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.C.Id) {
                    index = _.findIndex($scope.model.itemList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.itemList.splice(index, 1);
                        toastr['success']('Item Refreshed Successfully for: ' + $scope.model.C.ClName + '!', $scope.toastr_title);
                        $scope.item = {};
                        $scope.RefreshItemDataTable();
                    }
                }

            });
        };
        //Render Item Groups


        //Render Symptoms
        $('table.dt-symptoms').on('click', 'span.symptom_edit', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.symList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.symptom = angular.copy($scope.model.symList[index]);
                        $scope.ValidateFormById('frmSymptom');
                    }
                }
            });
        });
        $('table.dt-symptoms').on('click', 'span.symptom_clone', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.symList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.symptom = angular.copy($scope.model.symList[index]);
                        $scope.symptom.Id = 0;
                        $scope.ValidateFormById('frmSymptom');
                    }
                }
            });
        });
        $('table.dt-symptoms').on('click', 'span.symptom_delete', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            $scope.$evalAsync(function () {
                if (id_parts.length > 1) {
                    var index = _.findIndex($scope.model.symList, { Id: parseInt(id_parts[1], 10) });
                    if (index >= 0) {
                        $scope.symptom = angular.copy($scope.model.symList[index]);
                        $scope.DeleteSymptomInfo($scope.model.U.U, $scope.symptom);
                    }
                }
            });
        });
        $scope.dtSymptom = null;
        $scope.RefreshSymptomDataTable = function () {
            $scope.$evalAsync(function () {

                var lengthMenu = [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ];
                var btns = [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="text-success bx bxs-spreadsheet"></i>',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="text-danger bx bxs-file-pdf"></i>',
                        titleAttr: 'Export to PDF'
                    }
                ];
                var clms = [
                    {
                        "mData": "Id",
                        "bSortable": false,
                        "mRender": function (data, type, gcb) {
                            var edBtns = '<span title="Edit Symptom" id="symptom_' + data + '" class="text-primary dt_btns symptom_edit bx bx-edit"></span>';
                            edBtns += '<span title="Delete Symptom" id="symptom_' + data + '" class="text-danger dt_btns symptom_delete bx bx-trash"></span>';
                            edBtns += '<span title="Clone Symptom" id="symptom_' + data + '" class="text-success dt_btns symptom_clone bx bx-copy"></span>';
                            return edBtns;
                        }
                    },
                    { "mData": "Name" },
                ];

                if ($scope.dtSymptom === null) {
                    $scope.dtSymptom = $("table.dt-symptoms").dataTable({
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: lengthMenu,
                        data: $scope.model.symList,
                        buttons: btns,
                        columns: clms
                    });
                }
                else {
                    $scope.dtSymptom.fnClearTable();
                    $scope.dtSymptom.fnAddData($scope.model.symList); // Add new data
                    $scope.dtSymptom.fnDraw(); // Redraw the DataTable
                }
            });
        };
        $scope.AddNewSymptom = function () {
            $scope.$evalAsync(function () {
                $scope.symptom = {};
                $scope.symptom.Id = 0;
            });
        };
        $scope.AddUpdateSymptomInfo = function (user) {
            if ($scope.frmSymptom.$valid) {
                $scope.symptom.DId = $scope.model.C.Id;
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateSymptomInformation(user);
                    });
                }
                else {
                    $scope.UpdateSymptomInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateSymptomInformation = function (user) {
            $scope.clinicHub.server.updateSymptomInformation(user, JSON.stringify($scope.symptom)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $('#mdlSymptom').modal('hide');
                        $scope.symptom = {};
                        toastr['success']('Symptom Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Symptom information!' + data, $scope.toastr_title);
                    }
                });
            });
        };
        $scope.DeleteSymptomInfo = function (user, symptom2delete) {
            var r = confirm("Are you sure to delete this symptom " + symptom2delete.Description + " (" + symptom2delete.Code + ")?");
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteSymptomInformation(user, symptom2delete);
                    });
                }
                else {
                    $scope.DeleteSymptomInformation(user, symptom2delete);
                }
            }
        };
        $scope.DeleteSymptomInformation = function (user, symptom2delete) {
            $scope.clinicHub.server.deleteSymptomInformation(user, JSON.stringify(symptom2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Symptom deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Symptom information!', $scope.toastr_title);
                    }
                });
            });
        };
        $scope.clinicHub.client.refreshSymptoms = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.C.Id) {
                    index = _.findIndex($scope.model.symList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.symList[index] = data;
                    }
                    else {
                        $scope.model.symList.push(data);
                    }
                    $scope.symptom = {};
                    $scope.RefreshSymptomDataTable();
                }
                toastr['success']('Symptom Refreshed Successfully for: ' + $scope.model.C.ClName + '!', $scope.toastr_title);
            });
        };
        $scope.clinicHub.client.refreshSymptomsAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.C.Id) {
                    index = _.findIndex($scope.model.symList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.symList.splice(index, 1);
                        toastr['success']('Symptom Refreshed Successfully for: ' + $scope.model.C.ClName + '!', $scope.toastr_title);
                        $scope.symptom = {};
                        $scope.RefreshSymptomDataTable();
                    }
                }
            });
        };
        //Render Symptoms


        $scope.UpdateClinicInfo = function (user) {
            if ($scope.frmeLogSheet.$valid) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateClinicInformation(user);
                    });
                }
                else {
                    $scope.UpdateClinicInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateClinicInformation = function (user) {
            $scope.$evalAsync(function () {
                $scope.clinicHub.server.updateClinicInformation(user, JSON.stringify($scope.model.C)).done(function (data) {
                    $scope.$evalAsync(function () {
                        if (data !== "") {
                            $scope.$evalAsync(function () {
                                $scope.model.C = $.parseJSON(data);
                            });
                            $('#mdlUpdateClinicInfo').modal('hide');
                            toastr['success']('Clinic Information patient successfully', $scope.toastr_title);
                        }
                        else {
                            toastr['error']('Error in updating clinic information!', $scope.toastr_title);
                        }
                    });
                });
            });
        };

    }]);


    app.filter('ceil', function () {
        return function (input) {
            return Math.ceil(input);
        };
    });

    app.directive('enterAsTab', function () {
        return function (scope, element, attrs) {
            element.bind("keydown keypress", function (event) {
                if (event.which === 13) {
                    event.preventDefault();
                    var elementToFocus = element.parent().next().find('input, select, textarea, button')[0];
                    if (angular.isDefined(elementToFocus)) {
                        elementToFocus.focus();
                    }
                    else {
                        elementToFocus = element.parent().parent().next().find('input, select, textarea, button')[0];
                        if (angular.isDefined(elementToFocus)) {
                            elementToFocus.focus();
                        }
                    }
                }
            });
        };
    });

}());
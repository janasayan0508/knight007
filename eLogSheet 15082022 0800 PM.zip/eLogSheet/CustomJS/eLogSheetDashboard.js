﻿(function () {
    var app = angular.module('eLogSheetApp', []);
    app.controller('eLogSheetCtrl', ['$scope', '$http', '$filter', function ($scope, $http, $filter) {

        $scope.ConnectionStarted = false;

        //toaster options
        toastr.options = { 'closeButton': 'true', 'debug': false, 'newestOnTop': true, 'progressBar': true, 'positionClass': 'toast-bottom-left', 'preventDuplicates': true, 'onclick': null, 'showDuration': '5000', 'hideDuration': '1200', 'timeOut': '2000', 'extendedTimeOut': '1500', 'showEasing': 'swing', 'hideEasing': 'linear', 'showMethod': 'fadeIn', 'hideMethod': 'fadeOut' };
        $scope.toastr_title = 'ePractice Powered by CoDT, BSL!';

        $scope.dataEntryHub = $.connection.dataEntryHub; // initializes hub
        $scope.ConnectionStarted = false;

        $scope.SH = {};


        for (var hrs = 6; hrs <= 29; hrs++) {

            var shift = '';

            if (hrs >= 6 && hrs <= 13) {
                shift = 'A';
            }
            else if (hrs >= 14 && hrs <= 21) {
                shift = 'B';
            }
            else {
                shift = 'C';
            }
            var hr = hrs > 23 ? hrs % 24 : hrs;
            if ($scope.SH.hasOwnProperty(shift)) {
                $scope.SH[shift][hrs] = hr;
            }
            else {
                $scope.SH[shift] = {};
                $scope.SH[shift][hrs] = hr;
            }
        }


        $scope.data = {};
        $scope.model = {};
        $scope.dshift = '';
        $scope.pTotal = {};
        $scope.SelectedDate = '';




        angular.element(document).ready(function () {

            $scope.$evalAsync(function () {

                $scope.base_url = $(location).attr('host');


                $('.datepicker').daterangepicker({
                    singleDatePicker: true,
                    showDropdowns: true,
                    drops: "auto",
                    maxDate: new Date(),
                    autoUpdateInput: false,
                    autoApply: false,
                    locale: {
                        format: 'DD/MM/YYYY',
                        cancelLabel: 'Clear'
                    }
                });
                $('.datepicker').on('show.daterangepicker', () => {
                    $('.daterangepicker').removeClass('auto-apply');
                });

                $('.datepicker').on('apply.daterangepicker', function (ev, picker) {
                    $scope.$evalAsync(function () {
                        $scope.model.DT = moment(picker.startDate.format('DD/MM/YYYY'), 'DD/MM/YYYY');
                        $scope.SelectedDate = picker.startDate.format('DD/MM/YYYY');
                        var dt = picker.startDate.format('YYYYMMDD');
                        toastr['info'](dt, $scope.toastr_title);
                        $scope.GetDashboardDataForDay($scope.model.U.UserName, dt);
                    });
                });

                $scope.model = $.parseJSON($('p#modelData').text());
                $('p#modelData').text('');

                $.connection.hub.start().done(function () {
                    $scope.$evalAsync(function () {
                        $scope.ConnectionStarted = true;
                        toastr['info']('Hub Started!', $scope.toastr_title);

                        var hrs = new Date().getHours();

                        if (hrs >= 6 && hrs <= 13) {
                            shift = 'A';
                        }
                        else if (hrs >= 14 && hrs <= 21) {
                            shift = 'B';
                        }
                        else {
                            shift = 'C';
                        }

                        $scope.dshift = shift;
                        $scope.SelectedDate = $filter('date')($scope.model.DT, 'dd/MM/yyyy');
                        $scope.GenerateDataForm();
                    });
                }); // starts hub


                //
                //Datetime Picker
                //

                $('.datetimepicker').daterangepicker({
                    singleDatePicker: true,
                    showDropdowns: true,
                    autoUpdateInput: false,
                    autoApply: false,
                    timePicker: true,
                    timePickerIncrement: 5,
                    minDate: new Date(),
                    timePicker24Hour: true,
                    showDropdowns: true,
                    locale: {
                        format: 'YYYY-MM-DD HH:MM:SS',
                        cancelLabel: 'Clear'
                    }
                });


                $('.datetimepicker').on('show.daterangepicker', () => {
                    $('.daterangepicker').removeClass('auto-apply');
                });


                $('.datetimepicker').on('cancel.daterangepicker', function (ev, picker) {
                    var nm = $(this).attr('name');
                    var frmObjcet = $(this).attr('frm-entity');
                    $scope.$evalAsync(function () {
                        $scope[frmObjcet][nm] = null;
                    });
                });

                $('.datetimepicker').on('apply.daterangepicker', function (ev, picker) {
                    var nm = $(this).attr('name');
                    var frmObjcet = $(this).attr('frm-entity');
                    $scope.$evalAsync(function () {
                        $scope[frmObjcet][nm] = picker.startDate.format('YYYY-MM-DD H:mm:ss');
                    });
                });


                //
                //Datetime Picker
                //

            });
        });

        $('form.bv-form').each(function () {
            var frmId = $(this).attr('id');
            $('#' + frmId + ' .input-field').on("blur, change", function () {
                var nm = $(this).attr('name');
                $('#' + frmId + '').bootstrapValidator('revalidateField', nm);
            });
        });

        $scope.ValidateFormById = function (frmId) {
            $scope.$evalAsync(function () {
                $('#' + frmId + ' .input-field:visible').each(function () {
                    var nm = $(this).attr('name');
                    $('#' + frmId + '').bootstrapValidator('revalidateField', nm);
                });
            });
        };


        $('form.bv-form').on('blur', 'input.input-field', function () {
            var frm = $(this).attr('frm-name');
            var nm = $(this).attr('name');
            $scope.$evalAsync(function () {
                //var bv = $('#' + frm + '').bootstrapValidator();
                $('#' + frm + '').bootstrapValidator('revalidateField', nm);
                toastr['info'](frm + ' Input ' + nm + ' Changed!', $scope.toastr_title);
            });
        });


        $scope.dfwpList = {};
        $scope.data = {};
        $scope.ann = {};

        $scope.GenerateDataForm = function () {
            $scope.$evalAsync(function () {

                $scope.dfwpList = {};
                toastr['info']('Processing Data fro Date!', $scope.toastr_title);
                $scope.model.dataList = $scope.model.dataList.sort(function (a, b) {
                    return a.FPV - b.FPV;
                });

                for (var j in $scope.model.dataList) {

                    var st = $scope.model.dataList[j].PF;
                    var did = $scope.model.dataList[j].DId;
                    var sft = $scope.model.dataList[j].PFT;
                    var pid = $scope.model.dataList[j].PId;
                    var pname = $scope.model.pList[pid].Name;
                    

                    var isInpuparam4Form = false;
                    var sv = null;
                    switch (sft) {
                        case "int":
                            sv = parseInt($scope.model.dataList[j].PFV, 10);
                            break;
                        case "string":
                            sv = $scope.model.dataList[j].PFV
                            break;
                        default:
                            break;
                    }

                    var uid = st + '_' + sv + '_' + $scope.model.dataList[j].PId;
                    var stpid = st + '_' + $scope.model.dataList[j].PId;
                    var val = 0;

                    var dfname = $scope.model.dataList[j].PDT + 'Value';

                    $scope.model.dataList[j].uid = uid;
                    $scope.model.dataList[j].stpid = stpid;
                    $scope.model.dataList[j].dfname = dfname;

                    var val = $scope.model.dataList[j][dfname];

                    switch (st) {
                        case "Shift":
                            isInpuparam4Form = ($scope.dshift === sv);

                            break;
                        case "Hour":
                            isInpuparam4Form = $scope.SH.hasOwnProperty($scope.dshift) && $scope.SH[$scope.dshift].hasOwnProperty(sv);
                            break;
                        case "Day":
                            break;
                        default:
                            break;
                    }

                    if ($scope.dfwpList.hasOwnProperty(did)) {
                        if ($scope.dfwpList[did].hasOwnProperty(st)) {
                            if ($scope.dfwpList[did][st].pList.hasOwnProperty(pid)) {
                                if (isInpuparam4Form) {
                                    $scope.dfwpList[did][st].pList[pid].ifList[sv] = val;
                                }
                                else {
                                    $scope.dfwpList[did][st].pList[pid].ofList[sv] = val;
                                }
                            }
                            else {
                                $scope.dfwpList[did][st].pList[pid] = {};
                                $scope.dfwpList[did][st].pList[pid].ifList = {};
                                $scope.dfwpList[did][st].pList[pid].ofList = {};
                                if (isInpuparam4Form) {
                                    $scope.dfwpList[did][st].pList[pid].ifList[sv] = val;
                                }
                                else {
                                    $scope.dfwpList[did][st].pList[pid].ofList[sv] = val;
                                }
                            }
                        }
                        else {
                            $scope.dfwpList[did][st] = {};
                            $scope.dfwpList[did][st].pList = {};
                            $scope.dfwpList[did][st].pList[pid] = {};
                            $scope.dfwpList[did][st].pList[pid].ifList = {};
                            $scope.dfwpList[did][st].pList[pid].ofList = {};
                            if (isInpuparam4Form) {
                                $scope.dfwpList[did][st].pList[pid].ifList[sv] = val;
                            }
                            else {
                                $scope.dfwpList[did][st].pList[pid].ofList[sv] = val;
                            }
                        }
                    }
                    else {
                        $scope.dfwpList[did] = {};
                        $scope.dfwpList[did][st] = {};
                        $scope.dfwpList[did][st].pList = {};
                        $scope.dfwpList[did][st].pList[pid] = {};
                        $scope.dfwpList[did][st].pList[pid].ifList = {};
                        $scope.dfwpList[did][st].pList[pid].ofList = {};
                        if (isInpuparam4Form) {
                            $scope.dfwpList[did][st].pList[pid].ifList[sv] = val;
                        }
                        else {
                            $scope.dfwpList[did][st].pList[pid].ofList[sv] = val;
                        }
                    }
                }
            });
        };



        $scope.dwswpl = {};

        $scope.GetDashboardDataForDay = function (user, dt) {

            $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
            if (!$scope.ConnectionStarted) {
                $.connection.hub.start().done(function () {
                    $scope.ConnectionStarted = true;
                    $scope.GetDashboardReportDataForDay(user, dt);
                });
            }
            else {
                $scope.GetDashboardReportDataForDay(user, dt);
            }
        };


        $scope.GetDashboardReportDataForDay = function (user, dt) {


            $scope.dataEntryHub.server.getDashboardDataForTheDay(user, dt).done(function (response) {
                $scope.$evalAsync(function () {
                    if (response !== "") {
                        var data = $.parseJSON(response);
                        $scope.model = angular.copy(data);
                        $scope.GenerateDataForm();
                        toastr['success']('Data Refreshed for ' + data.DT + '!', $scope.toastr_title);
                        toastr['success']('Data Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating data!', $scope.toastr_title);
                    }
                });
            });
        };


        $scope.dataEntryHub.client.refreshDashboardViewModel = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if ($filter('date')(data.DT, 'yyyyMMdd') == $filter('date')($scope.model.DT, 'yyyyMMdd')) {
                    $scope.model = angular.copy(data);
                    $scope.GenerateDataForm();
                    toastr['success']('Data Refreshed for ' + data.DT + '!', $scope.toastr_title);
                }
            });
        };


        //
        //Announcements
        //

        $('table#ann_list').on('click', 'span.dt_btns', function () {
            var id = $(this).attr('id');
            var id_parts = id.split("_");
            switch (id_parts[0]) {
                case "edt":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.annList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {

                                $scope.ann = angular.copy($scope.model.annList[index]);
                                $scope.ValidateFormById('frmAnnouncement');
                                toastr['info']('You are editing ' + $scope.ann.MsgTitle, $scope.toastr_title);
                                $('div#mdlAnnouncements').modal('show');
                            }
                        }
                    });
                    break;
                case "del":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.annList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {
                                $scope.ann = angular.copy($scope.model.annList[index]);
                                $scope.DeleteAnnouncementInfo($scope.model.U.UserName, $scope.ann);
                                toastr['danger']('You are deleting ' + $scope.ann.MsgTitle, $scope.toastr_title);
                            }
                        }
                    });
                    break;
                case "cln":
                    $scope.$evalAsync(function () {
                        if (id_parts.length > 1) {
                            var index = _.findIndex($scope.model.annList, { Id: parseInt(id_parts[1], 10) });
                            if (index >= 0) {

                                $scope.ann = angular.copy($scope.model.annList[index]);
                                $scope.ann.Id = 0;
                                $scope.ValidateFormById('frmAnnouncement');
                                toastr['success']('You are creating copy of ' + $scope.ann.MsgTitle, $scope.toastr_title);
                                $('div#mdlAnnouncements').modal('show');
                            }
                        }
                    });
                    break;
                default:
                    break;
            }

        });


        $scope.dtAnnouncement = null;
        $scope.RefreshAnnouncementsTable = function () {
            $scope.$evalAsync(function () {

                var lengthMenu = [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ];
                var btns = [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="text-success bx bxs-spreadsheet"></i>',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="text-danger bx bxs-file-pdf"></i>',
                        titleAttr: 'Export to PDF'
                    }
                ];
                //<th></th>
                //<th>Title</th>
                //<th>StartDate</th>
                //<th>EndDate</th>
                //<th>Title</th>
                //<th>Desc</th>
                //<th>Url</th>
                //<th>VisibleTo</th>
                //<th>LastUpdated</th>
                var clms = [

                    {
                        "mData": "Id",
                        "bSortable": false,
                        "mRender": function (data, type, gcb) {
                            var edBtns = '<span title="Edit Announcement" id="edt_' + data + '" class="text-primary dt_btns bx bx-edit"></span>';
                            edBtns += '<span title="Delete Announcement" id="del_' + data + '" class="text-danger dt_btns bx bx-trash"></span>';
                            edBtns += '<span title="Clone Announcement" id="cln_' + data + '" class="text-success dt_btns bx bx-copy"></span>';
                            return edBtns;
                        }
                    },
                    { "mData": "MsgTitle" },
                    {
                        "mData": "MsgDtStart",
                        "bSortable": true,
                        "mRender": function (data, type, row) {

                            return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                        }
                    },
                    {
                        "mData": "MsgDtEnd",
                        "bSortable": true,
                        "mRender": function (data, type, row) {

                            return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                        }
                    },
                    { "mData": "MsgTitle" },
                    { "mData": "MsgDesc" },
                    { "mData": "MsgUrl" },
                    { "mData": "VisibleTo" },
                    {
                        "mData": "UpdatedOn",
                        "bSortable": true,
                        "mRender": function (data, type, row) {

                            return (data === null) ? '' : $filter('date')(data, 'yyyy-MM-dd hh:mm:ss a');
                        }
                    }
                ];

                if ($scope.dtAnnouncement === null) {
                    $scope.dtAnnouncement = $("table#ann_list").dataTable({
                        dom: 'lBfrtip',
                        // Configure the drop down options.
                        lengthMenu: lengthMenu,
                        data: $scope.model.annList,
                        buttons: btns,
                        columns: clms
                    });
                }
                else {
                    $scope.dtAnnouncement.fnClearTable();
                    $scope.dtAnnouncement.fnAddData($scope.model.annList); // Add new data
                    $scope.dtAnnouncement.fnDraw(); // Redraw the DataTable
                }
            });
        };

        $scope.ManageAnnouncements = function () {
            $scope.$evalAsync(function () {
                $scope.ann = {};
                $scope.ann.Id = null;
                $scope.RefreshAnnouncementsTable();
            });
        };

        $scope.AddNewAnnouncement = function () {
            $scope.$evalAsync(function () {
                $scope.ann = {};
                $scope.ann.Id = 0;
                $scope.ann.PF = 2;
                $scope.ann.PFT = 'string';
                $scope.ann.PFV = $scope.dshift;
                $scope.ann.DId = $scope.model.DId;
                $scope.ann.FY = $scope.model.FY;
                $scope.ann.DT = $filter('date')($scope.model.DT, 'yyyy-MM-dd');
                $scope.ann.Q = $scope.model.Q;
            });
        };
        $scope.AddUpdateAnnouncementInfo = function (user) {
            if ($scope.frmAnnouncement.$valid) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.UpdateAnnouncementInformation(user);
                    });
                }
                else {
                    $scope.UpdateAnnouncementInformation(user);
                }
            }
            else {
                toastr['error']('Correct Entries and try again!', $scope.toastr_title);
            }
        };
        $scope.UpdateAnnouncementInformation = function (user) {
            $scope.dataEntryHub.server.updateAnnouncementInformation(user, JSON.stringify($scope.ann)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        $('#mdlAnnouncements').modal('hide');
                        $scope.ann = {};
                        toastr['success']('Announcement Updated successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in updating Announcement information!' + data, $scope.toastr_title);
                    }
                });
            });
        };
        $scope.DeleteAnnouncementInfo = function (user, item2delete) {
            var r = confirm("Are you sure to delete this Announcement " + item2delete.Reason);
            if (r) {
                $scope.ConnectionStarted = !($.connection.hub.state === $.signalR.connectionState.disconnected);
                if (!$scope.ConnectionStarted) {
                    $.connection.hub.start().done(function () {
                        $scope.ConnectionStarted = true;
                        $scope.DeleteAnnouncementInformation(user, item2delete);
                    });
                }
                else {
                    $scope.DeleteAnnouncementInformation(user, item2delete);
                }
            }
        };
        $scope.DeleteAnnouncementInformation = function (user, item2delete) {
            $scope.dataEntryHub.server.deleteAnnouncementInformation(user, JSON.stringify(item2delete)).done(function (data) {
                $scope.$evalAsync(function () {
                    if (data === "") {
                        toastr['success']('Announcement deleted successfully', $scope.toastr_title);
                    }
                    else {
                        toastr['error']('Error in deleting Announcement information!', $scope.toastr_title);
                    }
                });
            });
        };
        $scope.dataEntryHub.client.refreshAnnouncements = function (responseData) {

            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.DId) {
                    index = _.findIndex($scope.model.annList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.annList[index] = data;
                    }
                    else {
                        $scope.model.annList.push(data);
                    }
                    $scope.ann = {};
                    $scope.RefreshAnnouncementsTable();
                    toastr['success']('Announcement Refreshed Successfully!', $scope.toastr_title);
                }

            });
        };
        $scope.dataEntryHub.client.refreshAnnouncementsAfterDeletion = function (responseData) {
            $scope.$evalAsync(function () {
                var data = $.parseJSON(responseData);
                if (data.DId === $scope.model.DId) {
                    index = _.findIndex($scope.model.annList, { Id: data.Id });
                    if (index >= 0) {
                        $scope.model.annList.splice(index, 1);
                        toastr['success']('Announcement Refreshed Successfully!', $scope.toastr_title);
                        $scope.ann = {};
                        $scope.RefreshAnnouncementsTable();
                    }
                }

            });
        };

        //
        //Announcements
        //

    }]);


    app.filter('ceil', function () {
        return function (input) {
            return Math.ceil(input);
        };
    });

    app.directive('enterAsTab', function () {
        return function (scope, element, attrs) {
            element.bind("keydown keypress", function (event) {
                if (event.which === 13) {
                    event.preventDefault();
                    var elementToFocus = element.parent().next().find('input, select, textarea, button')[0];
                    if (angular.isDefined(elementToFocus)) {
                        elementToFocus.focus();
                    }
                    else {
                        elementToFocus = element.parent().parent().next().find('input, select, textarea, button')[0];
                        if (angular.isDefined(elementToFocus)) {
                            elementToFocus.focus();
                        }
                    }
                }
            });
        };
    });

}());
﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using eLogSheet;
using eLogSheet.Models;
using eLogSheet.Utilities;
using Microsoft.AspNet.SignalR;
using Newtonsoft.Json;

namespace eLogSheet
{
    public class ClinicHub : Hub
    {
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");

        #region Settings

        public string UpdateSetting4Param(string user, string CId, string name, string data)
        {
            string responseText = string.Empty;
            try
            {
                List<string> list = JsonConvert.DeserializeObject<List<string>>(data);
                Setting item = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (!string.IsNullOrEmpty(CId))
                    {
                        item = db.Settings
                            .Where(s => s.CId.Equals(CId) &&
                            (string.IsNullOrEmpty(s.UId) || s.UId.Equals(user))
                            && name.Equals(s.NM)).FirstOrDefault();
                            
                        if (item != null)
                        {
                            item.JsonStr = JsonConvert.SerializeObject(list);
                            db.Entry(item).State = EntityState.Modified;
                        }
                        else
                        {
                            item = new Setting();
                            item.NM = name;
                            item.UId = user;
                            item.CId = CId;
                            item.JsonStr = JsonConvert.SerializeObject(list);
                            db.Settings.Add(item);
                        }
                        db.SaveChanges();
                    }
                   responseText = JsonConvert.SerializeObject(item);
                }
            }
            catch (Exception e)
            {
                responseText = string.Empty;
            }
            return responseText;
        }

        #endregion

        #region Doctor

        public string UpdateEPPList(string user, string CId, int VId, string data)
        {
            string responseText = string.Empty;
            try
            {
                DMV dmv = JsonConvert.DeserializeObject<DMV>(data);
                Visit item = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (!string.IsNullOrEmpty(CId))
                    {
                        item = db.Visits.Find(VId);
                        if (item != null)
                        {
                            item.Diagnosis = JsonConvert.SerializeObject(dmv);
                            item.UpdatedBy = user;
                            item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                            db.Entry(item).State = EntityState.Modified;
                            db.SaveChanges();
                            CurrentVisit wInvoice = new CurrentVisit();
                            wInvoice.cv = db.sp_GetVisitDetailsById(item.Id, item.CId).FirstOrDefault();
                            try
                            {
                                if (string.IsNullOrEmpty(wInvoice.cv.Diagnosis))
                                {
                                    wInvoice.dmv = new DMV { Id = item.Id };
                                }
                                else
                                {
                                    wInvoice.dmv = JsonConvert.DeserializeObject<DMV>(wInvoice.cv.Diagnosis);
                                }
                            }
                            catch (Exception)
                            {

                            }
                            Clients.All.RefreshEPPInVisit(JsonConvert.SerializeObject(wInvoice));
                        }
                    }
                }
            }
            catch (Exception e)
            {
            }
            return responseText;
        }

        public string UpdateInvestigations(string user, string CId, int VId, string data)
        {
            string responseText = string.Empty;
            try
            {
                Dictionary<string, Dictionary<string, Dictionary<string, int>>> imv = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, Dictionary<string, int>>>>(data);
                Visit item = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (!string.IsNullOrEmpty(CId))
                    {
                        item = db.Visits.Find(VId);
                        if (item != null)
                        {
                            item.Investigation = JsonConvert.SerializeObject(imv);
                            item.UpdatedBy = user;
                            item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                            db.Entry(item).State = EntityState.Modified;
                            db.SaveChanges();
                            CurrentVisit wInvoice = new CurrentVisit();
                            wInvoice.cv = db.sp_GetVisitDetailsById(item.Id, item.CId).FirstOrDefault();
                            try
                            {
                                if (string.IsNullOrEmpty(wInvoice.cv.Investigation))
                                {
                                    wInvoice.imv = new Dictionary<string, Dictionary<string, Dictionary<string, int>>>();
                                }
                                else
                                {
                                    wInvoice.imv = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, Dictionary<string, int>>>> (wInvoice.cv.Investigation);
                                }
                            }
                            catch (Exception)
                            {

                            }
                            Clients.All.RefreshInvestigations(JsonConvert.SerializeObject(wInvoice));
                        }
                    }
                }
            }
            catch (Exception e)
            {
            }
            return responseText;
        }

        public string SettleCurrentVisitInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Visit visit = JsonConvert.DeserializeObject<Visit>(data);
                Visit v2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (visit.Id > 0)
                    {
                        v2update = db.Visits.Find(visit.Id);
                        v2update.SettledBy = user;
                        v2update.SettledOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(v2update).State = EntityState.Modified;
                        db.SaveChanges();
                        db.sp_SettleVisitInformation(v2update.PId, v2update.CId, v2update.BillId, user);
                        db.SaveChanges();
                    }
                }
                using (HMSEntities db = new HMSEntities())
                {
                    Clients.All.RefreshVisitAfterSettlement(JsonConvert.SerializeObject(db.sp_GetVisitDetailsById(v2update.Id, v2update.CId).FirstOrDefault()));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UnSettleCurrentVisitInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Visit visit = JsonConvert.DeserializeObject<Visit>(data);
                Visit v2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (visit.Id > 0)
                    {
                        v2update = db.Visits.Find(visit.Id);
                        v2update.SettledBy = null;
                        v2update.SettledOn = null;
                        db.Entry(v2update).State = EntityState.Modified;
                        db.SaveChanges();
                        db.sp_UnSettleVisitInformation(v2update.PId, v2update.CId, v2update.BillId, user);
                        db.SaveChanges();
                    }
                }
                using (HMSEntities db = new HMSEntities())
                {
                    Clients.Caller.RefreshVisitAfterSettlement(JsonConvert.SerializeObject(db.sp_GetVisitDetailsById(v2update.Id, v2update.CId).FirstOrDefault()));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string GenerateDentalPrescription(string cid, int? pid, int vid)
        {
            string response = string.Empty;
            CurrentVisit CurrentVisit = new CurrentVisit();
            try
            {
                CurrentVisit = new CurrentVisit(cid, pid, vid, false);
                response = PdfOperations.GenerateDentalPrescription(CurrentVisit);
            }
            catch (Exception e)
            {
                response = string.Empty;
            }
            
            
            return response;
        }

        public string GeneratePrescription(string cid, int? pid, int vid)
        {
            string response = string.Empty;
            CurrentVisit CurrentVisit = new CurrentVisit();
            try
            {
                CurrentVisit = new CurrentVisit(cid, pid, vid, false);
                response = PdfOperations.GeneratePrescription(CurrentVisit);
            }
            catch (Exception e)
            {
                response = string.Empty;
            }
            return response;
        }
        public string GetPatientListForSearchText(string SearchTxt, string cid)
        {
            string response = string.Empty;
            List<sp_GetPatientListForMatchingCriteria_Result> pList = new List<sp_GetPatientListForMatchingCriteria_Result>();
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    pList = db.sp_GetPatientListForMatchingCriteria(SearchTxt, cid).ToList();
                    response = JsonConvert.SerializeObject(pList);
                    
                }
            }
            catch (Exception e)
            {
                response = string.Empty;
            }
            return response;
        }
        public string GetAppointmentsForDateRange(string CId, string start, string end, string type)
        {
            string response = string.Empty;
            List<sp_GetAppointmentListForDateRange_Result> pList = new List<sp_GetAppointmentListForDateRange_Result>();
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    pList = db.sp_GetAppointmentListForDateRange(start, end, CId, type).ToList();
                    response = JsonConvert.SerializeObject(pList);
                    Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(CId, start)));
                }
            }
            catch (Exception e)
            {
                response = string.Empty;
            }
            return response;
        }
        public string UpdatePatientInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Patient patient = JsonConvert.DeserializeObject<Patient>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    if (patient.Id>0)
                    {
                        Patient patient2update = db.Patients.Find(patient.Id);
                        patient2update.PtName = patient.PtName;
                        patient2update.PtAge = patient.PtAge;
                        if ((patient.PtAge ?? 0) > 0)
                        {
                            patient.PtDOB = patient.CreatedOn.Value.AddYears(-1 * (int)(patient.PtAge ?? 0));
                        }
                        patient2update.PtGender = patient.PtGender;
                        patient2update.PtSpouseName = patient.PtSpouseName;
                        patient2update.PtFinStatus = patient.PtFinStatus;
                        patient2update.PtEmergencyContact = patient.PtEmergencyContact;
                        patient2update.PtEmergencyName = patient.PtEmergencyName;
                        patient2update.PtAddress = patient.PtAddress;
                        patient2update.PtCity = patient.PtCity;
                        patient2update.PtTitle = patient.PtTitle;
                        patient2update.PtIdType = patient.PtIdType;
                        patient2update.PtIdCardNo = patient.PtIdCardNo;
                        patient2update.PtMobileNo = patient.PtMobileNo;
                        patient2update.PtAlternateMobileNo = patient.PtAlternateMobileNo;
                        patient2update.PtOccupation = patient.PtOccupation;
                        patient2update.PtFinStatus = patient.PtFinStatus;
                        patient2update.PtEducation = patient.PtEducation;
                        patient2update.PtEmailId = patient.PtEmailId;
                        patient2update.PtMaritalStatus = patient.PtMaritalStatus;
                        patient2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(patient2update).State = EntityState.Modified;
                    }
                    db.SaveChanges();
                    responseText = JsonConvert.SerializeObject(db.Patients.Find(patient.Id));
                }
            }
            catch (Exception e)
            {
                responseText = "";
            }
            return responseText;
        }

        public string UpdateEventInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Visit item = JsonConvert.DeserializeObject<Visit>(data);
                Visit item2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (item.Id > 0)
                    {
                        item2update = db.Visits.Find(item.Id);
                        item2update.ADATE = item.ApptDate;
                        item2update.ApptDate = item.ApptDate;
                        item2update.ApptEndDate = item.ApptEndDate;
                        if(!String.IsNullOrEmpty(item.ApptPurpose))
                        {
                            item2update.ApptPurpose = item.ApptPurpose;
                        }
                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    db.SaveChanges();
                    Clients.All.RefreshAppointments(JsonConvert.SerializeObject(db.sp_GetAppointmentListForId(item.Id, item.CId).FirstOrDefault()));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteEventInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Visit item = JsonConvert.DeserializeObject<Visit>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    if (item.Id > 0)
                    {
                        sp_GetAppointmentListForId_Result dItem = db.sp_GetAppointmentListForId(item.Id, item.CId).FirstOrDefault();
                        db.Visits.Remove(db.Visits.Find(item.Id));
                        db.SaveChanges();
                        Clients.All.RefreshAppointmentsAfterDeletion(JsonConvert.SerializeObject(dItem));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UpdateAppointmentInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Visit item = JsonConvert.DeserializeObject<Visit>(data);
                Visit item2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (item.Id > 0)
                    {
                        item2update = db.Visits.Find(item.Id);
                        item2update.Department = item.Department;
                        item2update.Doctor = item.Doctor;
                        item2update.ApptType = item.ApptType;
                        item2update.BP = item.BP;
                        item2update.ADATE = item.ApptDate;
                        item2update.ApptDate = item.ApptDate;
                        item2update.Weight = item.Weight;
                        item2update.Height = item.Height;
                        item2update.ApptPurpose = item.ApptPurpose;
                        item2update.ApptRemarks = item.ApptRemarks;
                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        item.ApptCreatedBy = user;
                        item.ApptCreatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Visits.Add(item);
                    }
                    db.SaveChanges();
                    db.sp_PatientAppointmentAdded(item.Id, item.CId);
                    Clients.All.RefreshAppointments(JsonConvert.SerializeObject(db.sp_GetAppointmentListForId(item.Id, item.CId).FirstOrDefault()));
                }
                string txtDate = string.Format("{0:yyyy-MM-dd}", item.RDATE);
                Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(item.CId, txtDate)));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteAppointmentInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Visit item = JsonConvert.DeserializeObject<Visit>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    if (item.Id > 0)
                    {
                        sp_GetAppointmentListForId_Result dItem = db.sp_GetAppointmentListForId(item.Id, item.CId).FirstOrDefault();
                        db.Visits.Remove(db.Visits.Find(item.Id));
                        db.SaveChanges();
                        Clients.All.RefreshAppointmentsAfterDeletion(JsonConvert.SerializeObject(dItem));
                        string txtDate = string.Format("{0:yyyy-MM-dd}", item.RDATE);
                        Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(item.CId, txtDate)));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        
        
        public string RegisterPatientAndBookAppt(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Patient patient = JsonConvert.DeserializeObject<Patient>(data);
                Visit item = JsonConvert.DeserializeObject<Visit>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    patient.CreatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                    patient.CreatedBy = user;
                    patient.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                    patient.UpdatedBy = user;
                    if ((patient.PtAge ?? 0) > 0)
                    {
                        patient.PtDOB = patient.CreatedOn.Value.AddYears(-1 * (int)(patient.PtAge ?? 0));
                    }
                    db.Patients.Add(patient);                 
                    db.SaveChanges();
                    if (patient.Id>0)
                    {
                        item.PId = patient.Id;
                        item.CId = patient.CId;
                        item.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Visits.Add(item);
                    }
                    db.SaveChanges();
                    db.sp_PatientAppointmentAdded(item.Id, item.CId);
                    Clients.All.RefreshAppointments(JsonConvert.SerializeObject(db.sp_GetAppointmentListForId(item.Id, item.CId).FirstOrDefault()));
                    string txtDate = string.Format("{0:yyyy-MM-dd}", item.ADATE);
                    Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(item.CId, txtDate)));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UpdateBasicVisitInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Visit visit = JsonConvert.DeserializeObject<Visit>(data);
                Visit v2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (visit.Id > 0)
                    {
                        v2update = db.Visits.Find(visit.Id);
                        v2update.Disc = visit.Disc;
                        v2update.DiscPercent = visit.DiscPercent;
                        //v2update.OH = visit.OH;

                        v2update.UpdatedBy = user;
                        v2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(v2update).State = EntityState.Modified;
                        db.SaveChanges();
                        db.sp_UpdatePaymentInPatientInvoice(v2update.PId, v2update.CId, v2update.BillId, visit.Id, v2update.FY);
                        db.SaveChanges();
                    }
                }
                using (HMSEntities db = new HMSEntities())
                {
                    CurrentVisit wInvoice = new CurrentVisit();
                    wInvoice.vpList = db.VisitPayments.Where(wo => wo.PId == v2update.PId && wo.BillId == v2update.BillId && wo.VId == v2update.Id).ToList();
                    wInvoice.cv = db.sp_GetVisitDetailsById(v2update.Id, v2update.CId).FirstOrDefault();
                    Clients.All.RefreshPayments(JsonConvert.SerializeObject(wInvoice));
                    string txtDate = string.Format("{0:yyyy-MM-dd}", visit.RDATE);
                    Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(visit.CId, txtDate)));
                    DateTime dt = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UpdateVisitPrescriptionInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Visit visit = JsonConvert.DeserializeObject<Visit>(data);
                Visit v2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (visit.Id > 0)
                    {
                        v2update = db.Visits.Find(visit.Id);

                        v2update.DocRemarks = visit.DocRemarks;
                        v2update.Weight = visit.Weight;
                        v2update.Height = visit.Height;
                        v2update.BP = visit.BP;
                        v2update.PR = visit.PR;
                        v2update.SpclRemarks = visit.SpclRemarks;
                        v2update.Examination = visit.Examination;
                        v2update.Investigation = visit.Investigation;

                        v2update.LMP = visit.LMP;
                        v2update.GA = visit.GA;
                        v2update.EDD = visit.EDD;
                        v2update.PMC = visit.PMC;
                        v2update.LMP = visit.LMP;
                        v2update.EDD_BY_USG = visit.EDD_BY_USG;
                        v2update.OHG = visit.OHG;
                        v2update.OHP = visit.OHP;
                        v2update.OHA = visit.OHA;
                        v2update.OH = visit.OH;
                        v2update.CO = visit.CO;
                        v2update.pOH = visit.pOH;
                        v2update.pCO = visit.pCO;
                        v2update.pDiagnosis = visit.pDiagnosis;
                        v2update.pPrescription = visit.pPrescription;
                        v2update.pExamination = visit.pExamination;
                        v2update.pInvestigation = visit.pInvestigation;
                        v2update.pDocRemarks = visit.pDocRemarks;
                        v2update.pInvestigation2 = visit.pInvestigation2;
                        v2update.Investigation2 = visit.Investigation2;
                        v2update.UpdatedBy = user;

                        v2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(v2update).State = EntityState.Modified;
                        db.SaveChanges();
                        db.sp_ExecutePostBAsicInforUpdatedForVisit(v2update.PId, v2update.CId, v2update.BillId);
                    }
                }
                using (HMSEntities db = new HMSEntities())
                {
                    Clients.All.RefreshVisitsByDoctor(JsonConvert.SerializeObject(db.sp_GetVisitDetailsById(v2update.Id, v2update.CId).FirstOrDefault()));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UpdateClinicInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Clinic item = JsonConvert.DeserializeObject<Clinic>(data);
                Clinic item2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (!string.IsNullOrEmpty(item.Id))
                    {
                        item2update = db.Clinics.Find(item.Id);

                        item2update.ClName = item.ClName;
                        item2update.ClTagline = item.ClTagline;
                        item2update.ClAddress = item.ClAddress;
                        item2update.ClContact = item.ClContact;
                        item2update.ClEmail = item.ClEmail;
                        item2update.ClGST = item.ClGST;
                        item2update.ClCGST = item.ClCGST;
                        item2update.ClSGST = item.ClSGST;
                        item2update.ClIGST = item.ClIGST;
                        item2update.ClCIN = item.ClCIN;
                        item2update.ClGSTIN = item.ClGSTIN;
                        item2update.ApptFeeExp = item.ApptFeeExp;


                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                        db.SaveChanges();
                        responseText = JsonConvert.SerializeObject(item2update);
                    }
                }
                
            }
            catch (Exception e)
            {
            }
            return responseText;
        }

        public string UpdateClinicSettingsInformation(string user, string CId, string data)
        {
            string responseText = string.Empty;
            try
            {
                ClinicSettings settings = JsonConvert.DeserializeObject<ClinicSettings>(data);
                Clinic item2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (!string.IsNullOrEmpty(CId))
                    {
                        item2update = db.Clinics.Find(CId);
                        item2update.ClSettings = JsonConvert.SerializeObject(settings);
                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                        db.SaveChanges();
                        responseText = JsonConvert.SerializeObject(item2update);
                    }
                }
            }
            catch (Exception e)
            {
            }
            return responseText;
        }

        public string GetCurrentVisitForPatient(string cid, int? pid, int vid, bool pvList)
        {
            string response = string.Empty;
            CurrentVisit wInvoice = new CurrentVisit();
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    wInvoice = new CurrentVisit(cid, pid, vid, pvList);
                    response = JsonConvert.SerializeObject(wInvoice);
                }
            }
            catch (Exception e)
            {
                response = string.Empty;
            }
            return response;
        }

        public string AttendPatientForAppointment(int vid, string cid)
        {
            string response = string.Empty;
            CurrentVisit wInvoice = new CurrentVisit();
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    //
                    //
                    //
                    DMV cdmv = new DMV();
                    DMV ldmv = new DMV();
                    Visit cvisit = db.Visits.Find(vid);
                    if (cvisit != null)
                    {
                        try
                        {
                            //was there any past Visit, get last visit
                            Visit lvisit = db.Visits.Where(v => v.CId.Equals(cid) && v.Id != vid && v.PId == cvisit.PId)
                                .OrderByDescending(v => v.RDATE).Take(1).FirstOrDefault();
                            if (lvisit != null && !string.IsNullOrEmpty(lvisit.Diagnosis))
                            {
                                ldmv = JsonConvert.DeserializeObject<DMV>(lvisit.Diagnosis);
                                foreach (string e in ldmv.eList.Keys)
                                {
                                    if ((ldmv.eList[e].P - ldmv.eList[e].A) > 0)
                                    {
                                        foreach (string tn in ldmv.eList[e].tList.Keys)
                                        {
                                            if ((ldmv.eList[e].tList[tn].P - ldmv.eList[e].tList[tn].A) > 0)
                                            {
                                                foreach (PP pp in ldmv.eList[e].tList[tn].ppList)
                                                {
                                                    if ((pp.PQ - pp.AQ) > 0)
                                                    {
                                                        cdmv.P += pp.PA;
                                                        cdmv.A += pp.AA;
                                                        if (cdmv.eList.ContainsKey(e))
                                                        {
                                                            if (cdmv.eList[e].tList.ContainsKey(tn))
                                                            {
                                                                cdmv.eList[e].P += pp.PA;
                                                                cdmv.eList[e].A += pp.AA;

                                                                cdmv.eList[e].tList[tn].P += pp.PA;
                                                                cdmv.eList[e].tList[tn].A += pp.AA;

                                                                cdmv.eList[e].tList[tn].ppList.Add(pp);
                                                            }
                                                            else
                                                            {
                                                                cdmv.eList[e].tList.Add(tn, new TMV());
                                                                cdmv.eList[e].tList[tn].P += pp.PA;
                                                                cdmv.eList[e].tList[tn].A += pp.AA;

                                                                cdmv.eList[e].tList[tn].ppList.Add(pp);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            cdmv.eList.Add(e, new EMV());
                                                            cdmv.eList[e].P += pp.PA;
                                                            cdmv.eList[e].A += pp.AA;

                                                            cdmv.eList[e].tList.Add(tn, new TMV());
                                                            cdmv.eList[e].tList[tn].P += pp.PA;
                                                            cdmv.eList[e].tList[tn].A += pp.AA;

                                                            cdmv.eList[e].tList[tn].ppList.Add(pp);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                cvisit.Diagnosis = JsonConvert.SerializeObject(cdmv);
                                db.Entry(cvisit).State = EntityState.Modified;
                                db.SaveChanges();
                            }
                        }
                        catch(Exception ex)
                        {
                            response = ex.Message;
                        }
                    }
                    //
                    //
                    //
                    db.sp_PatientAttendedForVisit(vid, cid);
                    sp_GetVisitDetailsById_Result vd = db.sp_GetVisitDetailsById(vid, cid).FirstOrDefault();
                    Clients.Caller.PatientAttended(JsonConvert.SerializeObject(vd));
                    string txtDate = string.Format("{0:yyyy-MM-dd}", vd.RDATE);
                    Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(vd.CId, txtDate)));
                }
            }
            catch (Exception e)
            {
                response = e.Message;
            }
            return response;
        }

        public string UpdateDrugInformation(string user, string data, string vData)
        {
            string responseText = string.Empty;
            try
            {
                List<sp_UpdateDrugMasterList_Result> adl = new List<sp_UpdateDrugMasterList_Result>();
                Visit visit = JsonConvert.DeserializeObject<Visit>(vData);
                List<DrugModelView> dList = JsonConvert.DeserializeObject<List<DrugModelView>>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    try
                    {

                        List<Drug> drg2add = dList
                            .Where(a => a.Id == 0)
                            .Select(a => new Drug
                            {
                                Name = (a.N + "").ToUpper(),
                                Type = a.DT,
                                Dose = a.DS,
                                Amnt = a.DC,
                                CId = a.CId
                            }).ToList();

                        foreach (Drug drg in drg2add)
                        {
                            adl.AddRange(db.sp_UpdateDrugMasterList(drg.CId, drg.Type, drg.Code, drg.Name, drg.Amnt, drg.Dose, user));
                        }

                        Visit item = db.Visits.Find(visit.Id);
                        item.Prescription = JsonConvert.SerializeObject(dList);
                        item.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item).State = EntityState.Modified;
                        db.SaveChanges();
                    }
                    catch (Exception ee)
                    {

                    }
                    CurrentVisit wInvoice = new CurrentVisit();
                    wInvoice.vpList = db.VisitPayments.Where(wo => wo.PId == visit.PId && wo.BillId == visit.BillId && wo.VId == visit.Id).ToList();
                    wInvoice.cv = db.sp_GetVisitDetailsById(visit.Id, visit.CId).FirstOrDefault();
                    db.SaveChanges();
                    DateTime dt = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                    string txtDate = string.Format("{0:yyyy-MM-dd}", dt);
                    Clients.Caller.RefreshDrugList(JsonConvert.SerializeObject(adl));
                    
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UpdateHDrugInformation(string user, string data, string vData)
        {
            string responseText = string.Empty;
            try
            {
                List<sp_UpdateDrugMasterList_Result> adl = new List<sp_UpdateDrugMasterList_Result>();
                Visit visit = JsonConvert.DeserializeObject<Visit>(vData);
                List<DrugModelView> dList = JsonConvert.DeserializeObject<List<DrugModelView>>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    try
                    {

                        List<Drug> drg2add = dList
                            .Where(a => a.Id == 0)
                            .Select(a => new Drug
                            {
                                Name = (a.N + "").ToUpper(),
                                Type = a.DT,
                                Dose = a.DS,
                                Amnt = a.DC,
                                CId = a.CId
                            }).ToList();

                        foreach (Drug drg in drg2add)
                        {
                            adl.AddRange(db.sp_UpdateDrugMasterList(drg.CId, drg.Type, drg.Code, drg.Name, drg.Amnt, drg.Dose, user));
                        }

                        Visit item = db.Visits.Find(visit.Id);
                        item.HPrescription = JsonConvert.SerializeObject(dList);
                        item.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item).State = EntityState.Modified;
                        db.SaveChanges();
                    }
                    catch (Exception ee)
                    {

                    }
                    CurrentVisit wInvoice = new CurrentVisit();
                    wInvoice.vpList = db.VisitPayments.Where(wo => wo.PId == visit.PId && wo.BillId == visit.BillId && wo.VId == visit.Id).ToList();
                    wInvoice.cv = db.sp_GetVisitDetailsById(visit.Id, visit.CId).FirstOrDefault();
                    db.SaveChanges();
                    DateTime dt = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                    string txtDate = string.Format("{0:yyyy-MM-dd}", dt);
                    Clients.Caller.RefreshDrugList(JsonConvert.SerializeObject(adl));

                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UpdatePaymentInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                VisitPayment item = JsonConvert.DeserializeObject<VisitPayment>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    string PDATE = string.Format("{0:dd/MM/yyyy}", item.PDATE).Replace("-", "/");
                    Visit pv = db.Visits.Find(item.VId);
                    db.sp_UpdateVisitPaymentsInQuickMode(item.Id, item.ModeOfPayment, item.Amount, item.Remarks, user, item.PId, item.CId, item.VId, item.BillId, PDATE, pv.FY);
                    CurrentVisit wInvoice = new CurrentVisit();
                    wInvoice.vpList = db.VisitPayments.Where(wo => wo.PId == item.PId && wo.BillId == item.BillId && wo.VId == item.VId).ToList();
                    wInvoice.cv = db.sp_GetVisitDetailsById(item.VId, item.CId).FirstOrDefault();
                    Clients.All.RefreshPayments(JsonConvert.SerializeObject(wInvoice));
                    db.SaveChanges();
                    DateTime dt = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                    string txtDate = string.Format("{0:yyyy-MM-dd}", pv.RDATE);
                    Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(pv.CId, txtDate)));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeletePaymentInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                VisitPayment item = JsonConvert.DeserializeObject<VisitPayment>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    db.sp_DeleteVisitPayments(item.Id, user);

                    CurrentVisit wInvoice = new CurrentVisit();
                    wInvoice.vpList = db.VisitPayments.Where(wo => wo.PId == item.PId && wo.BillId == item.BillId && wo.VId == item.VId).ToList();
                    wInvoice.cv = db.sp_GetVisitDetailsById(item.VId, item.CId).FirstOrDefault();
                    Clients.All.RefreshPayments(JsonConvert.SerializeObject(wInvoice));
                    db.SaveChanges();
                    string txtDate = string.Format("{0:yyyy-MM-dd}", wInvoice.cv.RDATE);
                    Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(wInvoice.cv.CId, txtDate)));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UpdateVisitOrderInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                VisitOrder item = JsonConvert.DeserializeObject<VisitOrder>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    Visit ov = db.Visits.Find(item.VId);
                    db.sp_UpdateVisitOrdersInQuickMode(item.ItId, user, item.PId, item.CId, item.VId, item.BillId, item.Qty, ov.FY, item.GRP);
                    CurrentVisit wInvoice = new CurrentVisit();
                    List<VisitOrder> tmpvoList = db.VisitOrders
                        .Where(vo => vo.PId == item.PId &&
                        vo.VId == item.VId).ToList();
                    wInvoice.voList = tmpvoList.GroupBy(v => v.GRP)
                    .ToDictionary(a => a.Key, a => tmpvoList.Where(v => v.GRP.Equals(a.Key))
                    .ToDictionary(vo => vo.Id, vo => vo));
                    wInvoice.cv = db.sp_GetVisitDetailsById(item.VId, item.CId).FirstOrDefault();
                    Clients.All.RefreshVisitOrders(JsonConvert.SerializeObject(wInvoice));
                    string txtDate = string.Format("{0:yyyy-MM-dd}", wInvoice.cv.RDATE);
                    Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(wInvoice.cv.CId, txtDate)));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteVisitOrderInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                VisitOrder item = JsonConvert.DeserializeObject<VisitOrder>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    db.sp_DeleteVisitOrders(item.Id, user);
                    CurrentVisit wInvoice = new CurrentVisit();
                    List<VisitOrder> tmpvoList = db.VisitOrders
                        .Where(vo => vo.PId == item.PId &&
                        vo.VId == item.VId).ToList();
                    wInvoice.voList = tmpvoList.GroupBy(v => v.GRP)
                    .ToDictionary(a => a.Key, a => tmpvoList.Where(v => v.GRP.Equals(a.Key))
                    .ToDictionary(vo => vo.Id, vo => vo));
                    wInvoice.cv = db.sp_GetVisitDetailsById(item.VId, item.CId).FirstOrDefault();
                    Clients.All.RefreshVisitOrders(JsonConvert.SerializeObject(wInvoice));
                    string txtDate = string.Format("{0:yyyy-MM-dd}", wInvoice.cv.RDATE);
                    Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(wInvoice.cv.CId, txtDate)));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string UpdateClinicHolidayInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                ClinicHoliday item = JsonConvert.DeserializeObject<ClinicHoliday>(data);
                ClinicHoliday item2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (item.Id > 0)
                    {
                        item2update = db.ClinicHolidays.Find(item.Id);
                        item2update.ChStartDt = item.ChStartDt;
                        item2update.ChEndDt = item.ChEndDt;
                        item2update.ChReason = item.ChReason;
                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        item.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.ClinicHolidays.Add(item);
                    }
                    db.SaveChanges();
                    Clients.All.RefreshClinicHolidays(JsonConvert.SerializeObject(item));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteClinicHolidayInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                ClinicHoliday item = JsonConvert.DeserializeObject<ClinicHoliday>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    if (item.Id > 0)
                    {
                        ClinicHoliday item2delete = db.ClinicHolidays.Find(item.Id);
                        db.ClinicHolidays.Remove(db.ClinicHolidays.Find(item.Id));
                        db.SaveChanges();
                        Clients.All.RefreshClinicHolidaysAfterDeletion(JsonConvert.SerializeObject(item2delete));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string GetClinicHolidaysForDateRange(string CId, string start, string end)
        {
            string response = string.Empty;
            List<sp_GetClinicHolidaysForDateRange_Result> pList = new List<sp_GetClinicHolidaysForDateRange_Result>();
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    pList = db.sp_GetClinicHolidaysForDateRange(start, end, CId).ToList();
                    response = JsonConvert.SerializeObject(pList);
                }
            }
            catch (Exception e)
            {
                response = string.Empty;
            }
            return response;
        }

        #endregion

        #region Items

        public string UpdateItemInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Item item = JsonConvert.DeserializeObject<Item>(data);
                Item item2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    item2update = db.Items.Find(item.Id);
                    if (item.Id > 0)
                    {

                        item2update.ItRate = item.ItRate;
                        item2update.ItGRP = item.ItGRP;
                        item2update.ItDescription = item.ItDescription;
                        item2update.ItCode = item.ItCode;

                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        Item dupItem = db.Items
                            .Where(a => a.CId.Equals(item.CId) && item.ItCode.Equals(a.ItCode))
                            .FirstOrDefault();
                        if (dupItem != null)
                        {
                            responseText = "An item with Same Code already Exists " + dupItem.ItDescription + " (" + dupItem.ItCode + ")";
                            return responseText;
                        }
                        else
                        {

                        }
                        item.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Items.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshItems(JsonConvert.SerializeObject(db.sp_GetItemsForCompany(item2update.CId, user, item2update.Id).FirstOrDefault()));
                    }
                    else
                    {
                        Clients.All.RefreshItems(JsonConvert.SerializeObject(db.sp_GetItemsForCompany(item.CId, user, item.Id).FirstOrDefault()));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteItemInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Item item = JsonConvert.DeserializeObject<Item>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    db.sp_DeleteItem(item.CId, item.Id, user);
                }
                Clients.All.RefreshItemsAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string GetItemListForCompany(string user, string CompanyId)
        {
            string responseText = string.Empty;
            try
            {
                List<sp_GetItemsForCompany_Result> items = new List<sp_GetItemsForCompany_Result>();
                using (HMSEntities db = new HMSEntities())
                {
                    Clinic company = db.Clinics.Find(CompanyId);
                    if (company != null)
                    {
                        responseText = JsonConvert.SerializeObject(db.sp_GetItemsForCompany(CompanyId, user, 0).ToList());
                    }
                }
            }
            catch (Exception e)
            {
                responseText = string.Empty;
            }
            return responseText;
        }

        #endregion

        #region Symptoms

        public string UpdateSymptomInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Symptom symptom = JsonConvert.DeserializeObject<Symptom>(data);
                Symptom symptom2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    symptom2update = db.Symptoms.Find(symptom.Id);
                    if (symptom.Id > 0)
                    {

                        symptom2update.Name = symptom.Name;

                        symptom2update.UpdatedBy = user;
                        symptom2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(symptom2update).State = EntityState.Modified;
                    }
                    else
                    {
                        Symptom dupSymptom = db.Symptoms
                            .Where(a => a.CId.Equals(symptom.CId) && symptom.Name.Equals(a.Name))
                            .FirstOrDefault();
                        if (dupSymptom != null)
                        {
                            responseText = "An symptom with Same Code already Exists " + dupSymptom.Name;
                            return responseText;
                        }
                        else
                        {

                        }
                        symptom.UpdatedBy = user;
                        symptom.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Symptoms.Add(symptom);
                    }
                    db.SaveChanges();
                    if (symptom2update != null)
                    {
                        Clients.All.RefreshSymptoms(JsonConvert.SerializeObject(symptom2update));
                    }
                    else
                    {
                        Clients.All.RefreshSymptoms(JsonConvert.SerializeObject(symptom));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteSymptomInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Symptom symptom = JsonConvert.DeserializeObject<Symptom>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    db.sp_DeleteSymptom(symptom.CId, symptom.Id, user);
                }
                Clients.All.RefreshSymptomsAfterDeletion(JsonConvert.SerializeObject(symptom));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string GetSymptomListForCompany(string user, string CompanyId)
        {
            string responseText = string.Empty;
            try
            {
                List<sp_GetSymptomsForCompany_Result> symptoms = new List<sp_GetSymptomsForCompany_Result>();
                using (HMSEntities db = new HMSEntities())
                {
                    Clinic company = db.Clinics.Find(CompanyId);
                    if (company != null)
                    {
                        responseText = JsonConvert.SerializeObject(db.sp_GetSymptomsForCompany(CompanyId, user, 0).ToList());
                    }
                }
            }
            catch (Exception e)
            {
                responseText = string.Empty;
            }
            return responseText;
        }

        #endregion

        #region Category

        public string UpdateCategoryInformation(string user, string data)
            {
            string responseText = string.Empty;
            try
            {
                ItemGroup item = JsonConvert.DeserializeObject<ItemGroup>(data);
                ItemGroup item2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    item2update = db.ItemGroups.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.ItGRP = item.ItGRP;
                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        ItemGroup dupCategory = db.ItemGroups
                            .Where(a => a.CId.Equals(item.CId) && item.ItGRP.Equals(a.ItGRP))
                            .FirstOrDefault();
                        if (dupCategory != null)
                        {
                            responseText = "An item with Same Name already Exists " + item.ItGRP;
                            return responseText;
                        }
                        else
                        {

                        }
                        item.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.ItemGroups.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshCategories(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshCategories(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteCategoryInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                ItemGroup item = JsonConvert.DeserializeObject<ItemGroup>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    db.ItemGroups.Remove(db.ItemGroups.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshCategoriesAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion

        #region Dashboard

        public string GetDashboardDataForRange(string user, string start, string end)
        {
            string response = string.Empty;
            DashboardView model = new DashboardView();
            try
            {
                model = new DashboardView(user, start, end);
                response = JsonConvert.SerializeObject(model);
            }
            catch (Exception e)
            {
                response = string.Empty;
            }
            return response;
        }

        #endregion

        #region Category

        public string UpdateDrugInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Drug item = JsonConvert.DeserializeObject<Drug>(data);
                Drug item2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    item2update = db.Drugs.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.Type = item.Type;
                        item2update.Code = item.Code;
                        item2update.Name = item.Name;
                        item2update.Amnt = item.Amnt;
                        item2update.Dose = item.Dose;
                        item2update.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        item2update.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Drugs.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshDrugs(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshDrugs(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteDrugInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Drug item = JsonConvert.DeserializeObject<Drug>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    db.Drugs.Remove(db.Drugs.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshDrugsAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion

        #region IPDManagement

        public string UpdatePackageInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Package item = JsonConvert.DeserializeObject<Package>(data);
                Package item2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    item2update = db.Packages.Find(item.Id);
                    if (item.Id > 0)
                    {

                        item2update.PkgName = item.PkgName;
                        item2update.PkgDescription = item.PkgDescription;

                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        item.PkgItems = 0;
                        item.PkgAmount = 0;
                        item.CreatedBy = user;
                        item.CreatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Packages.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshPackages(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshPackages(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeletePackageInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Package item = JsonConvert.DeserializeObject<Package>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    db.sp_DeleteIPDPackage(item.Id, user);
                }
                Clients.All.RefreshPackagesAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UpdateRateInIPDInvoice(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                VisitOrder item = JsonConvert.DeserializeObject<VisitOrder>(data);
                VisitOrder v2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (item.Id > 0)
                    {
                        v2update = db.VisitOrders.Find(item.Id);
                        v2update.Rate = item.Rate;
                        v2update.UpdatedBy = user;
                        v2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(v2update).State = EntityState.Modified;
                        db.SaveChanges();
                        db.sp_UpdatePaymentInPatientInvoice(v2update.PId, v2update.CId, v2update.BillId, item.VId, item.FY);
                        db.SaveChanges();
                    }
                }
                using (HMSEntities db = new HMSEntities())
                {
                    CurrentVisit wInvoice = new CurrentVisit();
                    wInvoice.vpList = db.VisitPayments.Where(wo => wo.PId == v2update.PId && wo.BillId == v2update.BillId && wo.VId == v2update.Id).ToList();
                    wInvoice.cv = db.sp_GetVisitDetailsById(v2update.VId, v2update.CId).FirstOrDefault();
                    Clients.All.RefreshPayments(JsonConvert.SerializeObject(wInvoice));
                    DateTime dt = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                    string txtDate = string.Format("{0:yyyy-MM-dd}", wInvoice.cv.RDATE);
                    Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(wInvoice.cv.CId, txtDate)));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UpdateDischargeSummaryInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Discharge discharge = JsonConvert.DeserializeObject<Discharge>(data);
                if (discharge.VId > 0)
                {
                    Discharge item2update = null;
                    using (HMSEntities db = new HMSEntities())
                    {
                        item2update = db.Discharges.Find(discharge.Id);
                        if (discharge.Id > 0)
                        {
                            item2update.Summary = discharge.Summary;
                            item2update.AdvForMother = discharge.AdvForMother;
                            item2update.AdvForBaby = discharge.AdvForBaby;
                            item2update.Review = discharge.Review;

                            item2update.UpdatedBy = user;
                            item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                            db.Entry(item2update).State = EntityState.Modified;
                        }
                        else
                        {
                            discharge.CreatedBy = user;
                            discharge.CreatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                            db.Discharges.Add(discharge);
                        }
                        db.SaveChanges();
                        Clients.All.RefreshDischarges(JsonConvert.SerializeObject(item2update));
                    }
                }
                else
                {
                    responseText = "Error in updating discharge summary.";
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string UpdateDischargeInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Visit visit = JsonConvert.DeserializeObject<Visit>(data);
                Visit v2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    if (visit.Id > 0)
                    {
                        v2update = db.Visits.Find(visit.Id);

                        if (v2update != null)
                        {
                            v2update.DisStatus = visit.DisStatus;
                            v2update.DtAdmission = visit.DtAdmission;
                            v2update.DtDischarge = visit.DtDischarge;
                            v2update.RefBy = visit.RefBy;
                            v2update.BabyDOB = visit.BabyDOB;
                            v2update.BabyWeight = visit.BabyWeight;
                            v2update.BabyGender = visit.BabyGender;
                            v2update.UpdatedBy = user;
                            v2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                            db.Entry(v2update).State = EntityState.Modified;
                            db.SaveChanges();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string UpdateDisTemplateInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                DisTemplate item = JsonConvert.DeserializeObject<DisTemplate>(data);
                DisTemplate item2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    item2update = db.DisTemplates.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.dtName = item.dtName;
                        item2update.Summary = item.Summary;
                        item2update.AdvForBaby = item.AdvForBaby;
                        item2update.AdvForMother = item.AdvForMother;
                        item2update.Review = item.Review;

                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        item.CreatedBy = user;
                        item.CreatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.DisTemplates.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshDisTemplates(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshDisTemplates(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteDisTemplateInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                DisTemplate item = JsonConvert.DeserializeObject<DisTemplate>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    db.DisTemplates.Remove(item);
                }
                Clients.All.RefreshDisTemplatesAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UpdatePkgItemInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                PackageOrder item = JsonConvert.DeserializeObject<PackageOrder>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    db.sp_UpdatePackageOrdersInQuickMode(item.ItId, item.ItCode, user, item.PkgId, item.CId, item.ItQty);
                    PackageModelView pmv = new PackageModelView();
                }
                PackageRefreshView prv = new PackageRefreshView(item.PkgId);
                Clients.All.RefreshPkgItems(JsonConvert.SerializeObject(prv));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeletePkgItemInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                PackageOrder item = JsonConvert.DeserializeObject<PackageOrder>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    db.sp_DeletePAckageOrders(item.Id, user);
                }
                PackageRefreshView prv = new PackageRefreshView(item.PkgId);
                Clients.All.RefreshPkgItems(JsonConvert.SerializeObject(prv));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string UpdateBirthInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Birth item = JsonConvert.DeserializeObject<Birth>(data);
                Birth item2update = null;
                using (HMSEntities db = new HMSEntities())
                {
                    item2update = db.Births.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.BbDOB = item.BbDOB;
                        item2update.BbGender = item.BbGender;
                        item2update.BbName = item.BbName;
                        item2update.BbWeight = item.BbWeight;
                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        item.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Births.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshBirths(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshBirths(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteBirthInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Birth item = JsonConvert.DeserializeObject<Birth>(data);
                using (HMSEntities db = new HMSEntities())
                {
                    db.Births.Remove(db.Births.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshBirthsAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        public string ApplyPackageForPatient(int VId, int PkgId, string User)
        {
            string responseText = string.Empty;
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    Visit visit = db.Visits.Find(VId);
                    db.sp_IncludePackageItemsInInvoice(VId, PkgId, User);
                    CurrentVisit wInvoice = new CurrentVisit(visit.CId, visit.PId ?? 0, visit.Id, true);
                    Clients.Caller.RefreshCurrentVisit(JsonConvert.SerializeObject(wInvoice));
                    string txtDate = string.Format("{0:yyyy-MM-dd}", wInvoice.cv.RDATE);
                    Clients.Caller.RefreshSalesSummary(JsonConvert.SerializeObject(new SalesSummaryModel(wInvoice.cv.CId, txtDate)));
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion
    }
}
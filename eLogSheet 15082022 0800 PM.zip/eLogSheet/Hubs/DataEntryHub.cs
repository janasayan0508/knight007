﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using eLogSheet;
using eLogSheet.Models;
using eLogSheet.Utilities;
using Microsoft.AspNet.SignalR;
using Newtonsoft.Json;

namespace eLogSheet.Hubs
{
    public class DataEntryHub : Hub
    {
        #region Settings
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        public string SaveDataForTheDay(string user, string dt, int did,  string data)
        {
            string responseText = string.Empty;
            List<Datum> dtList = JsonConvert.DeserializeObject<List<Datum>>(data);
            try
            {
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    foreach(Datum d in dtList)
                    {
                        if (d.Id > 0)
                        {
                            Datum item2update = db.Data.Find(d.Id);
                            item2update.PDV = d.PDV;
                            item2update.bitValue = d.bitValue;
                            item2update.intValue = d.intValue;
                            item2update.decimalValue = d.decimalValue;
                            item2update.txtValue = d.txtValue;
                            item2update.dtValue = d.dtValue;
                            item2update.UpdatedBy = user;
                            item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                            db.Entry(item2update).State = EntityState.Modified;
                        }
                        else
                        {
                            d.CreatedBy = user;
                            d.CreatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                            d.UpdatedBy = user;
                            d.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                            db.Data.Add(d);
                        }
                        db.SaveChanges();
                    }
                }
                Clients.All.RefreshSheetViewModel(new SheetView(user, dt, did).json.ToString());
                Clients.All.RefreshDashboardViewModel(new DashboardView(user, dt).json.ToString());
            }
            catch (Exception e)
            {
                responseText = string.Empty;
            }
            return responseText;
        }

        public string GetDataForTheDay(string user, string dt, int did)
        {
            string responseText = string.Empty;
            try
            {
                responseText = new SheetView(user, dt, did).json.ToString();
            }
            catch (Exception e)
            {
                responseText = string.Empty;
            }
            return responseText;
        }

        public string GetDashboardDataForTheDay(string user, string dt)
        {
            string responseText = string.Empty;
            try
            {
                responseText = new DashboardView(user, dt).json.ToString();
            }
            catch (Exception e)
            {
                responseText = string.Empty;
            }
            return responseText;
        }

        #endregion

        #region Delays

        public string UpdateDelayInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Delay item = JsonConvert.DeserializeObject<Delay>(data);
                Delay item2update = null;
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    item2update = db.Delays.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.DtStart = item.DtStart;
                        item2update.DtEnd = item.DtEnd;
                        item2update.HH = item.HH;
                        item2update.MM = item.MM;
                        item2update.SS = item.SS;
                        item2update.Agency = item.Agency;
                        item2update.Reason = item.Reason;
                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        item.CreatedBy = user;
                        item.CreatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        item.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Delays.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshDelays(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshDelays(JsonConvert.SerializeObject(item));
                    }
                    Clients.All.RefreshDashboardViewModel(new DashboardView(user, string.Format("{0:yyyyMMdd}", item.DT)).json.ToString());
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteDelayInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Delay item = JsonConvert.DeserializeObject<Delay>(data);
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    db.Delays.Remove(db.Delays.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshDelaysAfterDeletion(JsonConvert.SerializeObject(item));
                Clients.All.RefreshDashboardViewModel(new DashboardView(user, string.Format("{0:yyyyMMdd}", item.DT)).json.ToString());
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion

        #region Delays

        public string UpdateAnnouncementInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Announcement item = JsonConvert.DeserializeObject<Announcement>(data);
                Announcement item2update = null;
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    item2update = db.Announcements.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.MsgDtStart = item.MsgDtStart;
                        item2update.MsgDtEnd = item.MsgDtEnd;

                        item2update.MsgTitle = item.MsgTitle;
                        item2update.MsgDesc = item.MsgDesc;
                        item2update.MsgUrl = item.MsgUrl;
                        item2update.MsgTitle = item.MsgTitle;
                        item2update.VisibleTo = item.VisibleTo;

                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        item.CreatedBy = user;
                        item.CreatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        item.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Announcements.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshAnnouncements(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshAnnouncements(JsonConvert.SerializeObject(item));
                    }
                    Clients.All.RefreshDashboardViewModel(new DashboardView(user, string.Format("{0:yyyyMMdd}", item.DT)).json.ToString());
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteAnnouncementInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Announcement item = JsonConvert.DeserializeObject<Announcement>(data);
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    db.Announcements.Remove(db.Announcements.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshAnnouncementsAfterDeletion(JsonConvert.SerializeObject(item));
                Clients.All.RefreshDashboardViewModel(new DashboardView(user, string.Format("{0:yyyyMMdd}", item.DT)).json.ToString());
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion

        #region Parameters

        public string UpdateParameterInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Parameter item = JsonConvert.DeserializeObject<Parameter>(data);
                Parameter item2update = null;
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    item2update = db.Parameters.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.Name = item.Name;
                        item2update.Desc = item.Desc;
                        item2update.Datatype = item.Datatype;
                        item2update.Min = item.Min;
                        item2update.Max = item.Max;
                        item2update.Regex = item.Regex;
                        item2update.IsRequired = item.IsRequired ?? true;
                        item2update.IsEnabled = item.IsEnabled ?? true;
                        item2update.IsNumber = item.IsNumber ?? false;
                        item2update.IsDP = item.IsDP ?? false;
                        item2update.Unit = item.Unit;
                        item2update.InpType = item.InpType;
                        item2update.InpValues = item.InpValues;
                        item2update.InpField = item.InpField;

                        item2update.MId = item.MId;
                        item2update.TId = item.TId;
                        item2update.EId = item.EId;
                        item2update.FId = item.FId;

                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        db.Parameters.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshParameters(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshParameters(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteParameterInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Parameter item = JsonConvert.DeserializeObject<Parameter>(data);
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    db.Parameters.Remove(db.Parameters.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshParametersAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion




        #region Machines

        public string UpdateMachineInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Machine item = JsonConvert.DeserializeObject<Machine>(data);
                Machine item2update = null;
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    item2update = db.Machines.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.Name = item.Name;
                        item2update.Desc = item.Desc;
                        item2update.IsEnabled = item.IsEnabled;
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        db.Machines.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshMachines(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshMachines(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteMachineInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Machine item = JsonConvert.DeserializeObject<Machine>(data);
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    db.Machines.Remove(db.Machines.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshMachinesAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion




        #region Equipments

        public string UpdateEquipmentInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Equipment item = JsonConvert.DeserializeObject<Equipment>(data);
                Equipment item2update = null;
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    item2update = db.Equipments.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.Name = item.Name;
                        item2update.Desc = item.Desc;
                        item2update.IsEnabled = item.IsEnabled;
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        db.Equipments.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshEquipments(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshEquipments(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteEquipmentInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Equipment item = JsonConvert.DeserializeObject<Equipment>(data);
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    db.Equipments.Remove(db.Equipments.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshEquipmentsAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion



        #region Titles

        public string UpdateTitleInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Title item = JsonConvert.DeserializeObject<Title>(data);
                Title item2update = null;
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    item2update = db.Titles.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.Name = item.Name;
                        item2update.Desc = item.Desc;
                        item2update.IsEnabled = item.IsEnabled;
                        item2update.Remarks = item.Remarks;
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        db.Titles.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshTitles(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshTitles(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteTitleInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Title item = JsonConvert.DeserializeObject<Title>(data);
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    db.Titles.Remove(db.Titles.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshTitlesAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion




        #region Frequency

        public string UpdateFrequencyInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Frequency item = JsonConvert.DeserializeObject<Frequency>(data);
                Frequency item2update = null;
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    item2update = db.Frequencies.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.Freq = item.Freq;
                        item2update.UpdatedBy = item.UpdatedBy;
                        item2update.UpdatedOn = item.UpdatedOn;
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        db.Frequencies.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshFrequency(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshFrequency(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteFrequencyInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Frequency item = JsonConvert.DeserializeObject<Frequency>(data);
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    db.Frequencies.Remove(db.Frequencies.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshFrequencyAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion



        #region Fvalues

        public string UpdateFvaluesInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                FValue item = JsonConvert.DeserializeObject<FValue>(data);
                FValue item2update = null;
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    item2update = db.FValues.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.FType = item.FType;
                        item2update.FValue1 = item.FValue1;
                        item2update.UpdatedBy = item.UpdatedBy;
                        item2update.UpdatedOn = item.UpdatedOn;
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        db.FValues.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshFvalues(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshFvalues(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteFvaluesInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                FValue item = JsonConvert.DeserializeObject<FValue>(data);
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    db.FValues.Remove(db.FValues.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshFvaluesAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion 



        #region Incidents

        public string UpdateIncidentInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Incident item = JsonConvert.DeserializeObject<Incident>(data);
                Incident item2update = null;
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    item2update = db.Incidents.Find(item.Id);
                    if (item.Id > 0)
                    {
                        item2update.IncDate = item.IncDate;
                        item2update.Agency = item.Agency;
                        item2update.Reason = item.Reason;
                        item2update.BriefDesc = item.BriefDesc;
                        item2update.ShiftInc = item.ShiftInc;
                        item2update.IncLocation = item.IncLocation;
                        item2update.IncType = item.IncType;
                        item2update.MsrsTaken = item.MsrsTaken;
                        item2update.UpdatedBy = user;
                        item2update.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Entry(item2update).State = EntityState.Modified;
                    }
                    else
                    {
                        item.CreatedBy = user;
                        item.CreatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        item.UpdatedBy = user;
                        item.UpdatedOn = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        db.Incidents.Add(item);
                    }
                    db.SaveChanges();
                    if (item2update != null)
                    {
                        Clients.All.RefreshIncidents(JsonConvert.SerializeObject(item2update));
                    }
                    else
                    {
                        Clients.All.RefreshIncidents(JsonConvert.SerializeObject(item));
                    }
                }
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }
        public string DeleteIncidentInformation(string user, string data)
        {
            string responseText = string.Empty;
            try
            {
                Incident item = JsonConvert.DeserializeObject<Incident>(data);
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    db.Incidents.Remove(db.Incidents.Find(item.Id));
                    db.SaveChanges();
                }
                Clients.All.RefreshIncidentsAfterDeletion(JsonConvert.SerializeObject(item));
            }
            catch (Exception e)
            {
                responseText = e.Message;
            }
            return responseText;
        }

        #endregion
    }
}
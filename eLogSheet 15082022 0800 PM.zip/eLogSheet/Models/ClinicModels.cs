﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Clinic.Models
{

    public class AccDetailsView
    {
        public string DateRange { get; set; }
        public Clinic C { get; set; }
        public UserView U { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public Dictionary<DateTime?, List<sp_GetBillingDateWiseDuesSummaryForAccounts_Result>> d1List { get; set; }
        public Dictionary<DateTime?, sp_GetBillingDateWiseSummaryForAccounts_Result> d1Sum { get; set; }
        public Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>> b1List { get; set; }

        public Dictionary<DateTime?, List<sp_GetBillingDateWiseDuesSummaryForAccounts_Result>> d2List { get; set; }
        public Dictionary<DateTime?, sp_GetBillingDateWiseSummaryForAccounts_Result> d2Sum { get; set; }
        public Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>> b2List { get; set; }

        public Dictionary<DateTime?, List<sp_GetBillingDateWiseDuesSummaryForAccounts_Result>> d4List { get; set; }
        public Dictionary<DateTime?, sp_GetBillingDateWiseSummaryForAccounts_Result> d4Sum { get; set; }
        public Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>> b4List { get; set; }

        public Dictionary<DateTime?, List<sp_GetBillingDateWiseDuesSummaryForAccounts_Result>> d3List { get; set; }
        public Dictionary<DateTime?, sp_GetBillingDateWiseSummaryForAccounts_Result> d3Sum { get; set; }
        public Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>> b3List { get; set; }

        public sp_GetBillingDateWiseSummaryForAccounts_Result b1Total { get; set; }
        public sp_GetBillingDateWiseSummaryForAccounts_Result b2Total { get; set; }
        public sp_GetBillingDateWiseSummaryForAccounts_Result b3Total { get; set; }

        public sp_GetBillingDateWiseSummaryForAccounts_Result b4Total { get; set; }

        public AccDetailsView()
        {

            b1Total = new sp_GetBillingDateWiseSummaryForAccounts_Result();
            b2Total = new sp_GetBillingDateWiseSummaryForAccounts_Result();
            b3Total = new sp_GetBillingDateWiseSummaryForAccounts_Result();
            b4Total = new sp_GetBillingDateWiseSummaryForAccounts_Result();

            d1List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseDuesSummaryForAccounts_Result>>();
            d1Sum = new Dictionary<DateTime?, sp_GetBillingDateWiseSummaryForAccounts_Result>();
            b1List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>>();

            d2List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseDuesSummaryForAccounts_Result>>();
            d2Sum = new Dictionary<DateTime?, sp_GetBillingDateWiseSummaryForAccounts_Result>();
            b2List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>>();

            d3List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseDuesSummaryForAccounts_Result>>();
            d3Sum = new Dictionary<DateTime?, sp_GetBillingDateWiseSummaryForAccounts_Result>();
            b3List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>>();

            d4List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseDuesSummaryForAccounts_Result>>();
            d4Sum = new Dictionary<DateTime?, sp_GetBillingDateWiseSummaryForAccounts_Result>();
            b4List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>>();

            b1List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>>();
            b2List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>>();
            b3List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>>();
            b4List = new Dictionary<DateTime?, List<sp_GetBillingDateWiseSummaryForAccounts_Result>>();
        }
    }

    public class SalesSummaryModel
    {
        public string CId { get; set; }
        public string RDATE { get; set; }
        public List<sp_GetDailySalesForDate_Result> S { get; set; }
        public sp_GetDailySalesForDate_Result C { get; set; }

        public SalesSummaryModel(string cid, string date)
        {
            CId = cid;
            RDATE = date;
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    S = db.sp_GetDailySalesForDate(date, cid).ToList();
                    C = S.GroupBy(s => "Total")
                        .Select(s => new sp_GetDailySalesForDate_Result
                        {
                            AT = s.Key,
                            C = s.Sum(a => a.C ?? 0),
                            Gross = s.Sum(a => a.Gross ?? 0),
                            NetAmnt = s.Sum(a => a.NetAmnt ?? 0),
                            Cash = s.Sum(a => a.Cash ?? 0),
                            Cards = s.Sum(a => a.Cards ?? 0),
                            Cheque = s.Sum(a => a.Cheque ?? 0),
                            Due = s.Sum(a => a.Due ?? 0),
                            Paid = s.Sum(a => a.Paid ?? 0),
                            Neft = s.Sum(a => a.Neft ?? 0),
                            GuestCrdt = s.Sum(a => a.GuestCrdt ?? 0),
                            Complntry = s.Sum(a => a.Complntry ?? 0),
                        })
                        .FirstOrDefault();
                }
            }
            catch (Exception e)
            {

            }
        }

        public SalesSummaryModel(string cid, string start, string end)
        {
            CId = cid;
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    S = db.sp_GetDailySalesForDateRange(start, end, cid).ToList();
                    C = S.GroupBy(s => "Total")
                        .Select(s => new sp_GetDailySalesForDate_Result
                        {
                            AT = s.Key,
                            Gross = s.Sum(a => a.Gross ?? 0),
                            NetAmnt = s.Sum(a => a.NetAmnt ?? 0),
                            Cash = s.Sum(a => a.Cash ?? 0),
                            Cards = s.Sum(a => a.Cards ?? 0),
                            Cheque = s.Sum(a => a.Cheque ?? 0),
                            Due = s.Sum(a => a.Due ?? 0),
                            Paid = s.Sum(a => a.Paid ?? 0),
                            Neft = s.Sum(a => a.Neft ?? 0),
                            GuestCrdt = s.Sum(a => a.GuestCrdt ?? 0),
                            Complntry = s.Sum(a => a.Complntry ?? 0),
                        })
                        .FirstOrDefault();
                }
            }
            catch (Exception e)
            {

            }
        }
    }

    public class PatientDetailsView
    {
        public sp_GetPatientListForSearchPageByCompanyId_Result vSummary { get; set; }
        public Patient P { get; set; }
        public List<Visit> pvList { get; set; }
        public List<PatientVisit> vdList { get; set; }
        public PatientDetailsView()
        {
            vSummary = new sp_GetPatientListForSearchPageByCompanyId_Result();
            pvList = new List<Visit>();
            vdList = new List<PatientVisit>();
        }
    }

    public class PatientSearchView
    {
        public UserView U { get; set; }
        public Clinic C { get; set; }
        public string SearchTxt { get; set; }
        public List<sp_GetPatientListForSearchPageByCompanyId_Result> ptList { get; set; }

        public PatientSearchView()
        {
            ptList = new List<sp_GetPatientListForSearchPageByCompanyId_Result>();
        }
        public PatientSearchView(string user, string text)
        {
            try
            {
                using(HMSEntities db = new HMSEntities())
                {
                    U = db.AspNetUsers
                        .Where(u => u.UserName.Equals(user))
                        .Select(u => new UserView
                        {
                            U = u.UserName,
                            N = u.UserName,
                            M = u.PhoneNumber,
                            Id = u.Id,
                            CId = u.CId,
                            LI = u.LastLoginIP,
                            LL = u.LastLogin
                        })
                        .FirstOrDefault();
                    if (U != null)
                    {
                        C = db.Clinics.Find(U.CId);
                        if (!string.IsNullOrEmpty(text))
                        {
                            ptList = db.sp_GetPatientListForSearchPageByCompanyId(text, C.Id).ToList();
                        }
                    }
                }
            }
            catch(Exception e)
            {
                ptList = new List<sp_GetPatientListForSearchPageByCompanyId_Result>();
            }

        }
    }

    public class InvDetailsView
    {
        public string DateRange { get; set; }
        public string AppType { get; set; }
        public Clinic C { get; set; }
        public UserView U { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public Dictionary<string, List<kotItem>> kotList { get; set; }
        public CategorySale GrandTotal { get; set; }
        public List<KOT> kotSummary { get; set; }
    }

    public class KOT
    {
        public int ps { get; set; }
        public int KOTId { get; set; }
        public int Code { get; set; }
        public string Desc { get; set; }
        public decimal Rate { get; set; }
        public decimal Qty { get; set; }
        public int Tx { get; set; }
        public decimal RevQty { get; set; }
        public string Reason { get; set; }
    }

    public class CategorySale
    {
        public string B { get; set; }
        public int KOTNo { get; set; }
        public decimal Gross { get; set; }
        public decimal Disc { get; set; }
        public decimal GST { get; set; }
        public decimal ServCharge { get; set; }
        public decimal Net { get; set; }
    }

    public class kotItem
    {
        public sp_GetVisitDetailsById_Result visit { get; set; }
        public int kps { get; set; }
        public int bps { get; set; }
        public decimal BillAmnt { get; set; }
        public decimal DiscAmount { get; set; }
        public decimal DiscPercentAmount { get; set; }
        public decimal GSTAmount { get; set; }
        public decimal GrossTotal { get; set; }
        public string BillAmntWords { get; set; }
        public List<KOT> Orders { get; set; }
        public List<KOT> cOrders { get; set; }
        public List<VisitPayment> pList { get; set; }

        public kotItem()
        {
            pList = new List<VisitPayment>();
            cOrders = new List<KOT>();
            Orders = new List<KOT>();
            visit = new sp_GetVisitDetailsById_Result();
        }
    }

    public class AdminSettingsView
    {
        public List<Clinic> cList { get; set; }
        public List<sp_GetClinicUserListForAdmin_Result> uList { get; set; }
        public UserView U { get; set; }
        public AdminSettingsView()
        {
            U = new UserView();
            cList = new List<Clinic>();
            uList = new List<sp_GetClinicUserListForAdmin_Result>();
        }
        public AdminSettingsView(string user)
        {
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    U = db.AspNetUsers
                        .Where(u => u.UserName.Equals(user))
                        .Select(u => new UserView
                        {
                            U = u.UserName,
                            N = u.UserName,
                            M = u.PhoneNumber,
                            Id = u.Id,
                            CId = u.CId,
                            LI = u.LastLoginIP,
                            LL = u.LastLogin
                        })
                        .FirstOrDefault();
                    if (U != null)
                    {
                        uList = db.sp_GetClinicUserListForAdmin()
                            .ToList();
                        cList = db.Clinics.ToList();
                    }
                }
            }
            catch (Exception e)
            {
                U = new UserView();
                uList = new List<sp_GetClinicUserListForAdmin_Result>();
                cList = new List<Clinic>();
            }
        }
    }
    public class DashboardView
    {
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        public List<sp_GetAppointmentListForDateRange_Result> aList { get; set; }
        public sp_GetDashboardIncomeForDateRange_Result did { get; set; }
        public List<sp_DashboardDisplayParameters_Result> dpList { get; set; }
        public UserView U { get; set; }
        public string dtRange { get; set; }
        public string start { get; set; }
        public string end { get; set; }
        public DashboardView()
        {
            U = new UserView();
            aList = new List<sp_GetAppointmentListForDateRange_Result>();
            dpList = new List<sp_DashboardDisplayParameters_Result>();
            did = new sp_GetDashboardIncomeForDateRange_Result();
        }
        public DashboardView(string user, string sd, string ed)
        {
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    U = db.AspNetUsers
                        .Where(u => u.UserName.Equals(user))
                        .Select(u => new UserView
                        {
                            U = u.UserName,
                            N = u.UserName,
                            M = u.PhoneNumber,
                            Id = u.Id,
                            CId = u.CId,
                            LI = u.LastLoginIP,
                            LL = u.LastLogin
                        })
                        .FirstOrDefault();
                    if (U != null)
                    {
                        DateTime today = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
                        if (string.IsNullOrEmpty(sd))
                        {
                            sd = string.Format("{0:yyyy-MM-dd}", new DateTime(today.Year, today.Month, 1));
                        }
                        if (string.IsNullOrEmpty(ed))
                        {
                            ed = string.Format("{0:yyyy-MM-dd}", new DateTime(today.Year, today.Month, DateTime.DaysInMonth(today.Year, today.Month)));
                        }
                        start = sd;
                        end = ed;

                        dtRange = sd + " TO " + ed;

                        aList = db.sp_GetAppointmentListForDateRange(sd, ed, U.CId, string.Empty).ToList();
                        dpList = db.sp_DashboardDisplayParameters(sd, ed, U.CId).ToList();
                        did = db.sp_GetDashboardIncomeForDateRange(sd, ed, U.CId).FirstOrDefault();
                    }
                }
            }
            catch (Exception e)
            {
                U = new UserView();
                U = new UserView();
                aList = new List<sp_GetAppointmentListForDateRange_Result>();
                dpList = new List<sp_DashboardDisplayParameters_Result>();
                did = new sp_GetDashboardIncomeForDateRange_Result();
            }
        }
    }
    public class SettingsView
    {
        public List<ItemGroup> igList { get; set; }
        public List<Drug> drugList { get; set; }
        public List<Item> itemList { get; set; }
        public Dictionary<string, Setting> list { get; set; }
        public List<Symptom> symList { get; set; }
        public Clinic C { get; set; }
        public List<sp_GetClinicUserList_Result> uList { get; set; }
        public ClinicSettings CS { get; set; }
        public UserView U { get; set; }
        public SettingsView()
        {
            igList = new List<ItemGroup>();
            C = new Clinic();
            U = new UserView();
            uList = new List<sp_GetClinicUserList_Result>();
            drugList = new List<Drug>();
            itemList = new List<Item>();
            symList = new List<Symptom>();
        }
        public SettingsView(string user, string cid)
        {
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    U = db.AspNetUsers
                        .Where(u => u.UserName.Equals(user))
                        .Select(u => new UserView
                        {
                            U = u.UserName,
                            N = u.UserName,
                            M = u.PhoneNumber,
                            Id = u.Id,
                            CId = u.CId,
                            LI = u.LastLoginIP,
                            LL = u.LastLogin
                        })
                        .FirstOrDefault();
                    if (U != null)
                    {
                        C = db.Clinics.Find(U.CId);
                        if(C==null)
                        {
                            C = db.Clinics.Find(cid);
                        }
                        igList = db.ItemGroups
                            .Where(i=>i.CId.Equals(C.Id))
                            .ToList();
                        drugList = db.Drugs
                            .Where(i => i.CId.Equals(C.Id))
                            .ToList();
                        uList = db.sp_GetClinicUserList(C.Id)
                            .ToList();
                        itemList = db.Items
                            .Where(i => i.CId.Equals(C.Id))
                            .ToList();
                        symList = db.Symptoms
                            .Where(i => i.CId.Equals(C.Id))
                            .ToList();

                        list = db.Settings
                            .Where(i => i.CId.Equals(C.Id))
                            .ToDictionary(i => i.NM, i => i);

                    }
                }
            }
            catch (Exception e)
            {
                igList = new List<ItemGroup>();
                C = new Clinic();
                U = new UserView();
                uList = new List<sp_GetClinicUserList_Result>();
                drugList = new List<Drug>();
                itemList = new List<Item>();
                symList = new List<Symptom>();
                list = new Dictionary<string, Setting>();
            }
        }
    }
    public class ClinicSettings
    {
        public string CId { get; set; }
        public string WeeklyOff { get; set; }
        public string PresHdrStr { get; set; }
        public string InvHdrStr { get; set; }
        public string ClIconStr { get; set; }
        public string ClBirthCertStr { get; set; }
        public string Timings { get; set; }
        public string InvFooterNotes { get; set; }
        public string PrescFooterNotes { get; set; }

        public bool ACN_FRM_HDR { get; set; }
        public DateTime LastUpdatedOn { get; set; }
        public string LastUpdatedBy { get; set; }
        public int MAX_APT_DAY { get; set; } 
    }
    public class ClinicSettingsView
    {
        public string CId { get; set; }
        public string WeeklyOff { get; set; }
        public HttpPostedFileBase PresHdrImg { get; set; }
        public HttpPostedFileBase InvHdrImg { get; set; }
        public HttpPostedFileBase ClIconImg { get; set; }

        public bool ACN_FRM_HDR { get; set; }
        public HttpPostedFileBase ClBirthCertImg { get; set; }

        public string ClBirthCertStr { get; set; }
        public string PresHdrStr { get; set; }
        public string InvHdrStr { get; set; }
        public string ClIconStr { get; set; }
        public string Timings { get; set; }
        public string InvFooterNotes { get; set; }
        public string PrescFooterNotes { get; set; }
        public int MAX_APT_DAY { get; set; }
        public DateTime LastUpdatedOn { get; set; }
        public string LastUpdatedBy { get; set; }
    }
    public class DoctorView
    {
        public Dictionary<string, List<sp_GetItemsForCompany_Result>> Items { get; set; }

        public List<Symptom> symList { get; set; }
        public Clinic C { get; set; }
        public UserView U { get; set; }
        public sp_GetDefaultDoctorDetails_Result D { get; set; }
        public DoctorView()
        {
            Items = new Dictionary<string, List<sp_GetItemsForCompany_Result>>();
            C = new Clinic();
            U = new UserView();
            D = new sp_GetDefaultDoctorDetails_Result();
        }
        public DoctorView(string user)
        {
            try
            {
                using(HMSEntities db = new HMSEntities())
                {
                    U = db.AspNetUsers
                        .Where(u => u.UserName.Equals(user))
                        .Select(u => new UserView { 
                            U = u.UserName,
                            N = u.UserName,
                            M = u.PhoneNumber,
                            Id = u.Id,
                            CId = u.CId,
                            LI = u.LastLoginIP,
                            LL = u.LastLogin
                        })
                        .FirstOrDefault();
                    if (U != null)
                    {
                        C = db.Clinics.Find(U.CId);
                        D = db.sp_GetDefaultDoctorDetails(C.Id).FirstOrDefault();
                        List<sp_GetItemsForCompany_Result> tmpList = new List<sp_GetItemsForCompany_Result>();
                        tmpList = db.sp_GetItemsForCompany(U.CId, user, 0).ToList();
                        Items = tmpList
                            .GroupBy(t=>t.ItGRP)
                            .ToDictionary(c => c.Key, c=> tmpList.Where(t=>t.ItGRP.Equals(c.Key)).ToList());
                        symList = db.Symptoms.Where(s => s.CId.Equals(U.CId)).ToList();
                    }
                }
            }
            catch(Exception e)
            {
                Items = new Dictionary<string, List<sp_GetItemsForCompany_Result>>();
                C = new Clinic();
                D = new sp_GetDefaultDoctorDetails_Result();
                U = new UserView();
                symList = new List<Symptom>();
            }
        }
    }
    public class UserView
    {
        public string Id { get; set; }
        public string CId { get; set; }
        public string U { get; set; }

        public string N { get; set; }
        public string E { get; set; }
        public string M { get; set; }
        public DateTime? LL { get; set; }
        public string LI { get; set; }

        public string M1 { get; set; }
        public string M2 { get; set; }
        public string M3 { get; set; }

        public UserView()
        {

        }
        public UserView(string uid)
        {
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    AspNetUser user = db.AspNetUsers
                        .Where(u => u.UserName.Equals(uid))
                        .FirstOrDefault();
                    if (user != null)
                    {
                        U = user.UserName;
                        N = user.UserName;
                        M = user.PhoneNumber;
                        Id = user.Id;
                        CId = user.CId;
                        LI = user.LastLoginIP;
                        LL = user.LastLogin;
                        M1 = user.M1;
                        M2 = user.M2;
                        M3 = user.M3;
                    }
                }
            }
            catch(Exception e)
            {

            }
        }
    }
    public class DrugModelView
    {
        public int Id { get; set; }
        public string DT { get; set; }
        public string N { get; set; }
        public string DS { get; set; }
        public string DF { get; set; }
        public string DC { get; set; }
        public int DY { get; set; }
        public double T { get; set; }
        public string R { get; set; }
        public string CId { get; set; }
        public int HId { get; set; }
    }
    public class CurrentVisit
    {
        public Clinic C { get; set; }
        public sp_GetDefaultDoctorDetails_Result D { get; set; }
        public ClinicSettings CS { get; set; }
        public Patient P { get; set; }
        public Visit V { get; set; }
        public Discharge ds { get; set; }
        public List<Birth> births { get; set; }
        public sp_GetVisitDetailsById_Result cv { get; set; }
        public Dictionary<string, Dictionary<int, VisitOrder>> voList { get; set; }
        public Dictionary<string, List<EPP>> pveppList { get; set; }
        public DMV dmv { get; set; }
        public Dictionary<string, Dictionary<string, Dictionary<string, int>>> imv { get; set; }
        public List<VisitPayment> vpList { get; set; }
        public List<Visit> pvList { get; set; }
        public List<DrugModelView> dList { get; set; }
        public List<DrugModelView> hdList { get; set; }
        public string DueInWords { get; set; }
        public string NetAmntInWords { get; set; }
        public CurrentVisit()
        {
            voList = new Dictionary<string, Dictionary<int, VisitOrder>>();
            imv = new Dictionary<string, Dictionary<string, Dictionary<string, int>>>();
            pveppList = new Dictionary<string, List<EPP>>();
            vpList = new List<VisitPayment>();
            pvList = new List<Visit>();
            dmv = new DMV();
        }
        public CurrentVisit(string cid, int? pid, int vid, bool pastVisits)
        {
            try
            {
                using (HMSEntities db = new HMSEntities())
                {

                    P = db.Patients.Find(pid);
                    V = db.Visits.Find(vid);
                    C = db.Clinics.Find(cid);
                    if (P!=null && V!=null && C!=null)
                    {
                        C = db.Clinics.Find(cid);

                        if (!string.IsNullOrEmpty(C.ClSettings))
                        {
                            CS = JsonConvert.DeserializeObject<ClinicSettings>(C.ClSettings);
                        }
                        else
                        {
                            CS = new ClinicSettings();
                        }
                        D = db.sp_GetDefaultDoctorDetails(C.Id).FirstOrDefault();
                        List<VisitOrder> tmpvoList = db.VisitOrders
                        .Where(vo => vo.PId == pid &&
                        vo.VId == vid).ToList();
                        voList = tmpvoList.GroupBy(v => v.GRP)
                        .ToDictionary(a => a.Key, a => tmpvoList.Where(v => v.GRP.Equals(a.Key))
                        .ToDictionary(vo => vo.Id, vo => vo));

                        vpList = db.VisitPayments
                                .Where(vo => vo.PId==pid &&
                                vo.VId == vid)
                                .ToList();
                        if (pastVisits)
                        {
                            pvList = db.Visits.Where(pv => pid==pv.PId &&
                            pv.CId.Equals(P.CId) &&
                            pv.Id != vid)
                                .ToList();
                            cv = db.sp_GetVisitDetailsById(vid, P.CId).FirstOrDefault();
                        }
                        else
                        {
                            pvList = new List<Visit>();
                            cv = db.sp_GetVisitDetailsById(vid, P.CId).FirstOrDefault();
                        }

                        //int cnt = 0;
                        //pveppList = new Dictionary<string, List<EPP>>();
                        //foreach (Visit tmpv in pvList)
                        //{
                        //    cnt++;
                        //    string vd = string.Format("{0:yyyy-MM-dd}", tmpv.RDATE);
                        //    if (!pveppList.ContainsKey(vd))
                        //    {
                        //        if(string.IsNullOrEmpty(tmpv.Diagnosis))
                        //        {
                        //            pveppList.Add(vd, new List<EPP>());
                        //        }
                        //        else
                        //        {
                        //            pveppList.Add(vd, JsonConvert.DeserializeObject<List<EPP>>(tmpv.Diagnosis));
                        //        }
                                
                        //    }
                        //    if (cnt > 2)
                        //    {
                        //        break;
                        //    }
                        //}

                        DueInWords = Utility.NumberToWords((int)V.Due);
                        NetAmntInWords = Utility.NumberToWords((int)V.NetAmnt);
                        try
                        {
                            if (string.IsNullOrEmpty(V.Prescription))
                            {
                                dList = new List<DrugModelView>();
                            }
                            else
                            {
                                dList = JsonConvert.DeserializeObject<List<DrugModelView>>(V.Prescription);
                                dList = dList.Select(c => { c.Id = -1; return c; }).ToList();
                            }
                        }
                        catch (Exception de)
                        {
                            dList = new List<DrugModelView>();
                        }

                        try
                        {
                            if (string.IsNullOrEmpty(cv.Diagnosis))
                            {
                                dmv = new DMV { Id = V.Id };
                            }
                            else
                            {
                                dmv = JsonConvert.DeserializeObject<DMV>(cv.Diagnosis);
                            }
                        }
                        catch(Exception)
                        {

                        }

                        try
                        {
                            if (string.IsNullOrEmpty(cv.Investigation))
                            {
                                imv = new Dictionary<string, Dictionary<string, Dictionary<string, int>>>();
                            }
                            else
                            {
                                imv = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, Dictionary<string, int>>>> (cv.Investigation);
                            }
                        }
                        catch (Exception)
                        {

                        }

                        try
                        {
                            if (string.IsNullOrEmpty(V.HPrescription))
                            {
                                hdList = new List<DrugModelView>();
                            }
                            else
                            {
                                hdList = JsonConvert.DeserializeObject<List<DrugModelView>>(V.HPrescription);
                                hdList = hdList.Select(c => { c.Id = -1; return c; }).ToList();
                            }
                        }
                        catch (Exception hde)
                        {
                            hdList = new List<DrugModelView>();
                        }
                        //ds = db.Discharges
                        //    .Where(d => d.VId == vid && d.PId==pid && d.CId.Equals(C.Id))
                        //    .FirstOrDefault();
                        //if (ds == null)
                        //{
                        //    ds = new Discharge { Id = 0, ApptType = V.ApptType, PId = P.Id, CId = C.Id, VId = V.Id, BillId = V.BillId, Doctor = D.FullName, Department = D.Department, ApptDate = V.ADATE };
                        //}
                        //births = db.Births
                        //    .Where(d => d.VId == vid && d.PId==pid && d.CId.Equals(C.Id))
                        //    .ToList();
                    }
                    

                }
            }
            catch (Exception e)
            {
                DueInWords = Utility.NumberToWords(0);
                NetAmntInWords = Utility.NumberToWords(0);
                voList = new Dictionary<string, Dictionary<int, VisitOrder>>();
                pveppList = new Dictionary<string, List<EPP>>();
                dmv = new DMV();
                imv = new Dictionary<string, Dictionary<string, Dictionary<string, int>>>();
            }
        }
    }
    public class PatientHistory
    {
        public Clinic C { get; set; }
        public Patient P { get; set; }
        public List<PatientVisit> pvList { get; set; }
        public PatientHistory()
        {
            C = new Clinic();
            P = new Patient();
            pvList = new List<PatientVisit>();
        }
        public PatientHistory(int? pid, string cid)
        {
            List<int> vList = new List<int>();
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    
                    C = db.Clinics.Find(cid);
                    P = db.Patients.Find(pid);
                    if (C != null && P != null)
                    {
                        vList = db.Visits.Where(pv => pid==pv.PId && cid.Equals(pv.CId))
                            .Select(pv => pv.Id)
                                .ToList();
                    }
                    pvList = new List<PatientVisit>();
                    foreach (int vid in vList)
                    {
                        pvList.Add(new PatientVisit(pid, vid, cid));
                    }
                }
            }
            catch(Exception e)
            {
                C = new Clinic();
                P = new Patient();
                pvList = new List<PatientVisit>();
            }
        }
    }

    public class DMV
    {
        public int Id { get; set; }
        public decimal P { get; set; }
        public decimal A { get; set; }

        public Dictionary<string, EMV> eList { get; set; }
        public DMV()
        {
            try
            {
                Id = 0;
                P = 0;
                A = 0;
                eList = new Dictionary<string, EMV>();
                eList.Add("", new EMV());
            }
            catch (Exception e)
            {

            }
        }
    }

    public class EMV
    {
        public string E { get; set; }
        public decimal P { get; set; }
        public decimal A { get; set; }
        public Dictionary<string, TMV> tList { get; set; }
        public EMV() {
            try
            {
                P = 0;
                A = 0;
                tList = new Dictionary<string, TMV>();
                tList.Add("", new TMV());
            }
            catch (Exception e)
            {

            }
        }
    }

    public class TMV
    {
        public string T { get; set; }
        public decimal P { get; set; }
        public decimal A { get; set; }
        public List<PP> ppList { get; set; }
        public TMV() {
            try
            {
                P = 0;
                A = 0;
                ppList = new List<PP>();
            }
            catch (Exception e)
            {

            }
        }
    }

    public class PP
    {
        public int Id { get; set; }
        public string N { get; set; }
        public decimal RT { get; set; }
        public int PQ { get; set; }
        public int AQ { get; set; }
        public int PA { get; set; }
        public int AA { get; set; }

        public PP()
        {

        }
    }

    public class EPP
    {
        public string E { get; set; }
        public Dictionary<string, PP> ppList { get; set; }

        public EPP()
        {
            E = string.Empty;
            ppList = new Dictionary<string, PP>();
        }
    }

    public class PatientVisit
    {
        public Visit cv { get; set; }
        public Discharge ds { get; set; }
        public List<Birth> births { get; set; }
        public Dictionary<int, VisitOrder> voList { get; set; }
        
        public List<VisitPayment> vpList { get; set; }
        public List<DrugModelView> dList { get; set; }
        public DMV dmv { get; set; }
        public Dictionary<string, Dictionary<string, List<PP>>> eppList { get; set; }
        public string DueInWords { get; set; }
        public string NetAmntInWords { get; set; }
        public PatientVisit()
        {
            voList = new Dictionary<int, VisitOrder>();
            vpList = new List<VisitPayment>();
        }
        public PatientVisit(int? pid, int vid, string cid)
        {
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    voList = db.VisitOrders
                    .Where(vo => vo.PId==pid &&
                    vo.VId == vid)
                    .ToDictionary(a => a.Id, a => a);
                    vpList = db.VisitPayments
                            .Where(vo => vo.PId==pid &&
                            vo.VId == vid)
                            .ToList();

                    cv = db.Visits.Find(vid);
                    DueInWords = Utility.NumberToWords((int)cv.Due);
                    NetAmntInWords = Utility.NumberToWords((int)cv.NetAmnt);

                    try
                    {
                        if (string.IsNullOrEmpty(cv.Prescription))
                        {
                            dList = new List<DrugModelView>();
                        }
                        else
                        {
                            dList = JsonConvert.DeserializeObject<List<DrugModelView>>(cv.Prescription);
                            dList = dList.Select(c => { c.Id = -1; return c; }).ToList();
                        }
                        if (string.IsNullOrEmpty(cv.Diagnosis))
                        {
                            dmv = new DMV { Id = 0, A = 0, P = 0 };
                        }
                        else
                        {
                            dmv = JsonConvert.DeserializeObject<DMV>(cv.Diagnosis);
                        }
                    }
                    catch (Exception ee)
                    {
                        dList = new List<DrugModelView>();
                    }
                    

                }
            }
            catch (Exception e)
            {
                DueInWords = Utility.NumberToWords(0);
                NetAmntInWords = Utility.NumberToWords(0);
            }
        }
    }

    //
    //SM
    //
    public class PackageRefreshView
    {
        public Package P { get; set; }
        public List<PackageOrder> poList { get; set; }

        public PackageRefreshView()
        {
            P = new Package();
            poList = new List<PackageOrder>();
        }

        public PackageRefreshView(int PkgId)
        {
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    P = db.Packages.Find(PkgId);

                    poList = (from item in db.PackageOrders
                              where item.PkgId == PkgId
                              select item)
                             .ToList();
                }
            }
            catch (Exception e)
            {
                P = new Package();
                poList = new List<PackageOrder>();
            }
        }
    }

    public class PackageModelView
    {
        public List<Package> pList { get; set; }
        public Dictionary<int, List<PackageOrder>> poList { get; set; }

        public PackageModelView()
        {
            pList = new List<Package>();
            poList = new Dictionary<int, List<PackageOrder>>();
        }

        public PackageModelView(string CId, string type)
        {
            try
            {
                using (HMSEntities db = new HMSEntities())
                {
                    pList = (from item in db.Packages
                             where item.CId.Equals(CId) && item.PkgType.Equals(type)
                             select item)
                             .ToList();

                    poList = (from item in db.PackageOrders
                              where item.CId.Equals(CId)
                              select item)
                              .GroupBy(a => a.PkgId)
                             .ToDictionary(p => p.Key, p => (from item in db.PackageOrders
                                                             where item.CId.Equals(CId) && item.PkgId == p.Key
                                                             select item).ToList());
                }
            }
            catch (Exception e)
            {
                pList = new List<Package>();
                poList = new Dictionary<int, List<PackageOrder>>();
            }
        }
    }
}
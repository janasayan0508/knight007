﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;

namespace eLogSheet.Models
{

    public class DashboardView
    {
        public sp_GetUserDetails_Result U { get; set; }
        public int DId { get; set; }
        public StringBuilder json { get; set; }
        public DateTime DT { get; set; }
        public int FY { get; set; }
        public int Q { get; set; }
        public Dictionary<int, Department> dList { get; set; }
        public Dictionary<int, Parameter> pList { get; set; }
        public Dictionary<int, Machine> mList { get; set; }
        public Dictionary<int, Equipment> eList { get; set; }
        public Dictionary<int, Section> sList { get; set; }
        public Dictionary<int, Title> tList { get; set; }
        public List<sp_GetDashboardParametersByDate_Result> dataList { get; set; }
        public List<sp_GetAnnouncementsForDate_Result> annList { get; set; }
        public List<Delay> delaysList { get; set; }
        public List<Incident> incidentsList { get; set; }
        public Dictionary<string, Dictionary<int, Dictionary<string, List<sp_GetDashboardParametersByDate_Result>>>> swdList { get; set; }
        public Dictionary<int, Dictionary<string, List<sp_GetFreqDetails_Result>>> freqList { get; set; }

        public DashboardView()
        {
            dList = new Dictionary<int, Department>();
            pList = new Dictionary<int, Parameter>();
            mList = new Dictionary<int, Machine>();
            eList = new Dictionary<int, Equipment>();
            sList = new Dictionary<int, Section>();
            tList = new Dictionary<int, Title>();
            freqList = new Dictionary<int, Dictionary<string, List<sp_GetFreqDetails_Result>>>();
            dataList = new List<sp_GetDashboardParametersByDate_Result>();
            annList = new List<sp_GetAnnouncementsForDate_Result>();
            swdList = new Dictionary<string, Dictionary<int, Dictionary<string, List<sp_GetDashboardParametersByDate_Result>>>>();
            delaysList = new List<Delay>();
            incidentsList = new List<Incident>();
        }

        public DashboardView(string user, string dt)
        {
            try
            {
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    if (string.IsNullOrEmpty(dt))
                    {
                        DT = DateTime.Now;
                    }
                    else
                    {
                        DT = DateTime.ParseExact(dt, "yyyyMMdd", CultureInfo.InvariantCulture);
                    }

                    FY = (DT.Month <= 3) ? DT.Year - 1 : DT.Year;
                    Q = (DT.Month <= 3) ? 4 : (((DT.Month % 3) == 0) ? (DT.Month / 3) - 1 : (int)(DT.Month / 3));

                    U = db.sp_GetUserDetails(user).FirstOrDefault();
                    dList = db.Departments.ToDictionary(m => m.Id, m => m);
                    mList = db.Machines.ToDictionary(m => m.Id, m => m);
                    //eList = db.Equipments.Where(e => e.DId == D.Id).ToDictionary(e => e.Id, e => e);
                    sList = db.Sections.ToDictionary(s => s.Id, s => s);
                    pList = db.Parameters.ToDictionary(p => p.Id, p => p);
                    dataList = db.sp_GetDashboardParametersByDate(string.Format("{0:yyyyMMdd}", DT)).ToList();
                    annList = db.sp_GetAnnouncementsForDate(string.Format("{0:yyyyMMdd}", DT)).ToList();
                    List<sp_GetFreqDetails_Result> tmp = db.sp_GetFreqDetails().ToList();
                    delaysList = db.Delays.Where(d => DateTime.Compare(d.DT ?? DT, DT.Date) == 0).ToList();
                    incidentsList = db.Incidents.Where(d => DateTime.Compare(d.DT ?? DT, DT.Date) == 0).ToList();
                    
                    freqList = tmp.GroupBy(f => f.Id)
                .ToDictionary(f => f.Key,
                f => tmp.Where(a => a.Id == f.Key).
                GroupBy(b => b.Freq).ToDictionary(c => c.Key, c => tmp
                .Where(x => x.Id == f.Key && x.Freq.Equals(c.Key)).ToList()));

                    json = new StringBuilder();
                    json.Append(JsonConvert.SerializeObject(this, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                    }));

                }
            }
            catch (Exception e)
            {

            }
        }
    }
    public class DepttSettingsView
    {
        public List<Parameter> paramList { get; set; }
        public List<Equipment> eqpList { get; set; }
        public List<Machine> mcnList { get; set; }
        public List<Title> tList { get; set; }
        public StringBuilder json { get; set; }
        public Dictionary<int, Frequency> freqList { get; set; }
        public Department D { get; set; }
        public sp_GetUserDetails_Result U { get; set; }
        public DepttSettingsView()
        {
            tList = new List<Title>();
            mcnList = new List<Machine>();
            eqpList = new List<Equipment>();
            paramList = new List<Parameter>();
            D = new Department();
            U = new sp_GetUserDetails_Result();
        }
        public DepttSettingsView(string user, int did)
        {
            try
            {
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    U = db.sp_GetUserDetails(user).FirstOrDefault();
                    if (U != null)
                    {
                        D = db.Departments.Find(U.DId);
                        if (D == null)
                        {
                            D = db.Departments.Find(did);
                        }
                        paramList = db.Parameters
                            .Where(i => i.DId == D.Id)
                            .ToList();

                        eqpList = db.Equipments
                            .Where(i => i.DId == D.Id)
                            .ToList();

                        mcnList = db.Machines
                            .Where(i => i.DId == D.Id)
                            .ToList();

                        tList = db.Titles
                            .Where(i => i.DId == D.Id)
                            .ToList();

                        freqList = db.Frequencies.ToDictionary(f => f.Id, f => f);

                        json = new StringBuilder();
                        json.Append(JsonConvert.SerializeObject(this, Formatting.Indented,
                        new JsonSerializerSettings
                        {
                            ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                        }));

                    }
                }
            }
            catch (Exception e)
            {
                tList = new List<Title>();
                mcnList = new List<Machine>();
                eqpList = new List<Equipment>();
                paramList = new List<Parameter>();
                freqList = new Dictionary<int, Frequency>();
                D = new Department();
                U = new sp_GetUserDetails_Result();
            }
        }
    }

    public class AdminSettingsView
    {
        public List<Department> cList { get; set; }
        public List<AspNetUser> uList { get; set; }
        public UserView U { get; set; }
        public AdminSettingsView()
        {
            U = new UserView();
            cList = new List<Department>();
            uList = new List<AspNetUser>();
        }
        public AdminSettingsView(string user)
        {
            try
            {
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    U = db.AspNetUsers
                        .Where(u => u.UserName.Equals(user))
                        .Select(u => new UserView
                        {
                            U = u.UserName,
                            N = u.UserName,
                            M = u.PhoneNumber,
                            Id = u.Id,
                            DId = u.DId,
                            LI = u.LastLoginIP,
                            LL = u.LastLogin
                        })
                        .FirstOrDefault();
                    if (U != null)
                    {
                        uList = db.AspNetUsers
                            .ToList();
                        cList = db.Departments.ToList();
                    }
                }
            }
            catch (Exception e)
            {
                U = new UserView();
                uList = new List<AspNetUser>();
                cList = new List<Department>();
            }
        }
    }
    public class UserView
    {
        public string Id { get; set; }
        public string DId { get; set; }
        public string U { get; set; }

        public string N { get; set; }
        public string E { get; set; }
        public string M { get; set; }
        public DateTime? LL { get; set; }
        public string LI { get; set; }

        public string M1 { get; set; }
        public string M2 { get; set; }
        public string M3 { get; set; }

        public UserView()
        {

        }
        public UserView(string uid)
        {
            try
            {
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    AspNetUser user = db.AspNetUsers
                        .Where(u => u.UserName.Equals(uid))
                        .FirstOrDefault();
                    if (user != null)
                    {
                        U = user.UserName;
                        N = user.UserName;
                        M = user.PhoneNumber;
                        Id = user.Id;
                        DId = user.DId;
                        LI = user.LastLoginIP;
                        LL = user.LastLogin;
                        M1 = user.M1;
                        M2 = user.M2;
                        M3 = user.M3;
                    }
                }
            }
            catch (Exception e)
            {

            }
        }
    }
    public class SheetView
    {
        public sp_GetUserDetails_Result U { get; set; }
        public int DId { get; set; }
        public StringBuilder json { get; set; }
        public DateTime DT { get; set; }
        public int FY { get; set; }
        public int Q { get; set; }
        public Dictionary<int, Parameter> pList { get; set; }
        public Dictionary<int, Machine> mList { get; set; }
        public Dictionary<int, Equipment> eList { get; set; }
        public Dictionary<int, Section> sList { get; set; }
        public Dictionary<int, Title> tList { get; set; }
        public List<sp_GetProductionParametersForDepttByrDate_Result> dataList { get; set; }
        public List<Delay> delaysList { get; set; }
        public List<Incident> incidentsList { get; set; }
        public Dictionary<string, Dictionary<int, Dictionary<string, sp_GetProductionParametersForDepttByrDate_Result>>> swpList { get; set; }
        public Dictionary<int, Dictionary<string, List<sp_GetFreqDetails_Result>>> freqList { get; set; }

        public SheetView() { 
            pList = new Dictionary<int, Parameter>();
            mList = new Dictionary<int, Machine>();
            eList = new Dictionary<int, Equipment>();
            sList = new Dictionary<int, Section>();
            tList = new Dictionary<int, Title>();
            freqList = new Dictionary<int, Dictionary<string, List<sp_GetFreqDetails_Result>>>();
            dataList = new List<sp_GetProductionParametersForDepttByrDate_Result>();
            swpList = new Dictionary<string, Dictionary<int, Dictionary<string, sp_GetProductionParametersForDepttByrDate_Result>>>();
            delaysList = new List<Delay>();
            incidentsList = new List<Incident>();
        }

        public SheetView(string user, string dt, int did)
        {
            try
            {
                using (eLogSheetEntities db = new eLogSheetEntities())
                {
                    DId = did;
                    if (string.IsNullOrEmpty(dt))
                    {
                        DT = DateTime.Now;
                    }
                    else
                    {
                        DT = DateTime.ParseExact(dt, "yyyyMMdd", CultureInfo.InvariantCulture);
                    }

                    FY = (DT.Month <= 3) ? DT.Year - 1 : DT.Year;
                    Q = (DT.Month <= 3) ? 4 : (((DT.Month % 3) == 0) ? (DT.Month / 3) - 1 : (int)(DT.Month / 3));

                    U = db.sp_GetUserDetails(user).FirstOrDefault();
                    mList = db.Machines.Where(m => m.DId == did).ToDictionary(m => m.Id, m => m);
                    //eList = db.Equipments.Where(e => e.DId == D.Id).ToDictionary(e => e.Id, e => e);
                    sList = db.Sections.Where(s => s.DId == did).ToDictionary(s => s.Id, s => s);
                    pList = db.Parameters.Where(p => p.DId == did).ToDictionary(p => p.Id, p => p);
                    dataList = db.sp_GetProductionParametersForDepttByrDate(did, string.Format("{0:yyyyMMdd}", DT)).ToList();
                    List<sp_GetFreqDetails_Result> tmp = db.sp_GetFreqDetails().ToList();
                    
                    delaysList = db.Delays.Where(d => d.DId == did && DateTime.Compare(d.DT ?? DT, DT.Date) == 0).ToList();
                    if (delaysList == null)
                    {
                        delaysList = new List<Delay>();
                    }

                    incidentsList = db.Incidents.Where(d => d.DId == did && DateTime.Compare(d.DT ?? DT, DT.Date) == 0).ToList();
                    if(incidentsList==null)
                    {
                        incidentsList = new List<Incident>();
                    }
                    freqList = tmp.GroupBy(f => f.Id)
                .ToDictionary(f => f.Key,
                f => tmp.Where(a => a.Id == f.Key).
                GroupBy(b => b.Freq).ToDictionary(c => c.Key, c => tmp
                .Where(x => x.Id == f.Key && x.Freq.Equals(c.Key)).ToList()));

                    
                        json = new StringBuilder();
                        json.Append(JsonConvert.SerializeObject(this, Formatting.Indented,
                        new JsonSerializerSettings
                        {
                            ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                        }));

                }
            }
            catch (Exception e)
            {

            }
        }
    }

    public class EntryView
    {
        public Department D { get; set; }
        public DateTime DT { get; set; }
        public List<Datum> dList { get; set; }

        public EntryView()
        {
            D = new Department();
            dList = new List<Datum>();
        }
    }

    public class DepttView
    {
        public Department D { get; set; }
        public List<ShiftView> svList { get; set; }

        public DepttView()
        {
            svList = new List<ShiftView>();
        }
    }
    public class ShiftView
    {
        public string SN { get; set; }
        public List<MachineView> mvList { get; set; }

        public ShiftView()
        {
            mvList = new List<MachineView>();
        }
    }

    public class MachineView
    {
        public string MN { get; set; }
        public List<Parameter> pList { get; set; }

        public MachineView()
        {
            pList = new List<Parameter>();
        }
    }
}